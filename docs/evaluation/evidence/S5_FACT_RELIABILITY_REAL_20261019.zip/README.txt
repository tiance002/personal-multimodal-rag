S5 authorized fixed-context generation only. No retrieval/API acceptance. No credentials/headers saved. Grant and execution CLOSED; old UNKNOWN unchanged. Compare raw bodies to S5 frozen cases.
