import asyncio,json,sys,os,secrets,subprocess,time
from pathlib import Path
ROOT=Path('E:/RAG-Worktrees/s8-six-dataset-evaluation');sys.path.insert(0,str(ROOT))
from scripts.s8_evaluation_controller import read,write,S8ApiClient,S8Controller,validate_identity
R=Path('E:/WK/run/s8-20261019');plan=read(R/'evaluation-plan.json')
async def snapshot():
 from scripts.local_runtime import load_config,environment,verify_resources
 from scripts.s2_generation_quality import identity_for
 from backend.weknora_port.development import DevelopmentSettings,assemble
 cfg=load_config('E:/WK/run/s4-quality-20261019/local.json');ident=await verify_resources(cfg);env,p=identity_for(332,environment(cfg,ident['redis_run_id']),read('E:/WK/run/p25-20261017/runtime/state.json'));env['WEKNORA_PORT_CLOUD_ALLOWED']='false';env.pop('WEKNORA_PORT_EXECUTION_FILE',None)
 async with assemble(DevelopmentSettings.from_environment(env),principal=p) as app:
  async with app.leases.lease() as g:
   await g.connection.execute('SET TRANSACTION READ ONLY'); out={}
   for name,sql in [('provider',"SELECT count(*) AS n,count(*) FILTER(WHERE outcome='UNKNOWN') AS unknown FROM port_provider_calls"),('sessions','SELECT count(*) AS n FROM sessions'),('principal',"SELECT md5(string_agg(row_to_json(t)::text,'' ORDER BY tenant_id,subject_id)) AS digest FROM port_local_principal t"),('models',"SELECT count(*) AS n,md5(string_agg(row_to_json(t)::text,'' ORDER BY id)) AS digest FROM models t"),('configuration',"SELECT md5(string_agg(row_to_json(t)::text,'' ORDER BY tenant_id,subject_id)) AS digest FROM port_model_configuration t")]:
    out[name]=await (await g.connection.execute(sql)).fetchone()
   return out
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as run:before=run.run(snapshot())
write(R/'readonly-api.before.json',before);results=[]
for arm in ('A','B','C'):
 out=R/('readonly-api-'+arm);out.mkdir(exist_ok=False);token=secrets.token_urlsafe(40);env=os.environ.copy();env['S8_API_BEARER_TOKEN']=token;env['S8_API_TOKEN_EXPIRES']=str(time.time()+1800)
 cmd=[sys.executable,'scripts/s8_trusted_api.py','--plan',str(R/'evaluation-plan.json'),'--config','E:/WK/run/s4-quality-20261019/local.json','--principal-state','E:/WK/run/p25-20261017/runtime/state.json','--arm',arm,'--output',str(out)]
 with (out/'server.stdout.log').open('xb') as stdout,(out/'server.stderr.log').open('xb') as stderr:process=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=stdout,stderr=stderr)
 try:
  for _ in range(100):
   if process.poll() is not None:raise ValueError('READONLY_API_PROCESS_EXITED_SEE_PRIVATE_LOG')
   if (out/'startup.json').exists():break
   time.sleep(.1)
  else:raise ValueError('READONLY_API_STARTUP_TIMEOUT')
  identity=read(out/'startup.json');validate_identity(plan,identity,arm);client=S8ApiClient(identity['base_url'],token)
  try:
   for _ in range(50):
    try:
     first=client.request('GET','/api/v1/runtime',authenticated=False);break
    except Exception:time.sleep(.1)
   missing=first.status_code;wrong=client.request('GET','/api/v1/runtime',headers={'Authorization':'Bearer wrong-token'}).status_code
   assert missing==401 and wrong==401
   runtime=client.get_json('/api/v1/runtime');visible=client.get_json('/api/v1/knowledge-bases');settings=client.get_json('/api/v1/settings/model-configuration')
   assert {c['knowledge_base_id'] for c in plan['cases']} <= {k['id'] for k in visible}
   controller=S8Controller(plan,arm,identity,client,R/('readonly-unused-checkpoint-'+arm+'.json'));check=controller.preflight_api()
   forbidden=client.request('GET','/api/v1/knowledge-bases/2703fb2d-743d-462e-a5b8-c5311a3a8ed2');assert forbidden.status_code in (403,404)
   result={'arm':arm,'status':'PASS_REAL_READONLY_API','missing_token':missing,'wrong_token':wrong,'tenant1_kb_denied':forbidden.status_code,'visible_kbs':len(visible),'planned_kbs_visible':True,'principal_and_resource_identity_verified':True,'global_cloud_allowed':identity['cloud_allowed'],'graph_enabled':identity['graph_enabled'],'floorless':identity['rerank_top1_floorless'],'stored_vs_effective_model_binding_verified':True,'new_sessions':0,'question_posts':0,'provider_calls':0,'controller_preflight':check}
   write(out/'result.json',result);results.append(result)
  finally:client.close()
 finally:
  (out/'stop.request').touch(exist_ok=False)
  process.wait(timeout=20)
  assert process.returncode==0
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as run:after=run.run(snapshot())
write(R/'readonly-api.after.json',after);assert before==after
write(R/'readonly-api.results.json',{'status':'PASS_REAL_API_ZERO_PROVIDER','arms':results,'snapshots_unchanged':before==after,'before':before,'after':after,'new_provider_calls':0,'new_sessions':0,'new_question_posts':0,'database_business_writes':0});print(json.dumps({'status':'PASS_REAL_API_ZERO_PROVIDER','arms':results,'snapshots_unchanged':True},ensure_ascii=False))
