"""Compare only public frozen Gold identities; never model calls or persistence."""
import json,hashlib,subprocess
from pathlib import Path
def canonical(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
root=Path('/opt/rag-p7-r1')
paths=[root/'data/v6-dev24-inputs/inputs/evaluation/cohort_dev24.jsonl',root/'state/authority/paired-glue-r4/evaluation40/hotpotqa-cases.jsonl',root/'state/authority/paired-glue-r4/evaluation40/mmlongbench-doc-cases.jsonl']
out={'new_provider_calls':0,'database_writes':0,'public_gold_files':[]}
for path in paths:
    rows=[json.loads(s) for s in path.read_text().splitlines() if s.strip()] if path.exists() else []
    out['public_gold_files'].append({'path':str(path),'exists':path.exists(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None,'rows':rows})
path=root/'data/special-subsets-r1/OmniDocBench/OmniDocBench.json'
out['omni_gold']={'path':str(path),'exists':path.exists()}
if path.exists():
    b=path.read_bytes();pages=json.loads(b);matches=[]
    if isinstance(pages,dict):pages=pages.get('data',pages.get('pages',[]))
    for page in pages:
        info=page.get('page_info',{});name=Path(info.get('image_path','')).name
        if name in EXPECTED_OMNI_NAMES:
            matches.append({'filename':name,'gold_sha256':hashlib.sha256(canonical(page).encode()).hexdigest()})
    out['omni_gold'].update(sha256=hashlib.sha256(b).hexdigest(),page_count=len(pages),selected_page_matches=matches)
sql="BEGIN READ ONLY; SELECT json_agg(json_build_object('id',id,'provider',provider,'model_name',model_name,'model_revision',model_revision,'dimension',dimension,'distance',distance,'fingerprint',fingerprint)) FROM embedding_profiles; ROLLBACK"
p=subprocess.run(['runuser','-u','postgres','--','psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-d','rag_p7_r1','-c',sql],capture_output=True,text=True,timeout=15)
out['legacy_embedding_profiles']={'exit_code':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()[:300]}
print(json.dumps(out,ensure_ascii=False))
