"""Join existing read-only receipts into S8.0 delivery; no services or model IO."""
import json,hashlib,subprocess,zipfile,re
from pathlib import Path
R=Path('E:/WK/run/s8-20261019');ROOT=Path('E:/RAG-Worktrees/s8-six-dataset-evaluation')
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def git(*args,cwd=ROOT):return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
import sys
sys.path.insert(0,str(ROOT))
from scripts.s8_evaluation_controller import source_fingerprints,canonical,validate_plan
t=read(R/'text-contracts.json');m=read(R/'multimodal-contracts.json');idx=read(R/'index-integrity.json');remote=read(R/'ecs-readonly.raw.json');supp=read(R/'ecs-readonly.supplement.json');gold=read(R/'ecs-gold-profile.json');api=read(R/'readonly-api.results.json');plan=read(R/'evaluation-plan.json');old=read('E:/WK/run/m4-full-sweep-20261018/qa_cases.json')
base=read('E:/RAG-Worktrees/s7-graph-targeted/.planning/2026-10-19-s7-graph/original-main-worktree.json')
main=Path('E:/RAG-Worktrees/weknora-python-port-20261013')
preserved=[{'path':f['path'],'expected_sha256':f['sha256'],'current_sha256':sha(main/f['path'])} for f in base['files']]
assert len(preserved)==18 and all(x['expected_sha256']==x['current_sha256'] for x in preserved)
protection={'main_head':git('rev-parse','HEAD',cwd=main),'main_original_head':base['head'],'all18_unchanged':True,'files':preserved,
 'reference_worktrees':[{ 'path':str(p),'head':git('rev-parse','HEAD',cwd=p),'status':git('status','--porcelain',cwd=p)} for p in (Path('E:/RAG-Worktrees/s7-graph-targeted'),Path('E:/RAG-Worktrees/rerank-top1-experiment'))]}
assert protection['main_head']==base['head'] and all(not x['status'] for x in protection['reference_worktrees'])
put(R/'preservation-audit.json',protection)

oldids={c['case_id'] for c in old};allcases=plan['cases']+plan['blocked_cases'];extra=[c for c in plan['cases'] if c['case_id'] not in oldids and c['dataset']!='engineering-negative']
assert len(extra)==10
local_arch={d['dataset']:d['transport_archive'] for d in t['datasets']}
local_arch.update({k:v for k,v in m['archives'].items()})
remote_arch={Path(x['path']).stem:x for x in supp['six_archives']}
package_comparison=[]
for ds in ('scifact','miracl-zh','longbench-zh','omnidocbench','mmlongbench-doc','hotpotqa'):
    a,b=local_arch[ds],remote_arch[ds]
    package_comparison.append({'dataset':ds,'local_sha256':a['sha256'],'ecs_sha256':b['sha256'],'ecs_path':b['path'],'bytes':b['bytes'],'exact_match':a['sha256']==b['sha256'],'action':'REUSE_EXISTING_ECS_ARCHIVE_NO_UPLOAD'})
assert all(x['exact_match'] for x in package_comparison)
remote_cases={(x['dataset'],x['qid']):x for f in gold['public_gold_files'] for x in f['rows']}
gold_rows=[]
for c in old:
    other=remote_cases.get((c['dataset'],c['qid']))
    fields=('dataset_version','question','qrels','answers')
    mismatch=[k for k in fields if other is None or c.get(k,[] if k=='answers' else None)!=other.get(k,[] if k=='answers' else None)]
    gold_rows.append({'case_id':c['case_id'],'present':other is not None,'compared_fields':list(fields),'mismatch_fields':mismatch,'match':not mismatch})
omni_gold={p['filename']:p['gold_sha256'] for p in gold['omni_gold']['selected_page_matches']}
omni_gold_checks=[{'page_id':p['page_id'],'filename':p['filename'],'local_sha256':p['gold_sha256'],'ecs_sha256':omni_gold.get(p['filename']),'match':p['gold_sha256']==omni_gold.get(p['filename'])} for p in m['omni_pages']]
put(R/'ecs-data-comparison.json',{'packages':package_comparison,'qa_gold':gold_rows,'omni_gold':omni_gold_checks,'new_provider_calls':0,'transfers':0})

# Preserve previous proposed local plan, never convert it to a permission.
backup=R/'evaluation-plan.before-ecs-target.json'
if not backup.exists():backup.write_bytes((R/'evaluation-plan.json').read_bytes())
plan['status']='S8_0_BASELINE_READY_LOCAL_REFERENCE_ONLY_ECS_GAPS'
plan['evaluation_environment']={'local':'S8.0_READONLY_AND_OFFLINE_ONLY','formal_S8.1_S8.2':'ECS','ecs_identity':remote['identity'],'ecs_ready':False,'local_identity_is_not_ecs_identity':True,'formal_plan_requires_new_remote_source_runtime_freeze':True}
plan['evaluation_stages']={'S8.0':'COMPLETE_READONLY_PRECHECK','S8.1':'NOT_RUN_ECS_PREPARATION_AND_NEW_AUTHORIZATION_REQUIRED','S8.2':'NOT_RUN_ECS_PREPARATION_AND_NEW_AUTHORIZATION_REQUIRED','S8.3':'NOT_RUN_NO_NEW_COMPARABLE_BASELINE'}
plan['source_fingerprints']=source_fingerprints()
plan['source_snapshot']['index_integrity_sha256']=sha(R/'index-integrity.json')
plan['source_snapshot_sha256']=hashlib.sha256(canonical(plan['source_snapshot']).encode()).hexdigest()
plan['selection_rules']['A']='38 original40 fresh cases plus10 already-mapped SciFact;1 engineering indexed-text insufficiency case separately labeled. All are future candidates, not currently authorized submissions.'
plan['scope_limitations'].append('Owner moved formal S8.1/S8.2 to ECS. This Windows plan is an offline input reference, not a deployable remote identity or send grant; ECS source/runtime/model freeze must be regenerated after approved preparation.')
validate_plan(plan);put(R/'evaluation-plan.json',plan)
proposal=read(R/'owner-envelope.proposed.json');proposal['status']='SUPERSEDED_PROPOSAL_NOT_AUTHORIZED_ECS_REPLAN_REQUIRED';proposal['owner_approval']=None;proposal['approved_case_arms']=[];proposal['ledgers']=[];proposal['plan_sha256']=hashlib.sha256(canonical(plan).encode()).hexdigest();proposal['note']='Previous numeric envelope was never approved. Do not activate it; current Owner only requests S8.0 and an ECS gap/migration plan.';put(R/'owner-envelope.proposed.json',proposal)

datasets=[]
for d in t['datasets']:
    datasets.append({'dataset':d['dataset'],'official_frozen_QIDs':8,'current_kb_documents':d['counts']['saved_KB_documents'],'required_original8_sources_present':8,
        'existing_vector_rows':sum(x['count'] for x in d['current_KB_vector_aggregate']),'dimension':1024,'metric_contract':d['metric_contract'],
        'additional_ready_questions':10 if d['dataset']=='scifact' else 0,'remaining_prepared_scope':d['counts'],'new_QA':0})
datasets.extend([
 {'dataset':'hotpotqa','official_frozen_QIDs':8,'current_kb_documents':24,'prepared_documents':73,'missing_background_documents':49,'required_source_bindings_present':16,'cases_all_required_source_identity_present':8,'existing_vector_rows':59,'dimension':1024,'new_QA':0,'metric_contract':m['metric_policy']['hotpot']},
 {'dataset':'mmlongbench-doc','official_frozen_QIDs':8,'required_original_PDFs':3,'current_scope_kb_documents':4,'existing_scope_vector_rows':274,'dimension':1024,'new_QA':0,'metric_contract':m['metric_policy']['mml']},
 {'dataset':'omnidocbench','official_frozen_pages':24,'images_and_Gold_SHA_valid':24,'saved_MinerU_parses':24,'new_parses':0,'current_legacy_OCR_indexed_pages':21,'current_placeholder_only_pages':3,'existing_vector_rows':66,'dimension':1024,'valid_project_page_text_NED_mapping':3,'NOT_SCORABLE':21,'metric_contract':m['metric_policy']['omni']}])
frozen_rows=[]
text_cases={c['case_id']:c for d in t['datasets'] for c in d['frozen_cases']};special={c['case_id']:c for c in m['cases']};planned={c['case_id']:c for c in allcases}
for c in old:
    p=planned[c['case_id']];detail=text_cases.get(c['case_id'],special.get(c['case_id']));protected=c['case_id'] in {x['case_id'] for x in plan['blocked_cases']}
    historical=detail.get('history',detail.get('historical_full_rag',{}))
    frozen_rows.append({'case_id':c['case_id'],'dataset':c['dataset'],'qid':c['qid'],'question':c['question'],'kb':c['knowledge_base_id'],'document_scope':[],
       'current_source_identity':'ALL_REQUIRED_SOURCES_MAPPED','current_fact_coverage':'UNVERIFIED_REQUIRES_STAGE_TRAJECTORY_NOT_SOURCE_ID_ALONE',
       'gold_scoring_only':{k:c.get(k) for k in ('dataset_version','qrels_kind','qrels','answers','evaluation_metadata')},
       'historical_receipt':historical,'new_S8_QA_status':'NOT_RUN_OWNER_REQUEST_S8_0_ONLY',
       'next_submission':'PROHIBITED_HISTORICAL_UNKNOWN_NO_RESEND' if protected else 'LOCAL_INPUT_READY_ECS_NOT_READY_NEW_AUTHORIZATION_REQUIRED'})
omni_rows=[{**p,'new_S8_status':'NOT_RUN_REUSED_SAVED_PARSE_ONLY','ecs_selected_gold_verified':next(x['match'] for x in omni_gold_checks if x['page_id']==p['page_id'])} for p in m['omni_pages']]

gaps=[
 {'id':'ECS_RUNTIME','severity':'BLOCKING_FORMAL_EVALUATION','actual':'Only legacy eval_center.server active; Git f15aaeb374e32d7955429784b4d9dd50317608a5. No current weknora_port source/service found in known project roots.','minimum_action':'Install one pinned current release in a new isolated path, no main-chain redesign; cloud off and no old Worker queues.'},
 {'id':'ECS_POSTGRES_EXTENSIONS','severity':'BLOCKING_FORMAL_EVALUATION','actual':'PG16.15; vector0.6.0; halfvec absent; pg_search absent.','minimum_action':'Provide an isolated PG/ParadeDB runtime compatible with the actual Windows source extensions; do not upgrade/overwrite legacy rag_p7_r1 in place.'},
 {'id':'ECS_SCHEMA_AND_IDENTITIES','severity':'BLOCKING_FORMAL_EVALUATION','actual':'rag_p7_r1 is legacy0022_memory_vector_index;7KB751docs5351chunks4777legacy embeddings. None of7 frozen current KB IDs exists; current port_schema_migrations/embeddings absent.','minimum_action':'Restore only approved tenant332 identity/FK closure/current Chunk and vector data into a new target DB, preserving IDs/SHA/version. No new Embedding.'},
 {'id':'ECS_REDIS','severity':'BLOCKING_FORMAL_EVALUATION','actual':'No redis-cli, active service, TCP listener or old private socket observed.','minimum_action':'Provide isolated Redis DB/prefix and new verified run ID; do not restore old worker queues/leases.'},
 {'id':'ECS_MODEL_CONFIGURATION','severity':'BLOCKING_REAL_SEND','actual':'No current formal Model Registry or decryptable-role proof; legacy credential receipt metadata is not usable credentials/account proof. No Provider probe sent.','minimum_action':'Securely configure original approved cipher/credentials, tenant332 roles and isolated existing Qwen binding; verify normal read-only settings API, then obtain new stage send authorization.'},
 {'id':'CROSS_PLATFORM_ASSET_PATHS','severity':'BLOCKING_SOURCE_READBACK_AFTER_COPY','actual':'Current documents.file_path and asset manifest paths contain Windows physical paths; storage marker binds source PG physical ID.','minimum_action':'Map only target-copy physical locations/separators and regenerate legitimate target storage ownership after SHA verification. Never alter source IDs/content/versions or bypass containment.'},
 {'id':'OMNI_MINERU_INDEX_GAP','severity':'QUALITY_AND_SCOPE_GAP','actual':'24 saved local MinerU parse receipts did not write DB;21 legacy OCR indexed pages and3 placeholders. Only3 validated project-NED mappings.','minimum_action':'Use saved parses for parsing review now; do not claim current MinerU RAG or official structure score. New indexing or scoring work requires a separate explicit scope decision, no silent re-Embedding.'},
 {'id':'LOCAL_1024_ANN','severity':'PERFORMANCE_RISK_NOT_MISSING_VECTOR','actual':'739 nonnull1024 vectors; only existing HNSW partial index is dimension3, not1024. BM25 valid; exact distance SQL does not require ANN.','minimum_action':'Preserve values and report exact-search baseline; evaluate/authorize target1024 database index separately rather than regenerate embeddings.'}]
result={'schema':'s8-six-dataset-evaluation/v1','overall_status':'PARTIAL','S8_0_status':'BASELINE_READY','S8_0_readonly_audit':'PASS_WITH_EXPLICIT_GAPS',
 'formal_target':'ECS','formal_ECS_ready':False,'S8_1':'NOT_RUN','S8_2':'NOT_RUN','S8_3':'NOT_RUN','base_graph_commit':plan['base_graph_commit'],'base_top1_commit':plan['base_top1_commit'],
 'implementation_commit':git('rev-parse','HEAD'),'branch':git('branch','--show-current'),'worktree':str(ROOT),
 'production_defaults_changed':False,'datasets':datasets,'frozen40':frozen_rows,'additional10':extra,
 'engineering_negative':{'case':plan['cases'][-1],'status':'READY_LOCAL_INDEXED_TEXT_DIAGNOSTIC_ONLY_ECS_NOT_READY','official_Gold':False,'S7_same_question_but_different_tenant_KB':True,'old_scores_or_answers_reused_as_current':False,'pixels_certified_answer_free':False,'Top1_low_score_trigger':'UNVERIFIED_NOT_NEWLY_CALLED'},
 'omni24':omni_rows,'denominators':{'official_frozen_QA':40,'local_data_ready_original_QA':40,'protected_unknown_QIDs':2,'next_fresh_original_QA':38,'additional_source_ready_official_QA':10,'next_possible_fresh_official_QA':48,'engineering_negative':1,'omni_pages':24,'new_QA_submissions':0},
 'local_index_audit':{k:v for k,v in idx.items() if k!='knowledge_bases'},'local_index_by_kb':[{k:v for k,v in row.items() if k!='rows'} for row in idx['knowledge_bases']],
 'ecs':{'current_observation_utc':remote['utc']['stdout'],'identity':remote['identity'],'resources':remote['resources'],'current_application_git':'f15aaeb374e32d7955429784b4d9dd50317608a5','package_comparison':package_comparison,'QA_Gold_exact_matches':sum(x['match'] for x in gold_rows),'Omni_Gold_exact_matches':sum(x['match'] for x in omni_gold_checks),'legacy_embedding_profile':gold['legacy_embedding_profiles'],'gaps':gaps,'not_a_full_machine_or_managed_RDS_census':True},
 'independent_candidates':{'A':'OFFLINE_BASELINE_EQUIVALENCE_ONLY','B':'KEEP_EXPERIMENTAL_NO_NEW_QUALITY_RESULT','C':'KEEP_EXPERIMENTAL_19_EXISTING_VALID_CONTRIBUTIONS_NO_NEW_QUALITY_RESULT','D':'NOT_RUN_FORBIDDEN'},
 'usage':{'new_provider_calls':0,'new_input_tokens':0,'new_output_tokens':0,'new_total_tokens':0,'new_UNKNOWN':0,'historical_global_UNKNOWN_before':8,'historical_global_UNKNOWN_after':8,'historical_unknown_usage_is_not_zeroed':True,'new_uploads':0,'new_parses':0,'new_embedding_requests':0,'database_business_writes':0,'ecs_transfers':0,'ecs_install_or_deploy':0},
 'readonly_normal_API':api,'protection':protection,'tests':{'affected_pytest':{'exit_code':0,'passed':221,'log':'affected-tests.txt'},'valid_saved_rerank_A_equivalence':{'exit_code':0,'cases':6,'no_new_provider':True},'fresh_QA':'NOT_RUN'},
 'estimated_future_requests_not_authorization':{'A_at_most':49,'B_at_most':6,'C_at_most':4,'max_provider_per_normal_case':11,'max_provider_total_without_direct_diagnostics':649,'Token_envelope':'NOT_FROZEN_FOR_ECS; final wire reservations and new Owner approval required','currently_authorized_new_sends':0},
 'report_commit_resolution':'git log -1 --format=%H -- docs/evaluation/S8_SIX_DATASET_EVALUATION.md'}
put(R/'s80-delivery.results.json',result)
print(json.dumps({'S8.0':result['S8_0_status'],'new_provider_calls':0,'new_QA':0,'ECS_six_archives_SHA_matched':len(package_comparison),'ECS_QA_Gold_matches':sum(x['match'] for x in gold_rows),'ECS_Omni_Gold_matches':sum(x['match'] for x in omni_gold_checks),'preserved18':True,'implementation_commit':result['implementation_commit']},ensure_ascii=False))
