"""Read only known ECS data/extension/runtime metadata; no secret values."""
import json,os,subprocess,hashlib,urllib.request,zipfile
from pathlib import Path
def cmd(a,timeout=15):
    try:
        p=subprocess.run(a,capture_output=True,text=True,timeout=timeout)
        return {'exit_code':p.returncode,'stdout':p.stdout.strip(),'stderr':p.stderr.strip()[:300]}
    except Exception as e:return {'exit_code':None,'error':type(e).__name__}
def pg(sql):
    # Both read-only transaction and SELECT/SHOW-only statements; no DDL/DML.
    return cmd(['runuser','-u','postgres','--','psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-d','rag_p7_r1','-c','BEGIN READ ONLY; '+sql+'; ROLLBACK'])
result={'kind':'S8_ECS_READONLY_SUPPLEMENT','new_provider_calls':0,'database_writes':0,'transfers':0,'service_changes':0}
result['utc']=cmd(['date','-u','+%Y-%m-%dT%H:%M:%SZ'])
result['pg_compatibility']=pg("SELECT json_build_object('read_only',current_setting('transaction_read_only'),'halfvec',to_regtype('halfvec')::text,'port_schema',to_regclass('public.port_schema_migrations')::text,'current_embeddings',to_regclass('public.embeddings')::text,'legacy_embeddings',to_regclass('public.chunk_embeddings')::text,'preload',current_setting('shared_preload_libraries'))")
result['legacy_schema_counts']=pg("SELECT json_build_object('knowledge_bases',(SELECT count(*) FROM knowledge_bases),'documents',(SELECT count(*) FROM documents),'chunks',(SELECT count(*) FROM chunks),'chunk_embeddings',(SELECT count(*) FROM chunk_embeddings),'legacy_schema_version',(SELECT version_num FROM alembic_version LIMIT 1))")
result['six_named_legacy_kbs']=pg("SELECT json_agg(json_build_object('id',id,'name',name,'cloud_allowed',cloud_allowed)) FROM knowledge_bases WHERE lower(name) LIKE ANY(ARRAY['%scifact%','%miracl%','%longbench%','%omnidoc%','%hotpot%'])")
result['legacy_profile_columns']=pg("SELECT json_agg(column_name) FROM information_schema.columns WHERE table_schema='public' AND table_name='embedding_profiles'")
result['active_application']=cmd(['readlink','-f','/srv/rag-eval/app'])
try:
    health=json.loads(urllib.request.urlopen('http://127.0.0.1:8787/healthz',timeout=5).read())
    result['legacy_health']={k:v for k,v in health.items() if k in ('status','code_sha','git_sha','implementation','version')}
except Exception as e:result['legacy_health']={'error':type(e).__name__}
release=Path('/opt/rag-p7-r1/releases')
result['release_directory_names']=[p.name for p in release.iterdir()] if release.exists() else []
result['current_port_source_files']=[]
result['credential_file_metadata']=[]
for root in (release,Path('/opt/rag-p7-r1/state')):
    if not root.exists():continue
    for folder,dirs,files in os.walk(root):
        depth=len(Path(folder).relative_to(root).parts)
        dirs[:]=[d for d in dirs if d not in ('.git','venv','.venv','site-packages','node_modules','__pycache__') and depth<6]
        for name in files:
            path=Path(folder)/name
            if 'weknora_port' in path.parts and name in ('development.py','runtime.py','rerank.py','001_retrieval.sql'):
                result['current_port_source_files'].append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
            # Return filenames/permissions/nonempty only. Never read credentials.
            if any(word in name.lower() for word in ('secret','credential','provider-key','owner-key','api-key')) and path.stat().st_size<65536:
                result['credential_file_metadata'].append({'path':str(path),'nonempty':path.stat().st_size>0,'mode':oct(path.stat().st_mode&0o777),'read_contents':False})
result['six_archives']=[]
for path in Path('/opt/rag-p7-r1/incoming/v6-attempt3-ocr-layout-setup-r3').glob('*.zip'):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    row={'path':str(path),'bytes':path.stat().st_size,'sha256':h.hexdigest()}
    with zipfile.ZipFile(path) as z:
        row['entries']=len(z.infolist());row['uncompressed_bytes']=sum(i.file_size for i in z.infolist());row['all_members_listing_only_no_extract']=True
    result['six_archives'].append(row)
socket=Path('/opt/rag-p7-r1/state/streams-r1/redis.sock')
result['historical_redis_socket']={'path':str(socket),'exists':socket.exists(),'is_socket':socket.is_socket()}
print(json.dumps(result,ensure_ascii=False))
