"""Zero-network same-wire check of S8 A versus S7 Graph A, six saved responses."""
import asyncio,hashlib,importlib.util,json,socket,subprocess,sys,types
from pathlib import Path
from types import SimpleNamespace
from copy import deepcopy
ROOT=Path('E:/RAG-Worktrees/s8-six-dataset-evaluation')
sys.path.insert(0,str(ROOT))
from backend.weknora_port.retrieval.rerank import rerank
from backend.weknora_port.models.types import CallContext,TrustedScope,RerankResponse,RerankResult
from backend.weknora_port.retrieval.pipeline import PipelineState
from backend.weknora_port.retrieval.search import SearchTarget,SearchNothing
from backend.weknora_port.retrieval.query import default_segmenter
text=subprocess.check_output(['git','show','b9268e2d6707f73c48b5624a96e39879d02ce12c:backend/weknora_port/retrieval/rerank.py'],cwd=ROOT)
baseline=types.ModuleType('backend.weknora_port.retrieval._saved_s7_a')
baseline.__package__='backend.weknora_port.retrieval';exec(compile(text,'S7_GRAPH_A', 'exec'),baseline.__dict__)
spec=importlib.util.spec_from_file_location('saved_case_loader','E:/RAG-Worktrees/rerank-top1-experiment/scripts/rerank_top1_fallback_ab.py')
loader=importlib.util.module_from_spec(spec);spec.loader.exec_module(loader)
files={}
def read(path):
    path=Path(path);files[str(path)]=hashlib.sha256(path.read_bytes()).hexdigest()
    return json.loads(path.read_text(encoding='utf-8-sig'))
def blocked(*args,**kwargs):raise RuntimeError('OFFLINE_NETWORK_FORBIDDEN')
args=SimpleNamespace(p33=Path('E:/WK/run/s1-0434-section-20261019/real-check'),
    s1=Path('E:/WK/run/s1-rerank-input-20261019'),quote_plan=Path('E:/WK/run/m4-s1-20261018/replay_plan.json'))
cases=loader.load_cases(args,read)
async def check(case,function,floorless=False):
    state=PipelineState(query=case['question'],rewrite_query=case['query'],
        targets=(SearchTarget(case['kb_id']),),search_results=deepcopy(case['rows']),
        rerank_model_id='SAVED_ONLY',rerank_threshold=.3,rerank_top_k=case['topk'],
        rerank_context_enabled=case['with_context'],rerank_top1_floorless=floorless)
    calls=0
    class SavedModel:
        async def rerank(self,query,documents,context):
            nonlocal calls;calls+=1
            assert query==case['wire']['body']['query'] and documents==case['wire']['body']['documents']
            return RerankResponse(tuple(RerankResult(r['index'],r['relevance_score']) for r in case['response']['results']))
    class Registry:
        async def rerank(self,*args):return SavedModel()
    try:await function(state,CallContext('OFFLINE_S8_A',TrustedScope(case['owner'],(case['kb_id'],))),Registry(),default_segmenter())
    except SearchNothing:return {'status':'SEARCH_NOTHING','ids':[],'saved_response_playbacks':calls}
    return {'status':'SELECTED','ids':[r.id for r in state.rerank_results],
        'fused_scores':[r.score for r in state.rerank_results],
        'metadata_sha256':[hashlib.sha256(json.dumps(r.metadata,sort_keys=True,ensure_ascii=False).encode()).hexdigest() for r in state.rerank_results],
        'saved_response_playbacks':calls}
async def main():
    # Windows Proactor creates an internal loopback self-pipe before this
    # coroutine begins; block external connections after loop initialization.
    socket.create_connection=blocked;socket.socket.connect=blocked
    rows=[]
    for case in cases:
        old=await check(case,baseline.rerank);new=await check(case,rerank);b=await check(case,rerank,True)
        rows.append({'case_id':case['case_id'],'candidate_count':len(case['rows']),
            'original_sorted_raw_top1':case['response']['results'][0]['relevance_score'],
            'original_A':old,'S8_A':new,'S8_B':b,'A_exact_match':old==new})
    result={'status':'PASS' if all(r['A_exact_match'] for r in rows) else 'FAIL',
        'baseline_commit':'b9268e2d6707f73c48b5624a96e39879d02ce12c',
        'baseline_rerank_sha256':hashlib.sha256(text).hexdigest(),'current_rerank_sha256':hashlib.sha256((ROOT/'backend/weknora_port/retrieval/rerank.py').read_bytes()).hexdigest(),
        'case_count':len(rows),'cases':rows,'source_files':files,'new_provider_calls':0,'database_writes':0,
        'scope':'Saved exact query, ordered passages, response; Rerank/MMR only. No new Search, Merge/Context or answer validation.'}
    out=Path('E:/WK/run/s8-20261019/valid-wire-a-replay.json');out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(result['status'],len(rows),'saved cases; new Provider0; output',out)
    if result['status']!='PASS':raise SystemExit(1)
asyncio.run(main())
