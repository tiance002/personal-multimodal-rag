import asyncio,json,sys,hashlib
from pathlib import Path
ROOT=Path('E:/RAG-Worktrees/s8-six-dataset-evaluation');sys.path.insert(0,str(ROOT))
from scripts.local_runtime import load_config,environment,verify_resources
from scripts.s2_generation_quality import identity_for
from backend.weknora_port.development import DevelopmentSettings,assemble
OUT=Path('E:/WK/run/s8-20261019/source-db-versions.json')
async def main():
 assert not OUT.exists()
 cfg=load_config('E:/WK/run/s4-quality-20261019/local.json');identity=await verify_resources(cfg)
 env=environment(cfg,identity['redis_run_id']);env.update(WEKNORA_PORT_CLOUD_ALLOWED='false',WEKNORA_PORT_GRAPH_ENABLED='false')
 for key in ('WEKNORA_PORT_EXECUTION_FILE','WEKNORA_PORT_EVIDENCE_DIR'):env.pop(key,None)
 state=json.loads(Path('E:/WK/run/p25-20261017/runtime/state.json').read_text(encoding='utf-8-sig'))
 env,principal=identity_for(332,env,state)
 async with assemble(DevelopmentSettings.from_environment(env),principal=principal) as app:
  async with app.leases.lease() as guard:
   async with guard.connection.transaction():
    await guard.connection.execute('SET TRANSACTION READ ONLY')
    row=await (await guard.connection.execute("SELECT version() AS server_version,current_database() AS database,(SELECT system_identifier::text FROM pg_control_system()) AS system_identifier,pg_database_size(current_database())::bigint AS database_size_bytes,current_setting('transaction_read_only') AS transaction_read_only,to_regtype('halfvec')::text AS halfvec_type,(SELECT jsonb_agg(jsonb_build_object('name',extname,'version',extversion) ORDER BY extname) FROM pg_extension) AS extensions")).fetchone()
    assert row['system_identifier']==identity['postgres_system_id'] and row['database']==identity['database'] and row['transaction_read_only']=='on'
 result={'schema':'s8-source-db-versions/v1','source':'CURRENT_TRUSTED_LOCAL_DATABASE','provider_calls':0,'database_writes':0,'data':row,'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
 with OUT.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2);stream.write('\n')
 print(json.dumps({'status':'READONLY_SOURCE_VERSION_COMPLETE','data':row,'output':str(OUT)},ensure_ascii=False))
if __name__=='__main__':
 with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner:runner.run(main())
