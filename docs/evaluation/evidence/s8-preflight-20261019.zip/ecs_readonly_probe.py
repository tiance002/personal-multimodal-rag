"""Read-only ECS inventory, streamed on SSH stdin; never installs or starts jobs."""
import json, os, sys, subprocess, shutil, hashlib, urllib.request
from pathlib import Path

def command(args, timeout=12, env=None):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout, env=env)
        return {'exit_code':p.returncode, 'stdout':p.stdout.strip(), 'stderr':p.stderr.strip()[:500]}
    except Exception as e:
        return {'exit_code':None, 'error':type(e).__name__}

base='http://100.100.100.200/latest/'
token=urllib.request.urlopen(urllib.request.Request(base+'api/token',method='PUT',headers={'X-aliyun-ecs-metadata-token-ttl-seconds':'60'}),timeout=3).read().decode()
def metadata(name):
    return urllib.request.urlopen(urllib.request.Request(base+'meta-data/'+name,headers={'X-aliyun-ecs-metadata-token':token}),timeout=3).read().decode()
identity={'instance_id':metadata('instance-id'), 'region':metadata('region-id')}
assert identity == {'instance_id':'i-bp1flliql08bz8yftild','region':'cn-hangzhou'}, 'ECS_IDENTITY_MISMATCH_NO_FURTHER_READS'

result={'schema':'s8-ecs-readonly-inventory/v1','identity':identity,
        'new_provider_calls':0,'uploads':0,'parses':0,'embedding_calls':0,'database_writes':0,'service_changes':0}
result['utc']=command(['date','-u','+%Y-%m-%dT%H:%M:%SZ'])
result['os_release']={line.split('=',1)[0]:line.split('=',1)[1].strip('"') for line in Path('/etc/os-release').read_text().splitlines() if '=' in line and line.split('=',1)[0] in ('ID','VERSION_ID','PRETTY_NAME')}
memory={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in Path('/proc/meminfo').read_text().splitlines() if line.split(':',1)[0] in ('MemTotal','MemAvailable','SwapTotal','SwapFree')}
result['resources']={'cpus':os.cpu_count(),'memory':memory,'root_disk':dict(zip(('total','used','free'),shutil.disk_usage('/'))),'python':sys.version.split()[0]}
result['tools']={name:shutil.which(name) for name in ('git','docker','redis-cli','psql','pg_dump','pg_restore','pg_lsclusters')}
result['ports']=command(['ss','-lnt'])
result['units']=command(['systemctl','list-units','--type=service','--all','--no-legend','--no-pager'])
# Only matching service lines; no process arguments, environment, or credentials.
result['units']['stdout']='\n'.join(line for line in result['units'].get('stdout','').splitlines() if any(s in line.lower() for s in ('rag','weknora','redis','postgres','docker','mineru')))
result['unit_details']={}
for name in ('rag-eval.service','redis-server.service','postgresql.service'):
    result['unit_details'][name]=command(['systemctl','show',name,'--no-pager','--property=ActiveState,SubState,MainPID,User,WorkingDirectory,FragmentPath'])
result['python_processes']=[]
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit(): continue
    try:
        args=(proc/'cmdline').read_bytes().decode(errors='replace').split('\0')
        if not args or not any(s in args[0].lower() for s in ('python','uvicorn','gunicorn','redis-server','postgres')): continue
        row={'pid':int(proc.name),'executable':args[0], 'cwd':str((proc/'cwd').resolve())}
        if '-m' in args and args.index('-m')+1<len(args): row['module']=args[args.index('-m')+1]
        row['weknora_port_argument_present']=any('weknora_port' in a for a in args)
        result['python_processes'].append(row)
    except (OSError,ValueError): pass

def pg(db,sql):
    env=os.environ.copy();env['PGOPTIONS']='-c default_transaction_read_only=on'
    return command(['runuser','-u','postgres','--','psql','-X','-A','-t','-v','ON_ERROR_STOP=1','-d',db,'-c',sql],env=env)
result['postgres']={'databases':pg('postgres',"SELECT json_agg(json_build_object('name',datname,'bytes',pg_database_size(oid))) FROM pg_database WHERE NOT datistemplate"),
    'version':pg('postgres','SHOW server_version'), 'system_identifier':pg('postgres','SELECT system_identifier FROM pg_control_system()'),
    'available_relevant_extensions':pg('postgres',"SELECT json_agg(json_build_object('name',name,'version',default_version)) FROM pg_available_extensions WHERE name IN ('vector','pg_search')"), 'candidate_databases':{}}
try: dbs=json.loads(result['postgres']['databases']['stdout'])
except (KeyError,ValueError,TypeError): dbs=[]
for row in dbs or []:
    db=row['name']
    if not any(s in db.lower() for s in ('rag','weknora')): continue
    entry={'extensions':pg(db,"SELECT json_agg(json_build_object('name',extname,'version',extversion)) FROM pg_extension"),
        'tables':pg(db,"SELECT json_agg(table_name ORDER BY table_name) FROM information_schema.tables WHERE table_schema='public'"),
        'read_only':pg(db,'SHOW transaction_read_only')}
    result['postgres']['candidate_databases'][db]=entry
    try: tables=json.loads(entry['tables']['stdout']) or []
    except (ValueError,KeyError): tables=[]
    if 'knowledge_bases' in tables:
        entry['kb_columns']=pg(db,"SELECT json_agg(column_name) FROM information_schema.columns WHERE table_schema='public' AND table_name='knowledge_bases'")
        # Only IDs in our frozen scope. No unrelated users/documents or secrets.
        ids="'214b8b2f-84f9-4d75-ab79-eccbdcd50ec2','76770fba-17c3-4704-8663-10aa669476ce','7f1d720d-9561-446f-a8cc-6a562c339d23','96a9eebd-ffb2-4bc6-9bea-3ed015845479','b66d8ae4-8cfe-4c9b-86d8-c28cb66ca3ef','f4b6ddb2-c05c-4ece-ba73-c1dad6eea8d7','fd444069-cc1a-42d0-9617-e95fa90b6941'"
        entry['frozen_kb_ids']=pg(db,'SELECT json_agg(id) FROM knowledge_bases WHERE id IN ('+ids+')')
    if 'port_provider_calls' in tables:
        entry['provider_counts']=pg(db,"SELECT json_build_object('total',count(*),'unknown',count(*) FILTER(WHERE outcome='UNKNOWN')) FROM port_provider_calls")

result['redis']={'ping':command(['redis-cli','PING'])}
if result['redis']['ping'].get('stdout')=='PONG':
    for section in ('server','memory','persistence','keyspace'):
        value=command(['redis-cli','INFO',section]);allowed=('redis_version','run_id','tcp_port','used_memory','maxmemory','rdb_last_bgsave_status','aof_enabled')
        value['stdout']='\n'.join(line for line in value.get('stdout','').splitlines() if (':' in line and (line.split(':',1)[0] in allowed or line.startswith('db'))))
        result['redis'][section]=value

roots=[Path(p) for p in ('/opt/rag-p7-r1','/srv/rag-eval','/opt/weknora','/srv/weknora','/opt/personal-rag','/srv/personal-rag','/opt/eviroute-rag')]
result['paths']=[];result['releases']=[];result['data_manifest_files']=[];result['config_presence']=[]
visited=0
for root in roots:
    result['paths'].append({'path':str(root),'exists':root.exists(),'resolved':str(root.resolve())})
    if not root.is_dir():continue
    result['paths'][-1]['children']=[p.name for p in root.iterdir()][:80]
    for folder,dirs,files in os.walk(root):
        depth=len(Path(folder).relative_to(root).parts)
        dirs[:]=[n for n in dirs if n not in ('.git','venv','.venv','site-packages','node_modules','__pycache__','model-cache') and depth<6]
        visited+=len(files)
        if visited>20000: result['scan_truncated']=True;break
        here=Path(folder)
        if '.git' in files or (here/'.git').is_dir():
            result['releases'].append({'path':str(here),'git_head':command(['git','-C',str(here),'rev-parse','HEAD'])})
        for name in files:
            p=here/name
            if name in ('CODE_SHA','VERSION','release.json','manifest.json','qa_cases.json','omni_pages.json','evaluation-plan.json','source_manifest.json','source_manifest_40.json','cohort_dev24.jsonl','gold-all.json','runtime.json') or any(s in name.lower() for s in ('scifact','miracl','longbench','hotpot','omnidoc','mmlong')):
                info={'path':str(p),'bytes':p.stat().st_size}
                if info['bytes']<=32*1024*1024: info['sha256']=hashlib.sha256(p.read_bytes()).hexdigest()
                if name in ('CODE_SHA','VERSION') and info['bytes']<128:
                    raw=p.read_text(errors='replace').strip()
                    if raw and all(c in '0123456789abcdefABCDEF.-v' for c in raw):info['version']=raw
                result['data_manifest_files'].append(info)
            if name in ('.env','runtime.env','runtime.env.example','local.json'):
                # Values never leave this process. Presence is not account authorization.
                raw=p.read_text(errors='replace'); names=[];cloud={}
                if name.endswith('.json'):
                    try: names=list(json.loads(raw))
                    except ValueError: pass
                else:
                    for line in raw.splitlines():
                        if '=' not in line or line.lstrip().startswith('#'):continue
                        key,value=line.split('=',1);key=key.strip();names.append(key)
                        if key in ('WEKNORA_PORT_CLOUD_ALLOWED','RAG_CLOUD_ENABLED') and value.strip().strip('"\'').lower() in ('true','false','0','1'):cloud[key]=value.strip().strip('"\'')
                result['config_presence'].append({'path':str(p),'variable_names':names,'cloud_booleans':cloud,'secret_values_not_read_back':True})
result['scan_scope']='Known approved project roots, depth<=6 and <=20000 files. Not a full-machine or mounted external database census.'
print(json.dumps(result,ensure_ascii=False))
