# S8 Owner Goal — execution scope record (2026-10-19)

This is a faithful condensed working record of the current Owner message; the chat original remains authoritative.

## Scope/order
S8六套数据集全链路评测与分阶段调优。S8.0先零模型请求核实数据/Gold/来源/索引/代码；S8.1代表性全链路试运行；通过后S8.2按完整可评测清单逐批，不把小样本称全量；S8.3完成可比较基线后按错误分布一次只调一主因素。
Six: SciFact, MIRACL-ZH, LongBench-ZH, OmniDocBench, MMLongBench-Doc, HotpotQA.
Use existing frozen packages/questions/Gold/versions. Check exact document/question count, corpus availability, chunk mapping, source identity, indexes, historical full-RAG receipts. No duplicate parsing/indexing. Distinguish full public benchmark vs project frozen subset. Six should use real parse/index/retrieval/context/generation where applicable, not one fabricated common metric.
SciFact retrieval vs support/refute; MIRACL qrels; LongBench task-specific answers; Omni parsing/structure/OCR not official QA; MML longdoc/multimodal fact support; Hotpot any/all hop sources and necessary facts. No generation Gold => no invented official QA accuracy. String equality alone is insufficient.

## Baselines/isolation
S7Graph b9268e2d6707f73c48b5624a96e39879d02ce12c.
S7Top1 4145448003bc008acfa2341ea28c5bd00bb041f7.
New independent evaluation worktree; preserve productionbranch and original18 protectedfiles and oldUNKNOWN. Minimal integration of two candidates into isolated evaluation code allowed, notproductionmerge. Allarmsmust becomparable explicitcode/models/data.
A: GraphOFF, threshold0.3 and Top1 minimum0.15, existing RRF/MMR/Merge/Parent/Child/currentCheapExpensive.
B: GraphOFF, onlyempty-rerank legalTop1 floorless; use A receipts to select actuallytriggeringcases plus successfulregression. NotallnondifferencecasesneedB.
C: originalTop1, GraphON onlyrelatedsubsetwithlegalsources, boundedgraphbuildnotwholecorpus. Track extractionaccepted/rejected, anchor/bridge success, all-hop/factcoverage, extra/noise/wrong relations/generationregressions, buildTokens/retrievaltime. NoGoldbasedruntime.
D: NOT_RUN, requires independent gains+separateOwnerapproval.

## Execution/evidence
Before any freshsend: NEW Ownerauthorization; all oldauthorizationsCLOSED. Currentmessage IS NOT a cloudgrant. Stage0 autonomousoffline only untilfreshapproval. Once planready, request models/batchcount/requestcounts/conservativeTokenbound once. No creator selfsignoff. Use existing Registry, tenant/KB/provider/SendGate/durableusage/UNKNOWN protections. NewUNKNOWN stoprelatedsends,no resend; independentofflineworkmaycontinue.
Every case independent request/session, normalAPI QU/Rewrite->HybridSearch/RRF->Rerank->Merge/Parent/TopK->Context->DYNAMIC->generation/SSE/history. Freeze allinputs; Gold onlyposthoc. Rawrerank vsfusedscores separate. If Rewrite/Search/parameters differ betweenactualarms, call systemregression, notpurecausalAB.
S8.2 batches target<40min, checkpoint/aggregate/resume reusealreadyreceipts; cannot silentlydropQIDs or reducefinalscopebecauseonebatchpassed. UnapprovedfuturebatchNOT_RUN.
Metrics: necessaryfactrecall/Context, irrelevant/noise, applicableofficialmetrics,fullanswerfacts/unsupportedextensions, unanswerableattribution, graphcoverage/bridging, stagelatency, actualin/outTokens, COMPLETE/FAILED/UNKNOWN, improvement/regression/extraexpense.
No全量unconditionalgraph, newgraphalgorithm/framework, PPTprogressivepagework, factjudge, routerrebuild, globalPromptrewrite, ECS, protectionbypass. PreserveS7knownqualitylimits. Onlyconfirmedblockingbugs minimalfix; noqualitytuninginStage0.

## Delivery/stop
Report actualscope BASELINE_READY/PARTIAL/COMPLETE/BLOCKED.
Commitrelatedfileslocally: docs/evaluation/S8_SIX_DATASET_EVALUATION.md and .results.json plusper-batchmachineoutputs.
Mustlistactualfinishedquestionsperdataset,metrics,Top1promotiondecision,Graphstableincrementalgainornot,priorityfixes,modellimits.
NoPush/deploy/dailydefaultswitchchange, noS9. Ownerdecisionbeforepromotion/combinedD.

## Latest Owner steering (supersedes earlier Windows execution assumption)
- First use the existing40 frozen QA plus24 Omni pages. The additional10 mapped QA and existing engineering negative may join only if already source/index/scoring-ready; do not prepare new corpora merely to expand this round.
- Current work is S8.0 only: local data/Gold/index/history verification and offline preparation. No new real QA now.
- ECS is the target of formal S8.1/S8.2. Inspect its actual identity/version/resources/PG/extensions/Redis/model configuration/data first, read-only. Do not run allQA on Windows first.
- Deliver ECS gap list and smallest migration plan with S8.0. No automatic deployment, upload, parsing, index rebuild or new Embedding. Preserve every existing checkpoint and UNKNOWN. Graph and Top1 remain independent. Old grants remain closed; this steering is not a new model-call authorization.
