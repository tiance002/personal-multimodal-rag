import asyncio, json, sys, hashlib, re
from collections import Counter, defaultdict
from pathlib import Path
ROOT=Path('E:/RAG-Worktrees/s8-six-dataset-evaluation');sys.path.insert(0,str(ROOT))
from scripts.local_runtime import load_config,environment,verify_resources
from scripts.s2_generation_quality import identity_for
from backend.weknora_port.development import DevelopmentSettings,assemble
from backend.weknora_port.storage.postgres import RetrieveParams
RUN=Path('E:/WK/run/s8-20261019')
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda b:hashlib.sha256(b.encode('utf-8') if isinstance(b,str) else b).hexdigest()
SEARCHABLE={'text','summary','table_column','table_summary','faq','image_ocr','image_caption'}

def jsonobj(value):
    if isinstance(value,dict):return value
    if isinstance(value,str):
        try:return json.loads(value)
        except ValueError:return {}
    return {}

async def main():
    output=RUN/'index-integrity.json';assert not output.exists()
    qa=read('E:/WK/run/m4-full-sweep-20261018/qa_cases.json')
    omni=read('E:/WK/run/m4-full-sweep-20261018/omni_pages.json')
    kbs=sorted({row['knowledge_base_id'] for row in qa+omni});assert len(qa)==40 and len(omni)==24 and len(kbs)==7
    cfg=load_config('E:/WK/run/s4-quality-20261019/local.json');identity=await verify_resources(cfg)
    env=environment(cfg,identity['redis_run_id']);env.update(WEKNORA_PORT_CLOUD_ALLOWED='false',WEKNORA_PORT_GRAPH_ENABLED='false')
    for key in ('WEKNORA_PORT_EXECUTION_FILE','WEKNORA_PORT_EVIDENCE_DIR'):env.pop(key,None)
    env,principal=identity_for(332,env,read('E:/WK/run/p25-20261017/runtime/state.json'))
    async with assemble(DevelopmentSettings.from_environment(env),principal=principal) as app:
      async with app.leases.lease() as guard:
       async with guard.connection.transaction():
        await guard.connection.execute('SET TRANSACTION READ ONLY')
        async def q(sql,args=()):return await (await guard.connection.execute(sql,args)).fetchall()
        ro=(await q('SHOW transaction_read_only'))[0]['transaction_read_only'];assert ro=='on'
        before=(await q("SELECT count(*) AS count,count(*) FILTER(WHERE outcome='UNKNOWN') AS unknown FROM port_provider_calls"))[0]
        columns=await q("SELECT table_name,column_name,data_type,udt_name FROM information_schema.columns WHERE table_schema='public' AND table_name=ANY(%s) ORDER BY table_name,ordinal_position",(['embeddings','chunks','knowledges','knowledge_bases'],))
        bytable=defaultdict(set)
        for row in columns:bytable[row['table_name']].add(row['column_name'])
        for table,required in {'embeddings':{'id','source_id','source_type','chunk_id','knowledge_id','knowledge_base_id','content','dimension','embedding','is_enabled'},'chunks':{'id','tenant_id','knowledge_id','knowledge_base_id','chunk_type','content','metadata','index_status','is_enabled','deleted_at'},'knowledges':{'id','tenant_id','knowledge_base_id','metadata','file_name','file_hash','parse_status','enable_status','deleted_at'}}.items():
            assert required<=bytable[table], 'ACTUAL_SCHEMA_CONTRACT_MISMATCH:'+table
        kbrows=await q('SELECT id,tenant_id,cloud_allowed,deleted_at FROM knowledge_bases WHERE id=ANY(%s)',(kbs,));assert len(kbrows)==7 and all(r['tenant_id']==332 and r['deleted_at'] is None for r in kbrows)
        docs=await q("SELECT id,tenant_id,knowledge_base_id,file_name,file_hash,metadata->>'source_version' AS source_version,parse_status,enable_status,deleted_at FROM knowledges WHERE tenant_id=332 AND knowledge_base_id=ANY(%s)",(kbs,));docmap={r['id']:r for r in docs}
        chunks=await q('SELECT id,tenant_id,knowledge_id,knowledge_base_id,chunk_type,chunk_index,content,context_header,parent_chunk_id,index_status,is_enabled,deleted_at,metadata FROM chunks WHERE tenant_id=332 AND knowledge_base_id=ANY(%s)',(kbs,));chunkmap={r['id']:r for r in chunks}
        indexes=await q("SELECT e.id,e.source_id,e.source_type,e.chunk_id,e.knowledge_id,e.knowledge_base_id,e.content,e.dimension,e.embedding IS NOT NULL AS embedding_present,e.is_enabled,CASE WHEN e.embedding IS NOT NULL THEN 1+length(e.embedding::text)-length(replace(e.embedding::text,',','')) END AS actual_vector_dimension,c.id AS joined_chunk_id,c.tenant_id AS joined_chunk_tenant,c.knowledge_id AS joined_chunk_document,c.knowledge_base_id AS joined_chunk_kb,c.deleted_at AS joined_chunk_deleted,k.tenant_id AS joined_document_tenant,k.knowledge_base_id AS joined_document_kb,k.deleted_at AS joined_document_deleted FROM embeddings e LEFT JOIN chunks c ON c.id=e.chunk_id LEFT JOIN knowledges k ON k.id=e.knowledge_id WHERE e.knowledge_base_id=ANY(%s) OR e.chunk_id=ANY(%s) ORDER BY e.knowledge_base_id,e.id",(kbs,list(chunkmap)))
        pgindexes=await q("SELECT t.relname AS table_name,i.relname AS index_name,am.amname AS access_method,x.indisvalid,x.indisready,pg_get_indexdef(i.oid) AS definition FROM pg_index x JOIN pg_class t ON t.oid=x.indrelid JOIN pg_class i ON i.oid=x.indexrelid JOIN pg_am am ON am.oid=i.relam WHERE t.relname='embeddings' ORDER BY i.relname")
        results=[]
        for kb in kbs:
            livechunks=[r for r in chunks if r['knowledge_base_id']==kb and r['deleted_at'] is None]
            indexed=[r for r in indexes if r['knowledge_base_id']==kb or r['chunk_id'] in {c['id'] for c in livechunks}]
            bychunk=defaultdict(list);bysource=defaultdict(list)
            for row in indexed:bychunk[row['chunk_id']].append(row['id']);bysource[(row['source_id'],row['source_type'])].append(row['id'])
            issues=defaultdict(list);proofs=[]
            for row in indexed:
                c=chunkmap.get(row['chunk_id']);d=docmap.get(row['knowledge_id']);flags=[]
                if row['joined_chunk_id'] is None:flags.append('ORPHAN_CHUNK_ID')
                if row['joined_document_tenant'] is None:flags.append('ORPHAN_DOCUMENT_ID')
                if row['joined_chunk_id'] and (row['joined_chunk_tenant']!=332 or row['joined_chunk_document']!=row['knowledge_id'] or row['joined_chunk_kb']!=row['knowledge_base_id']):flags.append('CHUNK_TENANT_DOCUMENT_KB_MISMATCH')
                if row['joined_document_tenant'] is not None and (row['joined_document_tenant']!=332 or row['joined_document_kb']!=row['knowledge_base_id']):flags.append('DOCUMENT_TENANT_KB_MISMATCH')
                if row['source_type']==0 and row['source_id']!=row['chunk_id']:flags.append('SOURCE_CHUNK_ID_MISMATCH_TYPE0')
                if row['joined_chunk_deleted'] is not None or row['joined_document_deleted'] is not None:flags.append('DELETED_SOURCE_STILL_INDEXED')
                if not row['embedding_present']:flags.append('VECTOR_NULL')
                if row['embedding_present'] and (row['dimension']!=1024 or row['actual_vector_dimension']!=row['dimension']):flags.append('VECTOR_DIMENSION_MISMATCH')
                if row['is_enabled'] is False:flags.append('INDEX_DISABLED')
                if c and (not c['is_enabled'] or c['index_status'] in ('processing','failed')):flags.append('CHUNK_NOT_SEARCHABLE')
                if d and (d['enable_status']!='enabled' or d['parse_status']!='completed'):flags.append('DOCUMENT_NOT_SEARCHABLE')
                if not row['content'] or not row['content'].strip():flags.append('KEYWORD_CONTENT_EMPTY')
                metadata=jsonobj(c['metadata']) if c else {};version=metadata.get('source_version')
                if c and d and c['chunk_type']!='summary' and version!=d['source_version']:flags.append('RAW_SOURCE_VERSION_MISMATCH')
                body=(c['content'] or '').strip() if c else ''
                body_present=bool(body) and body in (row['content'] or '')
                if c and body and not body_present:flags.append('CHUNK_BODY_NOT_IN_INDEX_CONTENT')
                for flag in flags:issues[flag].append(row['id'])
                proofs.append({key:row[key] for key in ('id','source_id','source_type','chunk_id','knowledge_id','knowledge_base_id','dimension','actual_vector_dimension','embedding_present','is_enabled')}|{'chunk_type':c['chunk_type'] if c else None,'parent_chunk_id':c.get('parent_chunk_id') if c else None,'chunk_source_version':version,'document_source_version':d['source_version'] if d else None,'summary_version_semantics':'MODEL_GENERATED; absent chunk version is not raw-source proof' if c and c['chunk_type']=='summary' else None,'index_content_sha256':sha(row['content'] or ''),'chunk_content_sha256':sha(c['content'] or '') if c else None,'chunk_body_present_in_keyword_index_content':body_present,'issues':flags})
            expected=[c for c in livechunks if c['is_enabled'] and c['chunk_type'] in SEARCHABLE and c['index_status'] not in ('processing','failed') and docmap.get(c['knowledge_id'],{}).get('parse_status')=='completed' and docmap.get(c['knowledge_id'],{}).get('enable_status')=='enabled']
            missing=[c['id'] for c in expected if c['id'] not in bychunk]
            duplicate_chunks={key:ids for key,ids in bychunk.items() if len(ids)>1};duplicate_sources={str(key):ids for key,ids in bysource.items() if len(ids)>1}
            seed=next((r for r in indexed if r['is_enabled'] is not False and r['content'] and re.search(r'[A-Za-z]{4,}',r['content'])),None)
            probe={'status':'NOT_RUN_NO_SAFE_ASCII_TERM','meaning':'One real BM25 operator smoke per KB; not all-row semantic recall'}
            if seed:
                token=max(re.findall(r'[A-Za-z]{4,}',seed['content']),key=len)[:48]
                try:
                    async with guard.connection.transaction():
                        hits=await guard.keywords(RetrieveParams((kb,),query=token,top_k=5,threshold=0))
                    probe={'status':'PASS' if hits else 'NO_HITS','query_term':token,'seed_index_id':seed['id'],'returned_index_ids':[r['id'] for r in hits],'returned_chunk_ids':[r['chunk_id'] for r in hits],'meaning':'Actual formal keyword_statement and ParadeDB operator; term from indexed content, no model/Gold; no all-row recall claim'}
                except Exception as exc:
                    probe={'status':'FAILED','error_type':type(exc).__name__,'meaning':'Raw error omitted to avoid connection details; failed probe retained, no retry'}
            results.append({'knowledge_base_id':kb,'current_documents':sum(r['knowledge_base_id']==kb and r['deleted_at'] is None for r in docs),'live_chunks':len(livechunks),'expected_searchable_chunks':len(expected),'index_rows':len(indexed),'indexed_chunk_type_counts':dict(Counter(p['chunk_type'] for p in proofs)),'missing_chunk_index_ids':missing,'duplicate_chunk_index_groups':duplicate_chunks,'duplicate_source_identity_groups':duplicate_sources,'issue_counts':{key:len(ids) for key,ids in issues.items()},'issues':dict(issues),'keyword_probe':probe,'rows':proofs,'child_only_claim':'NOT_CLAIMED; actual indexed chunk types including historical Summary retained'})
        after=(await q("SELECT count(*) AS count,count(*) FILTER(WHERE outcome='UNKNOWN') AS unknown FROM port_provider_calls"))[0];assert before==after
    result={'schema':'s8-index-row-integrity/v1','source_head':__import__('subprocess').check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'scope':{'tenant_id':332,'frozen_QIDs':40,'Omni_pages':24,'knowledge_base_ids':kbs},'transaction_read_only':ro,'database_writes':0,'new_provider_calls':0,'provider_before':before,'provider_after':after,'schema_columns':columns,'actual_embedding_indexes':pgindexes,'source_code_proof':{str(ROOT/p):sha((ROOT/p).read_bytes()) for p in ['backend/weknora_port/storage/postgres.py','backend/weknora_port/storage/knowledge.py','backend/weknora_port/storage/chunks.py','backend/weknora_port/storage/indexing.py','backend/weknora_port/storage/hybrid.py']},'inputs':{str(p):sha(Path(p).read_bytes()) for p in [Path(__file__),'E:/WK/run/m4-full-sweep-20261018/qa_cases.json','E:/WK/run/m4-full-sweep-20261018/omni_pages.json']},'knowledge_bases':results,'metric_limits':['Identity/dimension/content/index smoke only, not semantic fact completeness','Summary is derived, no raw-veracity or Child-only assertion','BM25 per-KB probe is not each-row retrieval or recall evaluation']}
    with output.open('x',encoding='utf-8') as stream:json.dump(result,stream,ensure_ascii=False,indent=2,default=str);stream.write('\n')
    print(json.dumps({'status':'READONLY_INDEX_AUDIT_COMPLETE','knowledge_bases':[{'id':r['knowledge_base_id'],'rows':r['index_rows'],'missing':len(r['missing_chunk_index_ids']),'duplicates':len(r['duplicate_chunk_index_groups']),'issues':r['issue_counts'],'keyword_probe':r['keyword_probe']['status']} for r in results],'provider_unchanged':before==after,'output':str(output)},ensure_ascii=False))
if __name__=='__main__':
    with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner:runner.run(main())
