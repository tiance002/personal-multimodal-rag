"""Only the still-unsubmitted S6 API question; no upload or extraction call."""
import asyncio
import json
from pathlib import Path
import sys
import time
from types import SimpleNamespace
import uuid

ROOT = Path('E:/RAG-Worktrees/weknora-python-port-20261013')
sys.path.insert(0, str(ROOT))
from scripts import s6_graph_acceptance as helper
from scripts.local_runtime import load_config, environment, verify_resources
from backend.weknora_port.development import DevelopmentSettings, assemble

RUN = Path('E:/WK/run/s6-graphrag-20261019')
OUT = RUN / 'acceptance-api-fixed'
AUTH = RUN / 'owner-authorization.json'
PRIOR = [RUN / 'acceptance-origin-fixed/phase1/execution.json', RUN / 'acceptance-deepseek/execution.json']
DOCS = ('4d35e306-4a19-470b-bf68-93731539439d', '734d37f7-40bc-4b75-a44b-e7ce30562c0f')


async def main():
    import httpx
    g = helper.read(AUTH)
    assert g['status'] == 'CLOSED' and g['owner_approved'] is True
    assert g['continuation_authorization']['human_answer'] == '批准上述 DeepSeek 图抽取及剩余验收'
    prior = helper.require_settled(PRIOR)
    assert prior['calls'] == 10 and prior['reported_tokens'] == 5719
    assert helper.read(RUN / 'acceptance-deepseek/source-quote-replay.json')['status'] == 'SOURCE_PROOF_REPLAY_AND_REAL_PG_PATH_PASS'
    for directory in ('acceptance', 'acceptance-origin-fixed', 'acceptance-deepseek'):
        assert not (RUN / directory / 'question.claim.json').exists()
    proof = helper.read(RUN / 'acceptance-api/zero-send-contract-proof.json')
    assert proof['status'] == 'ZERO_SEND_CONTRACT_FAILURE_CONFIRMED' and proof['provider_calls'] == 0
    assert not proof['accepted_turns'] and not proof['messages']
    assert helper.require_settled([RUN / 'acceptance-api/execution.json'])['calls'] == 0
    assert helper.port_is_free()
    OUT.mkdir(exist_ok=False)
    helper.write_new(OUT / 'grant-before.json', g)
    g.update(status='OPEN', unsubmitted_api_continuation={'reason': 'Same real DeepSeek response source-proof replay restored one literal quote; no new extraction and no prior question submission', 'prior_calls': 10, 'prior_reported_tokens': 5719, 'additional_authorized_question': 0, 'still_approved_question': 1, 'original_upper_limits_unchanged': True})
    g['admission_contract_recovery'] = {'proof': 'acceptance-api/zero-send-contract-proof.json', 'previous_client_request_length': 45, 'formal_repository_limit': 36, 'previous_turn_admitted': False, 'previous_provider_calls': 0, 'reason': 'Fix ordinary local tool request ID contract before the one still-approved logical question is admitted', 'additional_calls_authorized': 0, 'additional_tokens_authorized': 0, 'no_unknown_resend': True}
    g.pop('unused_space_revoked', None)
    helper.save(AUTH, g)
    cfg = load_config('E:/WK/run/s4-quality-20261019/local.json')
    identity = await verify_resources(cfg)
    env = environment(cfg, identity['redis_run_id'])
    env.pop('WEKNORA_PORT_EXECUTION_FILE', None); env.pop('WEKNORA_PORT_EVIDENCE_DIR', None)
    env['WEKNORA_PORT_CLOUD_ALLOWED'] = 'false'
    prepared = helper.read(RUN / 'acceptance-origin-fixed/preflight.json')
    async with assemble(DevelopmentSettings.from_environment(env)) as app:
        principal = app.principal
        assert principal.tenant_id == 1 and helper.digest(principal.subject_id.encode()) == prepared['subject_sha256']
    before = await helper.snapshot(env, DOCS)
    helper.write_new(OUT / 'before.json', before)
    ledger = OUT / 'execution.json'
    fence = helper.make_ledger(principal, prepared['models'], 2)
    assert fence['max_calls'] + prior['calls'] <= 20
    assert fence['max_tokens'] + prior['held_tokens'] <= 200000
    helper.write_new(ledger, fence)
    live_env = helper.phase_environment(cfg, env, ledger, OUT / 'local.json')
    process = None
    result = {'status': 'STARTED', 'new_uploads': 0, 'new_extractions': 0, 'question': helper.QUESTION}
    base = f'http://127.0.0.1:{helper.PORT}'
    try:
        process = await helper.start_api(SimpleNamespace(output=OUT), live_env, 4)
        async with httpx.AsyncClient(headers=helper.business_headers(cfg), timeout=httpx.Timeout(600, connect=5), trust_env=False) as client:
            consent = await client.patch(base + f'/api/v1/knowledge-bases/{helper.KB}/external-processing', json={'cloud_allowed': True})
            consent.raise_for_status(); helper.write_new(OUT / 'consent-open.json', consent.json())
            sid = helper.read(RUN / 'acceptance-api/question.claim.json')['session_id']
            existing = await client.get(base + f'/api/v1/sessions/{sid}/messages')
            existing.raise_for_status()
            assert existing.json()['data'] == []
            body = {'content': helper.QUESTION, 'request_id': str(uuid.uuid4()), 'mode': 'quick', 'knowledge_base_scope': [helper.KB], 'document_scope': [], 'reasoning_effort': 'off'}
            helper.write_new(OUT / 'question.claim.json', {'session_id': sid, 'body': body})
            began = time.monotonic()
            with (OUT / 'question.sse').open('xb') as output:
                async with client.stream('POST', base + f'/api/v1/sessions/{sid}/messages', json=body) as response:
                    helper.write_new(OUT / 'question.http.json', {'status_code': response.status_code, 'content_type': response.headers.get('content-type', '')})
                    if response.status_code >= 400:
                        (OUT / 'question.error.body').write_bytes(await response.aread())
                    response.raise_for_status()
                    async for block in response.aiter_bytes():
                        output.write(block); output.flush()
            result.update(session_id=sid, request_id=body['request_id'], question_seconds=time.monotonic()-began)
            helper.require_settled([ledger])
            count = helper.ledger_summary([ledger])['calls']
            history = []
            for index in range(2):
                response = await client.get(base + f'/api/v1/sessions/{sid}/messages')
                response.raise_for_status(); history.append(response.json())
                helper.write_new(OUT / f'history-{index}.json', history[-1])
            assert helper.same_history(history[0], history[1])
            assert helper.ledger_summary([ledger])['calls'] == count
            result['history_equal_without_new_call'] = True
            after = await helper.snapshot(env, DOCS)
            helper.write_new(OUT / 'after.json', after)
            old = {v['call_id']:v['fingerprint'] for v in before['all_call_fingerprints']}
            now = {v['call_id']:v['fingerprint'] for v in after['all_call_fingerprints']}
            assert all(now.get(k)==v for k,v in old.items())
            assert before['configuration']==after['configuration']
            assert before['chunks']==after['chunks'] and before['vectors']==after['vectors']
            result.update(status='EXECUTED_REQUIRES_EVIDENCE_REVIEW', historical_calls_unchanged=True, roles_chunks_vectors_unchanged=True)
    except BaseException as error:
        result.update(status='INCOMPLETE_STOP', first_failure={'type':type(error).__name__, 'code':str(error) if isinstance(error,(ValueError,AssertionError)) else 'SEE_SAVED_EVIDENCE'})
        raise
    finally:
        summary = helper.ledger_summary([ledger])
        if summary['inflight']: helper.stop_admission(ledger)
        if process is not None:
            try:
                async with httpx.AsyncClient(headers=helper.business_headers(cfg),timeout=5,trust_env=False) as client:
                    response=await client.patch(base+f'/api/v1/knowledge-bases/{helper.KB}/external-processing',json={'cloud_allowed':False})
                    response.raise_for_status(); helper.write_new(OUT/'consent-closed.json',response.json())
            except Exception: result['consent_close_status']='UNCONFIRMED_OWNER_ACTION_REQUIRED'
            if not summary['inflight']: await helper.stop_api(process,ledger)
            else: result['process_kept_alive_due_inflight']=process.pid
        if not summary['inflight']: helper.close_ledger(ledger)
        result['usage']=summary
        grant=helper.read(AUTH)
        grant.update(status='STOP' if summary['unsettled'] else 'CLOSED',actual_calls=10+summary['calls'],actual_reported_tokens=5719+summary['reported_tokens'],held_tokens=5719+summary['held_tokens'],unknown=summary['unknown'],unused_space_revoked=True)
        assert grant['actual_calls']<=20 and grant['held_tokens']<=200000
        helper.save(AUTH,grant); helper.save(OUT/'results.json',result)
        print(json.dumps({'status':result['status'],'total_calls':grant['actual_calls'],'total_tokens':grant['actual_reported_tokens'],'unknown':grant['unknown'],'question_seconds':result.get('question_seconds')}),flush=True)


if __name__=='__main__':
    try:
        with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner: runner.run(main())
    except Exception as error:
        print(json.dumps({'exception_type':type(error).__name__,'code':str(error) if isinstance(error,(AssertionError,ValueError)) else 'SEE_SAVED_EVIDENCE'}))
        raise SystemExit(2)
