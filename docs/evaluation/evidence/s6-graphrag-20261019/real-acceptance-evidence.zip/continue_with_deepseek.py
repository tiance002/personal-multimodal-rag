"""Single Owner-approved continuation: no upload and no old-operation replay."""
import asyncio
from dataclasses import asdict
import json
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
import uuid

ROOT = Path('E:/RAG-Worktrees/weknora-python-port-20261013')
sys.path.insert(0, str(ROOT))
from scripts import s6_graph_acceptance as helper
from scripts.local_runtime import load_config, environment, verify_resources

RUN = Path('E:/WK/run/s6-graphrag-20261019')
OUT = RUN / 'acceptance-deepseek'
AUTH = RUN / 'owner-authorization.json'
OLD = RUN / 'acceptance-origin-fixed'
DOCS = ('4d35e306-4a19-470b-bf68-93731539439d', '734d37f7-40bc-4b75-a44b-e7ce30562c0f')


async def main():
    import httpx
    from backend.weknora_port.development import DevelopmentSettings, assemble
    from backend.weknora_port.models.types import CallContext, TrustedScope
    from backend.weknora_port.storage.graph import PostgresGraphRepository
    from backend.weknora_port.graph.retrieval import find_paths
    grant = helper.read(AUTH)
    helper.validate_authorization(grant, helper.digest((RUN / 'text-sources.json').read_bytes()))
    addition = grant['continuation_authorization']
    assert addition['human_answer'] == '批准上述 DeepSeek 图抽取及剩余验收'
    assert addition['already_used_calls'] == 8 and addition['already_used_tokens'] == 3484
    old = helper.require_settled([OLD / 'phase1/execution.json'])
    assert old['calls'] == 8 and old['reported_tokens'] == 3484
    assert helper.read(OLD / 'phase1/execution.json')['status'] == 'CLOSED'
    assert helper.port_is_free(), 'Stop only the recorded daily API first'
    OUT.mkdir(exist_ok=False)
    prepared = helper.read(OLD / 'preflight.json')
    cfg = load_config('E:/WK/run/s4-quality-20261019/local.json')
    assert helper.digest(Path('E:/WK/run/s4-quality-20261019/local.json').read_bytes()) == prepared['config_sha256']
    identity = await verify_resources(cfg)
    env = environment(cfg, identity['redis_run_id'])
    env.pop('WEKNORA_PORT_EVIDENCE_DIR', None)
    env.pop('WEKNORA_PORT_EXECUTION_FILE', None)
    env['WEKNORA_PORT_CLOUD_ALLOWED'] = 'false'
    async with assemble(DevelopmentSettings.from_environment(env)) as app:
        principal = app.principal
        assert principal.tenant_id == 1 and helper.digest(principal.subject_id.encode()) == prepared['subject_sha256']
    before = await helper.snapshot(env, DOCS)
    sources = helper.read(RUN / 'text-sources.json')['sources']
    by_id = {d['id']: d for d in before['documents']}
    for index, doc in enumerate(DOCS):
        source = helper.read(OLD / f'graph-{index}.json')
        assert by_id[doc]['file_hash'] == sources[index]['sha256']
        assert by_id[doc]['metadata']['source_version'] == source['source_version']
        assert by_id[doc]['parse_status'] == 'completed'
    helper.write_new(OUT / 'before.json', before)
    ledger = OUT / 'execution.json'
    fence = helper.make_ledger(principal, prepared['models'], 1)
    fence['scope'] = 'S6_20261019_DEEPSEEK_ADDENDUM'
    assert fence['max_calls'] + old['calls'] == 20
    assert fence['max_tokens'] + old['held_tokens'] <= 200000
    helper.write_new(ledger, fence)
    live_env = helper.phase_environment(cfg, env, ledger, OUT / 'local.json')
    args = SimpleNamespace(output=OUT)
    process = None
    result = {'status': 'STARTED', 'old_calls': 8, 'old_tokens': 3484, 'no_upload': True, 'documents': DOCS}
    base = f'http://127.0.0.1:{helper.PORT}'
    try:
        process = await helper.start_api(args, live_env, 3)
        async with httpx.AsyncClient(headers=helper.business_headers(cfg), timeout=httpx.Timeout(600, connect=5), trust_env=False) as client:
            consent = await client.patch(base + f'/api/v1/knowledge-bases/{helper.KB}/external-processing', json={'cloud_allowed': True})
            consent.raise_for_status()
            helper.write_new(OUT / 'consent-open.json', consent.json())
            for index, doc in enumerate(DOCS):
                helper.require_settled([ledger])
                command = [sys.executable, '-B', '-m', 'backend.weknora_port.graph_cli', '--config', str(OUT / 'local.json'),
                           '--output', str(OUT / f'graph-{index}.json'), 'index', '--kb', helper.KB, '--document', doc,
                           '--model-id', prepared['role_ids']['expensive'], '--request-id', 's6-deepseek-graph-' + uuid.uuid4().hex]
                response = await asyncio.to_thread(subprocess.run, command, cwd=ROOT, env=live_env, capture_output=True, text=True)
                helper.write_new(OUT / f'graph-{index}.command.json', {'command': command, 'exit_code': response.returncode, 'stdout': response.stdout, 'stderr': response.stderr})
                helper.require_settled([ledger])
                assert response.returncode == 0, 'DEEPSEEK_GRAPH_FAILED_NO_RETRY'
                graph = helper.read(OUT / f'graph-{index}.json')
                print(json.dumps({'step': 'graph', 'document': doc, 'status': graph['status'], 'nodes': graph['nodes'], 'edges': graph['edges'], 'tokens': graph['reported_tokens']}), flush=True)
            async with assemble(DevelopmentSettings.from_environment(env)) as app:
                async def tenant(owner):
                    assert owner == principal.subject_id
                    return principal.tenant_id
                context = CallContext('s6-deepseek-read-only-path', TrustedScope(principal.subject_id, (helper.KB,), ()))
                async with app.leases.lease() as guard:
                    batches = await PostgresGraphRepository(guard, tenant).load_graph(context)
                paths = find_paths(helper.QUESTION, batches, context, tenant_id=principal.tenant_id)
                helper.write_new(OUT / 'graph-paths.json', {'batches': [asdict(b) for b in batches], 'paths': [asdict(p) for p in paths]})
                assert any(len(p.edges) == 2 and len({s.document_id for s in p.sources}) == 2 for p in paths), 'NO_REAL_TWO_DOCUMENT_PATH_NO_QUESTION_SENT'
            session = await client.post(base + '/api/v1/sessions', json={'title': 'S6 actual two-hop graph acceptance', 'knowledge_base_scope': [helper.KB], 'document_scope': []})
            session.raise_for_status()
            sid = session.json()['data']['id']
            body = {'content': helper.QUESTION, 'request_id': 's6-deepseek-answer-' + uuid.uuid4().hex, 'mode': 'quick', 'knowledge_base_scope': [helper.KB], 'document_scope': [], 'reasoning_effort': 'off'}
            helper.write_new(OUT / 'question.claim.json', {'session_id': sid, 'body': body})
            began = time.monotonic()
            with (OUT / 'question.sse').open('xb') as output:
                async with client.stream('POST', base + f'/api/v1/sessions/{sid}/messages', json=body) as response:
                    response.raise_for_status()
                    async for block in response.aiter_bytes():
                        output.write(block); output.flush()
            helper.require_settled([ledger])
            before_reads = helper.ledger_summary([ledger])['calls']
            history = []
            for index in range(2):
                response = await client.get(base + f'/api/v1/sessions/{sid}/messages')
                response.raise_for_status(); history.append(response.json())
                helper.write_new(OUT / f'history-{index}.json', history[-1])
            assert history[0] == history[1] and helper.ledger_summary([ledger])['calls'] == before_reads
            result.update(session_id=sid, request_id=body['request_id'], question_seconds=time.monotonic() - began, history_unchanged_no_new_call=True)
            after = await helper.snapshot(env, DOCS)
            helper.write_new(OUT / 'after.json', after)
            old_calls = {v['call_id']: v['fingerprint'] for v in before['all_call_fingerprints']}
            new_calls = {v['call_id']: v['fingerprint'] for v in after['all_call_fingerprints']}
            assert all(new_calls.get(k) == v for k, v in old_calls.items())
            assert before['configuration'] == after['configuration']
            assert before['chunks'] == after['chunks'] and before['vectors'] == after['vectors']
            result.update(status='EXECUTED_REQUIRES_EVIDENCE_REVIEW', historical_calls_unchanged=True, default_roles_unchanged=True, chunks_and_vectors_unchanged=True)
    except BaseException as error:
        result.update(status='INCOMPLETE_STOP', first_failure={'type': type(error).__name__, 'code': str(error) if isinstance(error, (ValueError, AssertionError)) else 'SEE_SAVED_EVIDENCE'})
        raise
    finally:
        summary = helper.ledger_summary([ledger])
        if summary['inflight']:
            helper.stop_admission(ledger)
        if process is not None:
            try:
                async with httpx.AsyncClient(headers=helper.business_headers(cfg), timeout=5, trust_env=False) as client:
                    response = await client.patch(base + f'/api/v1/knowledge-bases/{helper.KB}/external-processing', json={'cloud_allowed': False})
                    response.raise_for_status()
                    helper.write_new(OUT / 'consent-closed.json', response.json())
            except Exception:
                result['consent_close_status'] = 'UNCONFIRMED_OWNER_ACTION_REQUIRED'
            if not summary['inflight']:
                await helper.stop_api(process, ledger)
            else:
                result['process_kept_alive_due_inflight'] = process.pid
        if not summary['inflight']:
            helper.close_ledger(ledger)
        result['usage'] = summary
        g = helper.read(AUTH)
        g.update(status='STOP' if summary['unsettled'] else 'CLOSED', actual_calls=8 + summary['calls'], actual_reported_tokens=3484 + summary['reported_tokens'], held_tokens=3484 + summary['held_tokens'], unknown=summary['unknown'], unused_space_revoked=True)
        assert g['actual_calls'] <= 20 and g['held_tokens'] <= 200000
        helper.save(AUTH, g)
        helper.save(OUT / 'results.json', result)
        print(json.dumps({'status': result['status'], 'total_calls': g['actual_calls'], 'reported_tokens': g['actual_reported_tokens'], 'unknown': g['unknown']}), flush=True)


if __name__ == '__main__':
    try:
        with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner:
            runner.run(main())
    except Exception as error:
        print(json.dumps({'exception_type': type(error).__name__, 'code': str(error) if isinstance(error, (AssertionError, ValueError)) else 'SEE_SAVED_EVIDENCE'}))
        raise SystemExit(2)
