"""Synthetic contracts only: creates no live grant, service, DB or Provider call."""
import importlib.util,json,tempfile,unittest,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0,str(Path.cwd()))
spec=importlib.util.spec_from_file_location('prepare_s8_generic',Path(__file__).with_name('prepare_executions.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

class PreparationContracts(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.subject='synthetic-existing-subject'
        self.old=m.SUBJECT_SHA;m.SUBJECT_SHA=m.sha(self.subject.encode())
        self.row={'dataset':'synthetic','unit_id':'u1','knowledge_base_id':'00000000-0000-0000-0000-000000000001','source_sha256':'a'*64,'status':'NEW_SOURCE','embedding_model_id':m.MODEL['model_id'],'child_count':17,'embedding_calls_upper':2,'token_reservation_upper':5000}
        self.plan={'schema':'s8-overnight-ingestion/v1','tenant_id':332,'subject_sha256':m.SUBJECT_SHA,'gold_sent_to_parser':False,'embedding':{k:v for k,v in m.MODEL.items() if k!='capability'}|{'dimension':1024,'max_batch_size':16,'max_input_chars':0},'sources':[self.row]}
        self.approval={'schema':'s8-owner-approved-embedding-scope/v1','status':'APPROVED_AWAITING_TARGET_BINDING','owner_approved':True,'owner_question_id':'synthetic-no-send','owner_answer':'Synthetic fixture only','owner_goal_sha256':'b'*64,'plan_sha256':m.sha(m.canonical(self.plan).encode()),'only_provider':'siliconflow','only_model':'BAAI/bge-m3','capability':'embedding','max_batch_size':16,'new_UNKNOWN':'STOP_NO_RESEND','QA_authorized':False,'max_calls':3,'max_tokens':6000,'new_sources':1,'new_child_chunks':17}
        self.args=SimpleNamespace(approval=self.root/'approval.json',plan=self.root/'plan.json',principal_state=self.root/'principal.json',approval_sha256='',plan_sha256='',owner_goal=None,postgres_system_id=m.TARGET['postgres_system_id'],database=m.TARGET['database'],storage_root=m.STORAGE,run_id='s8-synthetic-contract',output_root='/opt/rag-s8/state/executions/s8-synthetic-contract',write=False)
        self.save()
    def tearDown(self):m.SUBJECT_SHA=self.old;self.tmp.cleanup()
    def save(self):
        self.args.plan.write_text(json.dumps(self.plan),encoding='utf-8');self.args.plan_sha256=m.sha(m.canonical(self.plan).encode());self.approval['plan_sha256']=self.args.plan_sha256
        self.args.approval.write_text(json.dumps(self.approval),encoding='utf-8');self.args.approval_sha256=m.sha(self.args.approval.read_bytes());self.args.principal_state.write_text(json.dumps({'tenant_id':332,'subject_id':self.subject}),encoding='utf-8')
    def test_validates_without_writing_and_parent_is_last(self):
        d=m.validate(self.args);files,report=m.build_documents(self.args,d)
        self.assertEqual(report['status'],'VALIDATED_NOT_WRITTEN');self.assertEqual([x[0] for x in files][-1],'parent.json');self.assertEqual(len(files),4)
        ledger=files[0][1];self.assertEqual((ledger['max_calls'],ledger['max_tokens']),(2,5000));self.assertEqual(files[-1][1]['executions'],{m.source_key(self.row):self.args.output_root+'/'+files[0][0]});self.assertEqual(ledger['allowed_models'],[m.MODEL]);self.assertEqual(ledger['entries'],[])
    def test_rejects_unapproved_missing_or_changed_numeric_approval(self):
        for field,value in [('owner_approved',False),('max_calls',True),('max_tokens',None),('QA_authorized',True)]:
            old=self.approval[field];self.approval[field]=value;self.save()
            with self.assertRaises(ValueError):m.validate(self.args)
            self.approval[field]=old
    def test_refuses_per_source_limit_and_aggregate_overflow(self):
        for field,value in [('embedding_calls_upper',13),('token_reservation_upper',100001),('embedding_calls_upper',1)]:
            old=self.row[field];self.row[field]=value;self.save()
            with self.assertRaises(ValueError):m.validate(self.args)
            self.row[field]=old
        self.approval['max_tokens']=4999;self.save()
        with self.assertRaisesRegex(ValueError,'PREALLOCATED_SUM'):m.validate(self.args)
    def test_duplicate_source_job_and_changed_scope_are_rejected(self):
        self.plan['sources'].append(dict(self.row));self.save()
        with self.assertRaisesRegex(ValueError,'DUPLICATE_SOURCE'):m.validate(self.args)
        self.plan['sources'].pop();self.args.database='other';self.save()
        with self.assertRaisesRegex(ValueError,'EXACT_VERIFIED_TARGET'):m.validate(self.args)
    def test_frozen_inputs_and_owner_goal_are_required(self):
        self.args.approval.write_text('{}',encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'FROZEN_OWNER'):m.validate(self.args)
        self.save();self.args.owner_goal=self.root/'goal';self.args.owner_goal.write_text('different')
        with self.assertRaisesRegex(ValueError,'OWNER_GOAL_SHA'):m.validate(self.args)
    def test_exclusive_writer_never_overwrites(self):
        p=self.root/'exclusive';m.write_exclusive(p,{'synthetic':1})
        with self.assertRaises(FileExistsError):m.write_exclusive(p,{'synthetic':2})
        self.assertEqual(json.loads(p.read_text()),{'synthetic':1})
    def test_objects_pass_actual_existing_v1_runner_contract(self):
        from unittest.mock import patch
        from backend.weknora_port.execution import _validate_ledger
        from scripts import s8_overnight_ingestion as runner
        d=m.validate(self.args);files,_=m.build_documents(self.args,d);ledger=files[0][1];parent=files[-1][1]
        _validate_ledger(ledger)
        lookup={self.args.output_root+'/'+files[0][0]:ledger,'synthetic-parent':parent}
        with patch.object(runner,'read',side_effect=lambda p:lookup[str(p)]):
            actual,calls,tokens=runner.parent_state('synthetic-parent',self.plan)
            path=runner.verify_execution(actual,self.plan,self.row,SimpleNamespace(subject_id=self.subject),calls,tokens)
        self.assertEqual((calls,tokens),(0,0));self.assertEqual(str(path).replace('\\','/'),self.args.output_root+'/'+files[0][0])

if __name__=='__main__':unittest.main()
