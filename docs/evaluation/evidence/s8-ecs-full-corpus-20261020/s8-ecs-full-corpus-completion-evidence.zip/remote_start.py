import json,hashlib,subprocess,urllib.request
from pathlib import Path
R=Path('/opt/rag-s8');F=R/'full-corpus-20261020';E=R/'state/executions/s8-full-corpus-20261020';C=R/'state/checkpoints/full-corpus-20261020'
assert not C.exists(),'EXISTING_CHECKPOINT_NO_DUPLICATE_START'
for p,d in [(F/'tools/s8_execution_counter.py','d21de8ac1eebb04ae72010af5d9078ef64c85b0903cd328619d03d8fbc4f00be'),
 (R/'state/run_full_corpus.py','f3039f2a7e9971fe4a29187a696bb68e6e94c3f755a05881cad0e572ca33073c')]:
 assert hashlib.sha256(p.read_bytes()).hexdigest()==d
parent=json.loads((E/'parent.json').read_text());assert parent['status']=='OPEN' and parent['max_calls']==11332 and parent['max_tokens']==70000000
assert all(not json.loads(Path(x).read_text())['entries'] for x in parent['executions'].values())
old=json.loads((R/'state/executions/s8-overnight-20261020/parent.json').read_text());assert old['status']=='CLOSED' and old['actual_calls']==745
check=json.loads((R/'state/reports/full-corpus-linux-semantics.json').read_text());assert check['sources_verified']==10935 and check['provider_calls']==0
token=(R/'secrets/api_token').read_text().strip()
request=urllib.request.Request('http://127.0.0.1:18800/readyz',headers={'Authorization':'Bearer '+token})
with urllib.request.urlopen(request,timeout=10) as response:identity=json.load(response)
assert identity['tenant_id']==332 and identity['postgres_system_id']=='7698420805889187877' and identity['cloud_allowed'] is False
unit=Path('/etc/systemd/system/rag-s8-full-corpus-20261020.service');assert not unit.exists()
unit.write_text('''[Unit]
Description=S8 remaining10935 text sources BGE ingestion (no QA)
After=docker.service network-online.target
Requires=docker.service
Wants=network-online.target

[Service]
Type=exec
WorkingDirectory=/opt/rag-s8/current
ExecStart=/usr/bin/docker compose --env-file /opt/rag-s8/config/runtime.env -f /opt/rag-s8/current/deploy/s8/compose.yml -f /opt/rag-s8/config/loaded-images.json run --rm --no-deps -T --name rag-s8-full-corpus-20261020 -e WEKNORA_PORT_CLOUD_ALLOWED=true api python /opt/rag-s8/state/run_full_corpus.py
ExecStop=-/usr/bin/docker stop -t 60 rag-s8-full-corpus-20261020
Restart=no
TimeoutStopSec=90
Nice=10
IOSchedulingClass=best-effort
IOSchedulingPriority=7
StandardOutput=append:/opt/rag-s8/logs/full-corpus-20261020.log
StandardError=append:/opt/rag-s8/logs/full-corpus-20261020.stderr.log
UMask=0077

[Install]
WantedBy=multi-user.target
''')
for command in (['systemd-analyze','verify',str(unit)],['systemctl','daemon-reload'],['systemctl','enable','--now',unit.name]):
 p=subprocess.run(command,capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr[-600:]
show=subprocess.run(['systemctl','show',unit.name,'--property=ActiveState,SubState,MainPID,ExecMainStatus,ActiveEnterTimestamp'],capture_output=True,text=True,timeout=15)
receipt={'status':'NEW_FULL_CORPUS_JOB_DISPATCHED','service':show.stdout,'existing748_untouched':True,
 'new_sources':10935,'provider_calls_upper':11332,'tokens_upper':70000000,
 'runtime_image_commit':'50f61d1e5494951fdc96f9a9845ff7f43633a7f4','execution_tools_commit':'161ef84632e6a669ee79e8850ce295eb57a7a2cc',
 'SSH_will_disconnect_after_dispatch':True}
(F/'dispatch-receipt.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
