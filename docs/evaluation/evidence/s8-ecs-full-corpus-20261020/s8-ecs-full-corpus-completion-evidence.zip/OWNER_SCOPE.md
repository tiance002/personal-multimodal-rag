# S8 incremental full ECS corpus — Owner clarification 2026-10-20

This records the current task scope, not a new executable Provider grant.

- Process all six already-prepared public dataset corpora on ECS.
- Keep the 748 completed/current BGE-M3 sources and their real indexes. Do not re-embed them.
- For every other source, build current cloud-model embeddings/indexes rather than spending time checking whether old vectors could be reused. Preserve historical records.
- Exact current inventory: SciFact5183, MIRACL6000, LongBench400, Hotpot73, MML3, Omni24 =11683 sources. Additional work: Sci4983, MIR5600, Long352 =10935 sources.
- Current model is the existing tenant332 SiliconFlow BAAI/bge-m3 Registry binding, dimension1024; no new supplier, model or account provisioning.
- Read existing originals on ECS; don't copy Windows environments or inject Gold. No new OCR is needed for the missing10935 text records.
- All work must run independently on ECS. Verify a fresh SSH connection observes progress before telling Owner the NEW full-corpus job is handed off.
- Old 745-call/5200000-token grant is CLOSED and remains unchanged. Prepare the exact new frozen job list and conservative upper bound, then obtain one new Owner approval before sending.
- No QA, Graph extraction, Summary, Caption, frontend release, Push, deletion, history/UNKNOWN changes or other additional tasks in this immediate handoff.

Owner's last controlling clarification: “除了这748条其他旧向量都重做，不用核验花时间了，之后是我休息的时间，也不算浪费时间”.
