import json,hashlib,tarfile,subprocess
from pathlib import Path
R=Path('/opt/rag-s8');F=R/'full-corpus-20261020';p=R/'incoming/full-corpus-materials.tar.gz.part'
assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()=='bdcc14f06401bc5f1d84b29bb30a39c246d874a27901352792f240b94d7ea7c5'
assert not F.exists();F.mkdir(mode=0o750)
with tarfile.open(p) as t:
 for m in t.getmembers():assert not(m.issym() or m.islnk()) and F in (F/m.name).resolve().parents
 t.extractall(F,filter='data')
p.rename(p.with_suffix(''))
manifest=json.loads((F/'transfer-manifest.json').read_text())
for name,record in manifest.items():
 if isinstance(record,dict):assert hashlib.file_digest((F/name).open('rb'),'sha256').hexdigest()==record['sha256']
old=json.loads((R/'state/executions/s8-overnight-20261020/parent.json').read_text());assert old['status']=='CLOSED'
prior=json.loads((R/'state/checkpoints/ingestion-20261020/ingestion-results.json').read_text());assert prior['state']=='INDEX_READY'
assert len(prior['documents'])==748
o=R/'config/loaded-images.json';d=json.loads(o.read_text())
for name in ('api','worker'):
 vols=d['services'][name].setdefault('volumes',[]);v=str(F)+':'+str(F)+':ro';assert v not in vols;vols.append(v)
o.write_text(json.dumps(d))
args=['python3',str(F/'tools/prepare_executions.py'),'--approval',str(F/'config/OWNER_APPROVAL.json'),
 '--approval-sha256',manifest['owner_approval_sha256'],'--owner-goal',str(F/'config/OWNER_SCOPE.md'),
 '--plan',str(F/'config/ingestion-plan.json'),'--plan-sha256',manifest['canonical_plan_sha256'],
 '--principal-state',str(R/'secrets/principal.json'),'--postgres-system-id','7698420805889187877',
 '--database','weknora_s8','--storage-root','/var/lib/eviroute/storage','--run-id','s8-full-corpus-20261020',
 '--output-root',str(R/'state/executions/s8-full-corpus-20261020')]
for mode in ([],['--write']):
 result=subprocess.run(args+mode,capture_output=True,text=True,timeout=100)
 (F/('prepare-actual' if mode else 'prepare-validation')).with_suffix('.stdout').write_text(result.stdout)
 assert result.returncode==0,result.stdout+result.stderr
 print(result.stdout.strip())
print(json.dumps({'remote_materials_verified':True,'old748_preserved':True,'provider_calls':0,'remote_root':str(F)}))
