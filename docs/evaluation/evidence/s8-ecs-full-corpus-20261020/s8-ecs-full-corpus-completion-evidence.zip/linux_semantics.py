import sys,json,hashlib,zipfile,time
from pathlib import Path
sys.path.insert(0,'/app');sys.path.insert(0,'/opt/rag-s8/full-corpus-20261020/tools')
from s8_full_corpus_ingestion import calculate_chunks
from backend.weknora_port.ingestion.core import ParserRegistry
R=Path('/opt/rag-s8/full-corpus-20261020');p=json.loads((R/'config/ingestion-plan.json').read_text());registry=ParserRegistry()
start=time.monotonic();n=0
with zipfile.ZipFile(R/'packages/full-corpus-additional.zip') as z:
 for row in p['sources']:
  raw=z.read(row['member']);assert hashlib.sha256(raw).hexdigest()==row['source_sha256']
  facts=calculate_chunks(raw,row['filename'],row['knowledge_base_id'],registry)
  assert all(facts[k]==row[k] for k in facts),(row['dataset'],row['unit_id'],'NATIVE_LINUX_PLAN_MISMATCH')
  n+=1
result={'status':'NATIVE_LINUX_FROZEN_INPUT_PASS','sources_verified':n,'provider_calls':0,'elapsed_seconds':time.monotonic()-start}
out=Path('/opt/rag-s8/state/reports/full-corpus-linux-semantics.json');assert not out.exists();out.write_text(json.dumps(result,indent=2))
print(json.dumps(result))
