import json,hashlib,subprocess,datetime
from pathlib import Path
R=Path('/opt/rag-s8');F=R/'full-corpus-20261020'
def run(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=30);assert p.returncode==0,p.stderr[-600:];return p.stdout
s=json.loads(run(['python3',str(R/'state/full-corpus-status.py')]))
assert 'MainPID=901220' in s['systemd']['output'] and 'ActiveState=active' in s['systemd']['output']
assert s['checkpoint']['states'].get('INDEXED',0)>41 and not s['provider']['unknown_held_tokens']
names=run(['docker','ps','--format','{{.Names}}']).splitlines();assert names.count('rag-s8-full-corpus-20261020')==1
inspection=json.loads(run(['docker','inspect','rag-s8-full-corpus-20261020']))[0]
mounts=[{'source':m['Source'],'destination':m['Destination'],'rw':m['RW']} for m in inspection['Mounts']]
assert all(m['source'].startswith('/') and ':' not in m['source'] for m in mounts)
plan=json.loads((F/'config/ingestion-plan.json').read_text());origins={}
for dataset,record in plan['supplement']['raw_corpora'].items():
 p=Path('/opt/rag-p7-r1/data/v6-dev24-inputs/inputs/public')/dataset/'corpus.jsonl'
 assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==record['sha256']
 origins[dataset]={'actual_ecs_path':str(p),'sha256':record['sha256'],'rows':record['rows'],
  'record_mapping':'plan.sources.corpus_source.record_line and original_record_sha256; only doc_id/title/text'}
(F/'config/ecs-source-origins.json').write_text(json.dumps(origins,indent=2))
out={'status':'REMOTE_BACKGROUND_VERIFIED','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'first_connection_closed':True,'same_main_pid':901220,'single_ingestion_container':True,'windows_dependency':False,
 'mounts':mounts,'origins':origins,'live_status':s,
 'runtime_image_commit':'50f61d1e5494951fdc96f9a9845ff7f43633a7f4','execution_tools_commit':'161ef84632e6a669ee79e8850ce295eb57a7a2cc',
 'scope':'Keep748; add10935; no QA/Summary/OCR/Caption/Graph; no resend on UNKNOWN'}
(F/'handoff-proof.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
