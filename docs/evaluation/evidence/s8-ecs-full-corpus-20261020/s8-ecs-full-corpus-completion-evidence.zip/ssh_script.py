import subprocess,sys,json
from pathlib import Path
R=Path(__file__).resolve().parent
cmd=['ssh.exe','-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes','-o','ConnectTimeout=15','-i','C:/Users/22088/Downloads/study-plan-dev.pem','root@120.55.115.162','python3 -']
if __name__=='__main__':
 p=subprocess.run(cmd,input=Path(sys.argv[1]).read_bytes(),capture_output=True,timeout=int(sys.argv[3]) if len(sys.argv)>3 else 180)
 (R/(sys.argv[2]+'.stdout')).write_bytes(p.stdout);(R/(sys.argv[2]+'.stderr')).write_bytes(p.stderr)
 print(json.dumps({'label':sys.argv[2],'exit':p.returncode,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr)}))
 raise SystemExit(p.returncode)
