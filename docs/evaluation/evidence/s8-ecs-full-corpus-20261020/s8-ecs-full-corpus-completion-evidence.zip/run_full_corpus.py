"""ECS-only finite job wrapper. Reuses the formal runtime and durable SendGate."""
import os,sys
sys.path.insert(0,'/app')
sys.path.insert(0,'/opt/rag-s8/full-corpus-20261020/tools')
from scripts.s8_ecs_runtime import runtime_environment
from scripts import s8_overnight_ingestion as runner
from s8_execution_counter import install
os.environ.update(runtime_environment())
install(runner)
sys.argv=['s8_overnight_ingestion.py','run',
 '--plan','/opt/rag-s8/full-corpus-20261020/config/ingestion-plan.json',
 '--package-root','/opt/rag-s8/full-corpus-20261020/packages',
 '--mineru-receipts','/opt/rag-s8/config/mineru-pages.jsonl',
 '--principal-state','/run/secrets/principal.json',
 '--authorization','/opt/rag-s8/state/executions/s8-full-corpus-20261020/parent.json',
 '--output','/opt/rag-s8/state/checkpoints/full-corpus-20261020']
runner.main()
