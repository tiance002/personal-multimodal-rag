"""Final completed-job audit; read-only SQL, original bytes, GET and stored vectors."""
import json,hashlib,subprocess,datetime
from pathlib import Path
R=Path('/opt/rag-s8')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def key(row):return sha(canonical([row['dataset'],row['knowledge_base_id'],row['source_sha256']]).encode())
plan_path=R/'full-corpus-20261020/config/ingestion-plan.json';plan=read(plan_path)
new_path=R/'state/checkpoints/full-corpus-20261020/ingestion-results.json';new=read(new_path)
old_path=R/'state/checkpoints/ingestion-20261020/ingestion-results.json';old=read(old_path)
parent_path=R/'state/executions/s8-full-corpus-20261020/parent.json';parent=read(parent_path)
old_parent=read(R/'state/executions/s8-overnight-20261020/parent.json')
assert new['state']=='INDEX_READY' and parent['status']=='CLOSED' and old['state']=='INDEX_READY' and old_parent['status']=='CLOSED'
rows=[]
for row in plan['sources']:
 if row['status']!='NEW_SOURCE':continue
 actual=new['documents'][key(row)]
 assert actual['state']=='INDEXED' and actual['original_sha256']==row['source_sha256']
 rows.append({k:row[k] for k in ('dataset','unit_id','knowledge_base_id','source_sha256','child_count')}|{'actual':{k:actual[k] for k in ('document_id','source_version','original_sha256')}})
old_records=[{k:v[k] for k in ('dataset','unit_id','document_id','source_version','original_sha256')} for v in old['documents'].values()]
payload={'new':rows,'old':old_records,'job':{k:new[k] for k in ('state','provider_calls','reported_tokens')},
 'authorization':{k:parent.get(k) for k in ('status','max_calls','max_tokens','actual_calls','actual_reported_tokens')},
 'old_authorization':{k:old_parent.get(k) for k in ('status','actual_calls','actual_reported_tokens')},
 'inputs':{str(p):sha(p.read_bytes()) for p in (plan_path,new_path,old_path,parent_path)}}
code=r'''
import asyncio,hashlib,json,re,time,uuid,builtins,traceback,urllib.request,urllib.error
from pathlib import Path
import psycopg
from psycopg.rows import dict_row
from scripts.s8_ecs_runtime import runtime_environment,trusted_principal,api_token
from backend.weknora_port.development import DevelopmentSettings,PROHIBITED
from backend.weknora_port.storage.postgres import PostgresRetriever,IsolationPolicy
from backend.weknora_port.storage.hybrid import PostgresKnowledgeRepository
from backend.weknora_port.retrieval.search import SearchTarget,SearchParams
from backend.weknora_port.retrieval.pipeline import PipelineState
from backend.weknora_port.retrieval.merge import merge
from backend.weknora_port.retrieval.filter_top_k import filter_top_k
from backend.weknora_port.retrieval.context import into_chat_message
from backend.weknora_port.retrieval.query import default_segmenter
from backend.weknora_port.models.types import CallContext,TrustedScope
D=PAYLOAD
def sha(raw):return hashlib.sha256(raw).hexdigest()
def get(path,token=None):
 headers={'Authorization':'Bearer '+token} if token is not None else {}
 try:
  with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:8000'+path,headers=headers),timeout=30) as r:return r.status,r.read()
 except urllib.error.HTTPError as e:return e.code,e.read()
def indexes(plan):
 found=[]
 if isinstance(plan,dict):
  if 'Index Name' in plan:found.append(plan['Index Name'])
  for value in plan.values():found+=indexes(value)
 elif isinstance(plan,list):
  for value in plan:found+=indexes(value)
 return found
async def main():
 s=DevelopmentSettings.from_environment(runtime_environment());principal=trusted_principal('/run/secrets/principal.json');token=api_token()
 assert s.database=='weknora_s8' and s.system_id=='7698420805889187877' and principal.tenant_id==332
 out={'schema':'s8-full-corpus-final-completion-audit/v1','inputs':D['inputs'],'job':D['job'],'authorization':D['authorization'],'kept748_authorization':D['old_authorization'],
      'datasets':{},'source_records':[],'probes':[],'source_gets':[],'limitations':['ZERO_CLOUD_INFRASTRUCTURE_PROBES_NOT_QA_QUALITY_RESULTS','NO_NEW_QU_RERANK_GENERATION_OR_OCR','PARENT_TEXT_RESOLUTION_ONLY_IF_REAL_PARENT_ROWS_EXIST']}
 out['api_unauthorized_status']=get('/readyz')[0];out['api_wrong_token_status']=get('/readyz','wrong-token-final-audit')[0]
 assert out['api_unauthorized_status']==401 and out['api_wrong_token_status']==401
 status,body=get('/readyz',token);assert status==200;out['api_readiness']=json.loads(body)
 assert out['api_readiness']['tenant_id']==332 and out['api_readiness']['cloud_allowed'] is False and out['api_readiness']['graph_enabled'] is False and out['api_readiness']['rerank_top1_floorless'] is False
 async with await psycopg.AsyncConnection.connect(s.database_url,autocommit=True,row_factory=dict_row,connect_timeout=10) as c:
  async with c.transaction():
   await c.execute('SET TRANSACTION READ ONLY')
   async def rows(query,params=()):return await(await c.execute(query,params)).fetchall()
   out['sql_read_only']=(await rows('SHOW transaction_read_only'))[0]['transaction_read_only'];assert out['sql_read_only']=='on'
   out['provider_before']=(await rows("SELECT count(*) AS total,count(*) FILTER(WHERE outcome='UNKNOWN') AS unknown FROM port_provider_calls"))[0]
   out['identity']=(await rows('SELECT current_database() AS database,system_identifier::text AS system_id FROM pg_control_system()'))[0]
   out['kb_permissions']=await rows('SELECT id,name,tenant_id,cloud_allowed,chunking_config,indexing_strategy,embedding_model_id FROM knowledge_bases WHERE deleted_at IS NULL ORDER BY id')
   assert builtins.all(k['tenant_id']==332 for k in out['kb_permissions'])
   new_ids=[x['actual']['document_id'] for x in D['new']];old_ids=[x['document_id'] for x in D['old']]
   assert len(set(new_ids))==len(new_ids) and len(set(old_ids))==len(old_ids) and not set(new_ids)&set(old_ids)
   ids=new_ids+old_ids
   docs=await rows("SELECT id,tenant_id,knowledge_base_id,file_path,file_hash,parse_status,enable_status,summary_status,metadata->>'source_version' AS source_version FROM knowledges WHERE id=ANY(%s) AND deleted_at IS NULL",(ids,));bydoc={r['id']:r for r in docs};assert len(docs)==len(ids)
   counts=await rows("SELECT c.knowledge_id,count(*) AS chunks,count(*) FILTER(WHERE c.chunk_type='text') AS text_chunks,count(*) FILTER(WHERE c.chunk_type='parent_text') AS parent_text_rows,count(*) FILTER(WHERE c.chunk_type='summary') AS summaries,count(*) FILTER(WHERE c.chunk_type NOT IN ('text','parent_text','summary')) AS other_chunks,count(e.id) AS embedding_rows,count(e.id) FILTER(WHERE e.dimension=1024 AND e.embedding IS NOT NULL) AS vector_1024 FROM chunks c LEFT JOIN embeddings e ON e.chunk_id=c.id AND e.knowledge_id=c.knowledge_id AND e.knowledge_base_id=c.knowledge_base_id WHERE c.knowledge_id=ANY(%s) AND c.deleted_at IS NULL AND c.is_enabled=true GROUP BY c.knowledge_id",(ids,));bycount={r['knowledge_id']:r for r in counts}
   for is_new,record in [(True,r) for r in D['new']]+[(False,r) for r in D['old']]:
    expected=record['actual'] if is_new else record;dataset=record['dataset'];doc=bydoc[expected['document_id']];ct=bycount[doc['id']]
    assert doc['tenant_id']==332 and doc['parse_status']=='completed' and doc['enable_status']=='enabled'
    assert doc['source_version']==expected['source_version'] and doc['file_hash']==expected['original_sha256']
    assert doc['file_path'].startswith('/var/lib/eviroute/storage/332/') and Path(doc['file_path']).is_file()
    if is_new:
     assert doc['knowledge_base_id']==record['knowledge_base_id'] and ct['text_chunks']==record['child_count']
     assert ct['chunks']==ct['text_chunks']==ct['embedding_rows']==ct['vector_1024'] and ct['summaries']==0 and ct['parent_text_rows']==0
     actual_sha=sha(Path(doc['file_path']).read_bytes());assert actual_sha==record['source_sha256'],'NEW_ORIGINAL_BYTES_SHA_MISMATCH'
    else:actual_sha=None
    group=out['datasets'].setdefault(dataset,{'new_sources':0,'kept_sources':0,'new_text_chunks':0,'new_embedding_rows':0,'new_vector_1024':0,'kept_text_chunks':0,'kept_embedding_rows':0,'kept_vector_1024':0,'parent_text_rows':0,'summaries':0,'other_chunks':0,'all_new_file_sha_verified':True})
    prefix='new' if is_new else 'kept';group[prefix+'_sources']+=1;group[prefix+'_text_chunks']+=ct['text_chunks'];group[prefix+'_embedding_rows']+=ct['embedding_rows'];group[prefix+'_vector_1024']+=ct['vector_1024'];group['parent_text_rows']+=ct['parent_text_rows'];group['summaries']+=ct['summaries'];group['other_chunks']+=ct['other_chunks']
    out['source_records'].append({'dataset':dataset,'scope':'NEW10935' if is_new else 'KEPT748','unit_id':record['unit_id'],'document_id':doc['id'],'knowledge_base_id':doc['knowledge_base_id'],'source_version':doc['source_version'],'original_sha256':doc['file_hash'],'actual_new_file_sha256':actual_sha,'chunks':ct,'status':'COMPLETED_VERSION_AND_INDEX_VERIFIED'})
   out['physical_totals']=(await rows('SELECT (SELECT count(*) FROM knowledge_bases WHERE deleted_at IS NULL) AS knowledge_bases,(SELECT count(*) FROM knowledges WHERE deleted_at IS NULL) AS documents,(SELECT count(*) FROM chunks WHERE deleted_at IS NULL) AS chunks,(SELECT count(*) FROM embeddings) AS embeddings,(SELECT count(*) FROM port_graph_evidence) AS graph_sources,(SELECT count(*) FROM port_graph_nodes) AS graph_nodes,(SELECT count(*) FROM port_graph_edges) AS graph_edges'))[0]
   out['extra_history_documents']=await rows('SELECT kb.id,kb.name,count(*) AS documents FROM knowledges k JOIN knowledge_bases kb ON kb.id=k.knowledge_base_id WHERE k.deleted_at IS NULL AND NOT(k.id=ANY(%s)) GROUP BY kb.id,kb.name ORDER BY kb.id',(ids,))
   out['integrity']=(await rows("SELECT count(*) FILTER(WHERE c.id IS NULL OR k.id IS NULL OR kb.id IS NULL) AS orphan,count(*) FILTER(WHERE c.knowledge_id<>e.knowledge_id OR c.knowledge_base_id<>e.knowledge_base_id OR k.knowledge_base_id<>e.knowledge_base_id OR c.tenant_id<>332 OR k.tenant_id<>332 OR kb.tenant_id<>332) AS identity_mismatch,count(*) FILTER(WHERE e.dimension<>1024 OR e.embedding IS NULL) AS invalid_vector,count(*) FILTER(WHERE NOT coalesce(c.is_enabled,false) OR c.deleted_at IS NOT NULL OR k.deleted_at IS NOT NULL OR kb.deleted_at IS NOT NULL) AS inactive FROM embeddings e LEFT JOIN chunks c ON c.id=e.chunk_id LEFT JOIN knowledges k ON k.id=e.knowledge_id LEFT JOIN knowledge_bases kb ON kb.id=e.knowledge_base_id"))[0];assert builtins.all(v==0 for v in out['integrity'].values())
   out['duplicate_indexes']=await rows('SELECT chunk_id,count(*) AS n FROM embeddings GROUP BY chunk_id HAVING count(*)<>1');assert not out['duplicate_indexes']
   out['invalid_versions']=(await rows("SELECT count(*) AS n FROM chunks c JOIN knowledges k ON k.id=c.knowledge_id WHERE c.deleted_at IS NULL AND c.chunk_type<>'summary' AND c.metadata->>'source_version' IS DISTINCT FROM k.metadata->>'source_version'"))[0]['n'];assert out['invalid_versions']==0
   out['invalid_parent_adjacency']=(await rows("SELECT count(*) AS n FROM chunks c LEFT JOIN chunks p ON p.id=c.parent_chunk_id LEFT JOIN chunks prev ON prev.id=c.pre_chunk_id LEFT JOIN chunks nxt ON nxt.id=c.next_chunk_id WHERE c.deleted_at IS NULL AND ((coalesce(c.parent_chunk_id,'')<>'' AND (p.id IS NULL OR p.knowledge_id<>c.knowledge_id OR p.knowledge_base_id<>c.knowledge_base_id)) OR (coalesce(c.pre_chunk_id,'')<>'' AND (prev.id IS NULL OR prev.knowledge_id<>c.knowledge_id OR prev.knowledge_base_id<>c.knowledge_base_id)) OR (coalesce(c.next_chunk_id,'')<>'' AND (nxt.id IS NULL OR nxt.knowledge_id<>c.knowledge_id OR nxt.knowledge_base_id<>c.knowledge_base_id)))"))[0]['n'];assert out['invalid_parent_adjacency']==0
   out['embedding_indexes']=await rows("SELECT indexname,indexdef FROM pg_indexes WHERE tablename='embeddings' ORDER BY indexname")
   guard=PostgresRetriever(c,IsolationPolicy(s.system_id,PROHIBITED,s.database));await guard.verify_identity()
   async def resolve(owner):
    assert owner==principal.subject_id
    return 332
   repo=PostgresKnowledgeRepository(guard,resolve);segmenter=default_segmenter()
   for dataset in sorted(out['datasets']):
    options=[r for r in D['new'] if r['dataset']==dataset];is_new=bool(options)
    record=sorted(options,key=lambda r:r['unit_id'])[0]['actual'] if is_new else sorted([r for r in D['old'] if r['dataset']==dataset],key=lambda r:r['unit_id'])[0]
    doc=bydoc[record['document_id']];kb=doc['knowledge_base_id']
    anchor=(await rows("SELECT c.id,c.content,c.parent_chunk_id,e.embedding::text AS vector FROM chunks c JOIN embeddings e ON e.chunk_id=c.id WHERE c.knowledge_id=%s AND c.chunk_type='text' AND c.is_enabled=true AND c.deleted_at IS NULL AND e.dimension=1024 AND e.embedding IS NOT NULL ORDER BY c.chunk_index,c.id LIMIT 1",(doc['id'],)))[0]
    vector=json.loads(anchor['vector']);query=' '.join(t[:32] for t in re.findall(r'[\w]{2,}',anchor['content'])[:6]);context=CallContext(str(uuid.uuid4()),TrustedScope(principal.subject_id,(kb,)));target=SearchTarget(kb)
    start=time.monotonic();hits=await repo.hybrid_search((target,),SearchParams(query_text=query,match_count=30,skip_context_enrichment=True),context,query_embedding=vector)
    state=PipelineState(query=query,rewrite_query=query,intent='kb_search',targets=(target,),search_results=list(hits),rerank_top_k=30)
    await merge(state,context,repo,segmenter=segmenter);filter_top_k(state);final=await into_chat_message(state,context)
    assert hits and final.rendered_contexts and final.result_ids and anchor['id'] in [h.id for h in hits]
    vector_text=anchor['vector'];statement='SELECT id,chunk_id,embedding::halfvec(1024) <=> %s::halfvec(1024) AS distance FROM embeddings WHERE dimension=1024 AND knowledge_base_id=%s AND is_enabled=true ORDER BY embedding::halfvec(1024) <=> %s::halfvec(1024) LIMIT 5';params=(vector_text,kb,vector_text)
    await c.execute('SET LOCAL enable_seqscan=off')
    try:
     explain=(await rows('EXPLAIN (ANALYZE,BUFFERS,FORMAT JSON) '+statement,params))[0]['QUERY PLAN'];nearest=await rows(statement,params)
    finally:await c.execute('SET LOCAL enable_seqscan=on')
    used=indexes(explain);assert 'embeddings_embedding_idx_1024' in used and nearest and nearest[0]['chunk_id']==anchor['id'] and abs(nearest[0]['distance'])<1e-6
    out['probes'].append({'dataset':dataset,'source_scope':'NEW10935' if is_new else 'KEPT748_NO_NEW_DOCUMENTS_FOR_DATASET','document_id':doc['id'],'query_source':'EXISTING_SOURCE_CHUNK_WORDS','query':query,'stored_vector_chunk_id':anchor['id'],'search_count':len(hits),'search_ids':[h.id for h in hits],'match_types':sorted(set(h.match_type for h in hits)),'merged_count':len(state.merge_results),'context_chars':len(final.rendered_contexts),'context_sha256':sha(final.rendered_contexts.encode()),'context':final.rendered_contexts,'final_ids':list(final.result_ids),'content_rewritten_by_merge':builtins.any(x.content_rewritten for x in state.merge_results),'parent_resolution':'NOT_EXERCISED_NO_PARENT_TEXT_ROWS','elapsed_seconds':round(time.monotonic()-start,4),'explain_analyze':explain,'indexes_used':used,'nearest_results':nearest,'status':'ZERO_CLOUD_INFRASTRUCTURE_PROBE_PASS'})
    status,raw=get(f'/api/v1/knowledge-bases/{kb}/documents/{doc["id"]}/source',token);assert status==200 and sha(raw)==doc['file_hash']
    status,rawchunk=get('/api/v1/chunks/'+anchor['id'],token);assert status==200
    out['source_gets'].append({'dataset':dataset,'scope':'NEW10935' if is_new else 'KEPT748','document_id':doc['id'],'source_version':doc['source_version'],'original_status':200,'original_bytes':len(raw),'original_sha256':sha(raw),'first_chunk_status':200,'first_chunk_id':anchor['id'],'first_chunk':json.loads(rawchunk)})
   out['provider_after']=(await rows("SELECT count(*) AS total,count(*) FILTER(WHERE outcome='UNKNOWN') AS unknown FROM port_provider_calls"))[0];assert out['provider_after']==out['provider_before'] and out['provider_after']['unknown']==2
 out['status']='FULL_CORPUS_DATA_INDEX_SOURCE_READONLY_AUDIT_PASS';out['new_provider_calls']=0;out['database_writes']=0
 print(json.dumps(out,ensure_ascii=False,default=str))
try:asyncio.run(main())
except Exception as e:
 print(json.dumps({'status':'FINAL_AUDIT_INCOMPLETE','error_type':type(e).__name__,'frames':[{'file':f.filename,'line':f.lineno,'function':f.name} for f in traceback.extract_tb(e.__traceback__)]}));raise SystemExit(2)
'''.replace('PAYLOAD','json.loads('+repr(json.dumps(payload,ensure_ascii=False,separators=(',',':')))+')')
p=subprocess.run(['docker','exec','-i','rag-s8-api-1','python','-'],input=code.encode(),capture_output=True,timeout=300)
if p.returncode:
 print(p.stdout.decode(),end='');print(json.dumps({'status':'REMOTE_FINAL_AUDIT_FAILED','exit_code':p.returncode,'stderr_bytes':len(p.stderr)}));raise SystemExit(p.returncode)
out=json.loads(p.stdout);out['audit_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
out['container_health']=subprocess.run(['docker','ps','--filter','name=rag-s8','--format','{{.Names}} {{.Status}}'],capture_output=True,text=True,timeout=20).stdout.splitlines()
out['api_restart_count']=int(subprocess.run(['docker','inspect','rag-s8-api-1','--format','{{.RestartCount}}'],capture_output=True,text=True,timeout=15).stdout)
out['api_state']=json.loads(subprocess.run(['docker','inspect','rag-s8-api-1','--format','{{json .State}}'],capture_output=True,text=True,timeout=15).stdout)
print(json.dumps(out,ensure_ascii=False))
