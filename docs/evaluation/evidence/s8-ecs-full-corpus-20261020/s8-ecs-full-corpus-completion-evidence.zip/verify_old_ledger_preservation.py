import json,hashlib,subprocess
from pathlib import Path
R=Path('/opt/rag-s8');P=R/'state/executions/s8-overnight-20261020/parent.json';parent=json.loads(P.read_text());rows=[]
FIELDS=['id', 'request_id', 'provider', 'model', 'model_id', 'capability', 'status', 'reserved_tokens', 'held_tokens', 'usage', 'started_at', 'settled_at', 'outcome']
for key,filename in sorted(parent['executions'].items()):
 path=Path(filename);assert path.resolve().parent==P.parent.resolve()
 data=json.loads(path.read_text())
 rows.append({'source_key':key,'status':data['status'],'max_calls':data['max_calls'],'max_tokens':data['max_tokens'],'entries':[{k:e.get(k) for k in FIELDS} for e in data['entries']]})
actual=hashlib.sha256(json.dumps(rows,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert actual=='b8dd88198a80109ac4459f9eba2118339b4f92efbdad8693d03e38c65ae01c83','OLD_LEDGER_SEMANTIC_MUTATION'
oldservice=subprocess.run(['systemctl','show','rag-s8-ingestion-20261020.service','--property=MainPID,ExecMainStatus,ActiveState,SubState,Result,UnitFileState'],capture_output=True,text=True,timeout=15)
assert oldservice.returncode==0
print(json.dumps({'status':'OLD_LEDGER_BASELINE_UNCHANGED','files':len(rows),'baseline_and_actual_semantic_sha256':actual,'old_service':oldservice.stdout.strip(),'new_provider_calls':0,'remote_mutations':0}))
