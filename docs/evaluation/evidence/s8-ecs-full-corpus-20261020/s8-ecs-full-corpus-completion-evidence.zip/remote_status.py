import json,subprocess,collections,datetime
from pathlib import Path
R=Path('/opt/rag-s8');E=R/'state/executions/s8-full-corpus-20261020';C=R/'state/checkpoints/full-corpus-20261020';F=R/'full-corpus-20261020'
def cmd(a):
 p=subprocess.run(a,capture_output=True,text=True,timeout=20);return {'exit':p.returncode,'output':p.stdout.strip()}
out={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'systemd':cmd(['systemctl','show','rag-s8-full-corpus-20261020.service','--property=MainPID,ExecMainStatus,ActiveState,SubState,ActiveEnterTimestamp,ExecMainExitTimestamp']),
 'containers':cmd(['docker','ps','--filter','name=rag-s8','--format','{{.Names}} {{.Status}}'])}
parent=json.loads((E/'parent.json').read_text());out['authorization']={k:parent.get(k) for k in ('status','max_calls','max_tokens','actual_calls','actual_reported_tokens','stop_reason')}
entries=[e for path in parent['executions'].values() for e in json.loads(Path(path).read_text())['entries']]
out['provider']={'calls':len(entries),'states':dict(collections.Counter(e['status'] for e in entries)),
 'reported_tokens':sum(e['usage']['total_tokens'] for e in entries if e.get('usage')),
 'held_tokens':sum(e['held_tokens'] for e in entries),'unknown_held_tokens':sum(e['held_tokens'] for e in entries if e['status']=='UNKNOWN')}
if (C/'checkpoint.json').exists():
 cp=json.loads((C/'checkpoint.json').read_text());rows=list(cp['documents'].values())
 out['checkpoint']={'state':cp.get('state','RUNNING'),'documents':len(rows),'states':dict(collections.Counter(r['state'] for r in rows)),
  'datasets':{d:dict(collections.Counter(r['state'] for r in rows if r['dataset']==d)) for d in sorted({r['dataset'] for r in rows})},
  'mtime_ns':(C/'checkpoint.json').stat().st_mtime_ns}
if (C/'runner-stopped.json').exists():out['stopped']=json.loads((C/'runner-stopped.json').read_text())
old=json.loads((R/'state/executions/s8-overnight-20261020/parent.json').read_text())
out['old748']={'authorization_status':old['status'],'calls_unchanged':old['actual_calls']==745,
 'tokens_unchanged':old['actual_reported_tokens']==557090,'sources':748}
text=json.dumps(out,ensure_ascii=False)
(F/'last-status.json').write_text(text+'\n')
print(text)
