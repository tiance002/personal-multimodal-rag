"""Prepare exact preallocated v1 ingestion ledgers from externally pinned approval.

Default validates only. No network, Provider, DB, runtime, signing or renewal.
Only explicit --write by Linux root creates private files; parent.json is LAST.
"""
from __future__ import annotations
import argparse,datetime,hashlib,json,os,re
from pathlib import Path,PurePosixPath

EXECUTION_ROOT=PurePosixPath('/opt/rag-s8/state/executions')
TARGET={'postgres_system_id':'7698420805889187877','database':'weknora_s8'}
STORAGE='/var/lib/eviroute/storage'
SUBJECT_SHA='00f2fd3dad2b741924376adab7fd29c12a93bc7a1fe4e8e1f0f97cacd418fa83'
MODEL={'provider':'siliconflow','model':'BAAI/bge-m3','model_id':'mdlebb9931ff609b45a70a6c29c6712caa66c6b657ce4d1f802ee114bed2e779','capability':'embedding'}

def require(ok,code):
    if not ok:raise ValueError(code)
def read(path):return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def integer(value,low=1,high=None):return type(value) is int and value>=low and (high is None or value<=high)
def fingerprint(value):return isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value) is not None
def source_key(row):return sha(canonical([row['dataset'],row['knowledge_base_id'],row['source_sha256']]).encode())

def validate(args):
    require(fingerprint(args.approval_sha256) and fingerprint(args.plan_sha256),'PINNED_INPUT_SHA_REQUIRED')
    require(sha(Path(args.approval).read_bytes())==args.approval_sha256,'FROZEN_OWNER_APPROVAL_CHANGED')
    approval,plan=read(args.approval),read(args.plan)
    require(sha(canonical(plan).encode())==args.plan_sha256,'FROZEN_SOURCE_PLAN_CHANGED')
    require(approval.get('schema')=='s8-owner-approved-embedding-scope/v1'
        and approval.get('status')=='APPROVED_AWAITING_TARGET_BINDING'
        and approval.get('owner_approved') is True
        and isinstance(approval.get('owner_question_id'),str) and bool(approval['owner_question_id'])
        and isinstance(approval.get('owner_answer'),str) and bool(approval['owner_answer'].strip()),'VALID_NEW_OWNER_APPROVAL_REQUIRED')
    require(approval.get('plan_sha256')==args.plan_sha256 and fingerprint(approval.get('owner_goal_sha256')),'OWNER_PLAN_AND_GOAL_BINDING_REQUIRED')
    if args.owner_goal:require(sha(Path(args.owner_goal).read_bytes())==approval['owner_goal_sha256'],'OWNER_GOAL_SHA_MISMATCH')
    require(plan.get('schema')=='s8-overnight-ingestion/v1' and type(plan.get('tenant_id')) is int and plan['tenant_id']==332
        and plan.get('gold_sent_to_parser') is False,'FORMAL_V1_SOURCE_PLAN_REQUIRED')
    embedding={k:v for k,v in MODEL.items() if k!='capability'}|{'dimension':1024,'max_batch_size':16,'max_input_chars':0}
    require(plan.get('embedding')==embedding,'EMBEDDING_IDENTITY_CHANGED')
    require(approval.get('only_provider')==MODEL['provider'] and approval.get('only_model')==MODEL['model']
        and approval.get('capability')=='embedding' and type(approval.get('max_batch_size')) is int and approval['max_batch_size']==16
        and approval.get('new_UNKNOWN')=='STOP_NO_RESEND' and approval.get('QA_authorized') is False,'OWNER_MODEL_OPERATION_SCOPE_CHANGED')
    require(integer(approval.get('max_calls')) and integer(approval.get('max_tokens')),'EXPLICIT_NUMERIC_OWNER_CAPS_REQUIRED')
    principal=read(args.principal_state);subject=principal.get('subject',principal.get('subject_id'))
    require(isinstance(subject,str) and sha(subject.encode())==SUBJECT_SHA==plan.get('subject_sha256'),'PRINCIPAL_SUBJECT_MISMATCH')
    if 'tenant_id' in principal:require(type(principal['tenant_id']) is int and principal['tenant_id']==332,'PRINCIPAL_TENANT_MISMATCH')
    if 'subject_id' in principal:require(principal['subject_id']==subject,'PRINCIPAL_SUBJECT_ALIAS_MISMATCH')
    require(isinstance(plan.get('sources'),list),'PLAN_SOURCES_REQUIRED')
    require(all(isinstance(r,dict) and r.get('status') in ('NEW_SOURCE','REUSE_MIGRATED') for r in plan['sources']),'UNKNOWN_SOURCE_STATUS')
    rows=[r for r in plan['sources'] if r['status']=='NEW_SOURCE'];require(bool(rows),'NO_NEW_SOURCE_EXECUTIONS')
    keyed={source_key(r):r for r in rows};require(len(keyed)==len(rows),'DUPLICATE_SOURCE_JOB_KEY')
    for row in rows:
        require(isinstance(row.get('dataset'),str) and bool(row['dataset']) and isinstance(row.get('knowledge_base_id'),str)
            and re.fullmatch('[0-9a-f-]{36}',row['knowledge_base_id']) and fingerprint(row.get('source_sha256')),'SOURCE_IDENTITY_INVALID')
        require(row.get('embedding_model_id')==MODEL['model_id'] and integer(row.get('child_count')),'SOURCE_MODEL_OR_CHUNK_COUNT_INVALID')
        require(integer(row.get('embedding_calls_upper'),high=12) and integer(row.get('token_reservation_upper'),high=100000),
            'PER_DOCUMENT_BOUND_EXCEEDS_SUPPORTED_FILE_LIMIT:'+str(row.get('dataset'))+':'+str(row.get('unit_id')))
        require(row['embedding_calls_upper']>=(row['child_count']+15)//16
            and row['token_reservation_upper']>=1024*row['embedding_calls_upper'],'SOURCE_BOUND_NOT_SUFFICIENT')
    count=len(rows);children=sum(r['child_count'] for r in rows);calls=sum(r['embedding_calls_upper'] for r in rows);tokens=sum(r['token_reservation_upper'] for r in rows)
    require(type(approval.get('new_sources')) is int and approval['new_sources']==count
        and type(approval.get('new_child_chunks')) is int and approval['new_child_chunks']==children,'OWNER_EXACT_SOURCE_AND_CHUNK_SET_MISMATCH')
    require(calls<=approval['max_calls'] and tokens<=approval['max_tokens'],'PREALLOCATED_SUM_EXCEEDS_OWNER_CAPS')
    require({'postgres_system_id':args.postgres_system_id,'database':args.database}==TARGET and args.storage_root==STORAGE,'EXACT_VERIFIED_TARGET_REQUIRED')
    require(re.fullmatch('[a-zA-Z0-9][a-zA-Z0-9_-]{0,79}',args.run_id) is not None,'SAFE_RUN_ID_REQUIRED')
    output=PurePosixPath(args.output_root)
    require(str(output)==args.output_root and EXECUTION_ROOT in output.parents and '..' not in output.parts and output.name==args.run_id,'APPROVED_EXECUTION_ROOT_REQUIRED')
    require(not Path(args.output_root).exists(),'EXISTING_AUTHORIZATION_DIRECTORY_NO_OVERWRITE')
    return {'approval':approval,'plan':plan,'keyed':keyed,'subject':subject,'sources':count,'children':children,'calls':calls,'tokens':tokens}

def build_documents(args,data):
    approval=data['approval'];goal_sha=approval['owner_goal_sha256'];root=PurePosixPath(args.output_root);executions={};documents=[]
    for key,row in sorted(data['keyed'].items()):
        filename='doc-'+key+'.json';executions[key]=str(root/filename)
        ledger={'schema':'s8-overnight-document-execution/v1','status':'OPEN','tenant_id':332,'subject_id':data['subject'],
            'max_calls':row['embedding_calls_upper'],'max_tokens':row['token_reservation_upper'],'allowed_kbs':[row['knowledge_base_id']],
            'allowed_request_prefixes':['*'],'allowed_models':[MODEL],'capture_evidence':True,'entries':[],
            'owner_goal_sha256':goal_sha,'approval_sha256':args.approval_sha256,'plan_sha256':args.plan_sha256,'source_key':key,'run_id':args.run_id}
        documents.append((filename,ledger))
    report={'status':'PREPARED_NO_SENDS' if args.write else 'VALIDATED_NOT_WRITTEN','sources':data['sources'],'child_chunks':data['children'],
        'max_calls':approval['max_calls'],'max_tokens':approval['max_tokens'],'sum_document_call_caps':data['calls'],'sum_document_token_caps':data['tokens'],
        'plan_sha256':args.plan_sha256,'approval_sha256':args.approval_sha256,'new_provider_calls':0,'dynamic_renewal':False}
    parent={'schema':'s8-overnight-owner-authorization/v1','status':'OPEN','owner_goal_sha256':goal_sha,'approval_sha256':args.approval_sha256,
        'owner_question_id':approval['owner_question_id'],'plan_sha256':args.plan_sha256,'tenant_id':332,'subject_sha256':data['plan']['subject_sha256'],
        'run_id':args.run_id,'max_calls':approval['max_calls'],'max_tokens':approval['max_tokens'],'resource_identity':TARGET,'storage_root':STORAGE,
        'executions':executions,'QA_authorized':False,'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'preallocated_calls':data['calls'],'preallocated_tokens':data['tokens'],'no_renewal':True}
    documents.extend([('approval-evidence.json',approval),('preparation-report.json',report),('parent.json',parent)])
    return documents,report

def write_exclusive(path,value):
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w',encoding='utf-8') as f:
        f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n');f.flush();os.fsync(f.fileno())

def materialize(args,documents):
    require(os.name=='posix' and os.geteuid()==0,'LINUX_ROOT_REQUIRED')
    root=Path(args.output_root);require(Path(str(EXECUTION_ROOT)).resolve(strict=True)==Path(str(EXECUTION_ROOT)),'EXECUTION_ROOT_SYMLINK_DENIED')
    require(root.parent.resolve(strict=True)==root.parent,'EXECUTION_PARENT_SYMLINK_DENIED')
    mask=os.umask(0o077)
    try:
        root.mkdir(mode=0o700,parents=False,exist_ok=False)
        for filename,value in documents:write_exclusive(root/filename,value)
        descriptor=os.open(root,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(descriptor)
        finally:os.close(descriptor)
    finally:os.umask(mask)

def arguments(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    for name in ('approval','approval-sha256','plan','plan-sha256','principal-state','postgres-system-id','database','storage-root','run-id','output-root'):p.add_argument('--'+name,required=True)
    p.add_argument('--owner-goal');p.add_argument('--write',action='store_true');return p.parse_args(argv)

def main(argv=None):
    args=arguments(argv);data=validate(args);documents,report=build_documents(args,data)
    if args.write:materialize(args,documents)
    print(json.dumps(report,ensure_ascii=False));return report

if __name__=='__main__':
    try:main()
    except (ValueError,OSError,KeyError,TypeError,json.JSONDecodeError) as exc:
        print(json.dumps({'status':'REFUSED_NO_SENDS','error':str(exc) if isinstance(exc,ValueError) else type(exc).__name__}));raise SystemExit(2)
