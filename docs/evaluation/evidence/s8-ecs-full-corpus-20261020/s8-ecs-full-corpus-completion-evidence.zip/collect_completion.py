"""Download completed S8 evidence only; no secrets, Provider sends or DB writes."""
import subprocess,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
REMOTE=r'''
import json,hashlib,subprocess
from pathlib import Path
r=Path('/opt/rag-s8')
files={
 'full-parent.json':r/'state/executions/s8-full-corpus-20261020/parent.json',
 'full-ingestion-results.json':r/'state/checkpoints/full-corpus-20261020/ingestion-results.json',
 'full-checkpoint.json':r/'state/checkpoints/full-corpus-20261020/checkpoint.json',
 'old-parent-final.json':r/'state/executions/s8-overnight-20261020/parent.json',
 'old-ingestion-results-final.json':r/'state/checkpoints/ingestion-20261020/ingestion-results.json',
 'remote-resource-identity.json':r/'reports/resource-identity.json',
 'remote-handoff-proof.json':r/'full-corpus-20261020/handoff-proof.json',
 'remote-ecs-source-origins.json':r/'full-corpus-20261020/config/ecs-source-origins.json',
 'remote-loaded-images.json':r/'config/loaded-images.json',
 'remote-migration-assets.json':r/'state/reports/migration-target-assets.json'}
out={}
for name,path in files.items():
 raw=path.read_bytes();out[name]={'source_path':str(path),'source_sha256':hashlib.sha256(raw).hexdigest(),'data':json.loads(raw)}
for mode,name in [('full-corpus-status.py','current-full-status'),('status.py','current-old-status')]:
 p=subprocess.run(['python3',str(r/'state'/mode)],capture_output=True,text=True,timeout=35)
 assert p.returncode==0;out[name]={'data':json.loads(p.stdout)}
print(json.dumps(out,ensure_ascii=False,separators=(',',':')))
'''
cmd=['ssh.exe','-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes','-o','ConnectTimeout=15','-i','C:/Users/22088/Downloads/study-plan-dev.pem','root@120.55.115.162','python3 -']
p=subprocess.run(cmd,input=REMOTE.encode(),capture_output=True,timeout=120)
(R/'completion-collection.stderr').write_bytes(p.stderr)
assert p.returncode==0,p.stderr.decode(errors='replace')
data=json.loads(p.stdout)
dest=R/'completion';dest.mkdir(exist_ok=True)
manifest={}
for name,item in data.items():
 target=dest/name
 raw=(json.dumps(item['data'],ensure_ascii=False,indent=2)+'\n').encode()
 target.write_bytes(raw);manifest[name]={'source_path':item.get('source_path'),'source_sha256':item.get('source_sha256'),'downloaded_sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}
(dest/'download-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'downloaded_files':len(data),'directory':str(dest),'new_state':data['full-ingestion-results.json']['data']['state'],
 'new_documents':len(data['full-ingestion-results.json']['data']['documents']),'new_calls':data['full-parent.json']['data']['actual_calls'],
 'new_tokens':data['full-parent.json']['data']['actual_reported_tokens'],'remote_mutations':0,'provider_requests':0}))
