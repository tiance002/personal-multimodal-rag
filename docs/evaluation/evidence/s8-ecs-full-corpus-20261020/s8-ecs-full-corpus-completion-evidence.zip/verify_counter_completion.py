"""Read-only remote terminal audit. Never imports a runner or reads secrets."""
import collections,datetime,hashlib,json,re,subprocess
from pathlib import Path

R=Path('/opt/rag-s8')
MODEL={'provider':'siliconflow','model':'BAAI/bge-m3','model_id':'mdlebb9931ff609b45a70a6c29c6712caa66c6b657ce4d1f802ee114bed2e779','capability':'embedding'}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def read(path):return json.loads(Path(path).read_text())
def require(ok,code):
    if not ok:raise ValueError(code)

def audit_job(name,config,checkpoint_name,expected_sources,expected_calls,expected_tokens):
    directory=R/'state/executions'/name;parent_path=directory/'parent.json';parent_raw=parent_path.read_bytes();parent=json.loads(parent_raw)
    plan=read(config);plan_sha=sha(canonical(plan).encode())
    require(parent['schema']=='s8-overnight-owner-authorization/v1' and parent['status']=='CLOSED'
        and parent['tenant_id']==332 and parent['plan_sha256']==plan_sha,'PARENT_CLOSED_EXACT_PLAN_REQUIRED')
    rows={sha(canonical([r['dataset'],r['knowledge_base_id'],r['source_sha256']]).encode()):r
        for r in plan['sources'] if r['status']=='NEW_SOURCE'}
    require(set(rows)==set(parent['executions']),'EXACT_REGISTERED_SOURCE_SET_REQUIRED')
    counts=collections.Counter();models=collections.Counter();calls=tokens=held=reserved=0;ids=set();entry_fingerprint=[];file_fingerprint=[];usage_by_dataset=collections.defaultdict(lambda:{'calls':0,'tokens':0})
    per_source={};allocated_calls=allocated_tokens=0
    for key,filename in sorted(parent['executions'].items()):
        path=Path(filename);require(path.resolve().parent==directory.resolve(),'EXECUTION_PATH_SCOPE_MISMATCH')
        raw=path.read_bytes();data=json.loads(raw);row=rows[key]
        require(data['status']=='CLOSED' and data['tenant_id']==332
            and sha(data['subject_id'].encode())==parent['subject_sha256']==plan['subject_sha256']
            and data['allowed_kbs']==[row['knowledge_base_id']] and data['allowed_models']==[MODEL],
            'FILE_CLOSED_SCOPE_OR_MODEL_MISMATCH')
        require(data['max_calls']==row['embedding_calls_upper']<=12
            and data['max_tokens']==row['token_reservation_upper']<=100000,'FROZEN_FILE_ALLOCATION_CHANGED')
        allocated_calls+=data['max_calls'];allocated_tokens+=data['max_tokens']
        require(len(data['entries'])<=data['max_calls'],'FILE_CALL_LIMIT_EXCEEDED')
        file_tokens=0
        for entry in data['entries']:
            counts[entry['status']]+=1
            require(entry['status']=='SETTLED' and entry.get('outcome')=='RESPONSE_RECEIVED','UNKNOWN_OR_UNSETTLED_MUST_REMAIN_STOPPED')
            require({k:entry[k] for k in MODEL}==MODEL,'ACTUAL_MODEL_IDENTITY_MISMATCH')
            identity=sha(json.dumps([entry['request_id'],entry['capability']]).encode())
            require(entry['id']==identity and identity not in ids,'DUPLICATE_PROVIDER_OPERATION')
            ids.add(identity);usage=entry.get('usage') or {}
            require(usage.get('status')=='REPORTED' and type(usage.get('total_tokens')) is int
                and 0<=usage['total_tokens']==entry['held_tokens']<=entry['reserved_tokens'],'ACTUAL_USAGE_INVALID')
            if usage.get('prompt_tokens') is not None and usage.get('completion_tokens') is not None:
                require(usage['prompt_tokens']+usage['completion_tokens']==usage['total_tokens'],'USAGE_PARTS_MISMATCH')
            calls+=1;tokens+=usage['total_tokens'];held+=entry['held_tokens'];reserved+=entry['reserved_tokens'];file_tokens+=entry['held_tokens']
            models[(entry['provider'],entry['model'],entry['capability'])]+=1
            entry_fingerprint.append([path.name,identity,entry['wire_sha256'],usage['total_tokens']])
        require(file_tokens<=data['max_tokens'],'FILE_TOKEN_LIMIT_EXCEEDED')
        usage_by_dataset[row['dataset']]['calls']+=len(data['entries']);usage_by_dataset[row['dataset']]['tokens']+=file_tokens
        per_source[key]={'provider_calls':len(data['entries']),'reported_tokens':file_tokens}
        file_fingerprint.append([path.name,sha(raw)])
    cp_path=R/'state/checkpoints'/checkpoint_name/'checkpoint.json';result_path=cp_path.with_name('ingestion-results.json')
    cp,result=read(cp_path),read(result_path)
    require(cp==result and cp['state']=='INDEX_READY' and cp['plan_sha256']==plan_sha
        and len(cp['documents'])==expected_sources,'FINAL_CHECKPOINT_RESULTS_MISMATCH')
    states=collections.Counter();datasets=collections.defaultdict(lambda:collections.Counter());versions=set();documents=set()
    for key,record in cp['documents'].items():
        states[record['state']]+=1;datasets[record['dataset']][record['state']]+=1
        require(record['state'] in ('INDEXED','REUSED_INDEXED') and record.get('document_id')
            and record.get('source_version') and record.get('dimension')==1024
            and record.get('first_source_readable') is True,'DOCUMENT_TERMINAL_PROOF_MISSING')
        require(record['document_id'] not in documents and record['source_version'] not in versions,'DUPLICATE_DOCUMENT_OR_VERSION')
        documents.add(record['document_id']);versions.add(record['source_version'])
        if key in rows:
            require(record['state']=='INDEXED' and record.get('original_sha256')==rows[key]['source_sha256']
                and record['child_count']==record['embedding_count']==rows[key]['child_count']
                and record['provider_calls']==per_source[key]['provider_calls']
                and record['reported_tokens']==per_source[key]['reported_tokens'],'SOURCE_CHECKPOINT_LEDGER_MISMATCH')
    require(calls==expected_calls==parent['actual_calls']==cp['provider_calls']
        and tokens==held==expected_tokens==parent['actual_reported_tokens']==cp['reported_tokens'],
        'FINAL_ACTUAL_TOTAL_MISMATCH')
    require(allocated_calls<=parent['max_calls'] and allocated_tokens<=parent['max_tokens']
        and parent['unused_calls_withdrawn']==parent['max_calls']-calls
        and parent['unused_token_space_withdrawn']==parent['max_tokens']-tokens,'FINAL_ALLOWANCE_WITHDRAWAL_MISMATCH')
    return {'status':'PASS_CLOSED_EXACT_SET_FULL_LEDGER_SCAN','parent_sha256':sha(parent_raw),
        'checkpoint_sha256':sha(cp_path.read_bytes()),'results_sha256':sha(result_path.read_bytes()),
        'plan_sha256':plan_sha,'execution_files':len(rows),'execution_file_states':{'CLOSED':len(rows)},
        'entry_states':dict(counts),'actual_calls':calls,'reported_tokens':tokens,'held_tokens':held,
        'original_reservation_sum':reserved,'allocated_max_calls':allocated_calls,'allocated_max_tokens':allocated_tokens,
        'parent_max_calls':parent['max_calls'],'parent_max_tokens':parent['max_tokens'],
        'unused_calls_withdrawn':parent['unused_calls_withdrawn'],'unused_token_space_withdrawn':parent['unused_token_space_withdrawn'],
        'unknown_entries':counts.get('UNKNOWN',0),'unreported_usage':0,'duplicate_operation_ids':0,
        'ledger_files_sha256':sha(canonical(file_fingerprint).encode()),'entries_identity_sha256':sha(canonical(entry_fingerprint).encode()),
        'models':[{'provider':k[0],'model':k[1],'capability':k[2],'calls':v} for k,v in models.items()],
        'document_states':dict(states),'dataset_states':{k:dict(v) for k,v in datasets.items()},'usage_by_dataset':dict(usage_by_dataset),
        'document_and_version_unique':True,'all_first_source_readbacks_saved_true':True,'final_result_equals_checkpoint':True}

def command(args):
    p=subprocess.run(args,capture_output=True,text=True,timeout=20)
    return {'exit_code':p.returncode,'output':p.stdout.strip()}

new=audit_job('s8-full-corpus-20261020',R/'full-corpus-20261020/config/ingestion-plan.json','full-corpus-20261020',10935,11332,5934546)
old=audit_job('s8-overnight-20261020',R/'config/ingestion-plan.json','ingestion-20261020',748,745,557090)
unit=command(['systemctl','show','rag-s8-full-corpus-20261020.service','--property=MainPID,ExecMainStatus,ActiveState,SubState,Result,ExecMainExitTimestamp,UnitFileState'])
properties=dict(line.split('=',1) for line in unit['output'].splitlines() if '=' in line)
require(unit['exit_code']==0 and properties.get('MainPID')=='0' and properties.get('ExecMainStatus')=='0'
    and properties.get('ActiveState')=='inactive' and properties.get('SubState')=='dead','TASK_NOT_ZERO_EXIT_TERMINAL')
active=command(['docker','ps','--filter','name=rag-s8-full-corpus-20261020','--format','{{.Names}}'])
require(active['exit_code']==0 and not active['output'],'INGESTION_CONTAINER_STILL_RUNNING')
tool=R/'full-corpus-20261020/tools/s8_execution_counter.py';wrapper=R/'state/run_full_corpus.py'
tool_sha=sha(tool.read_bytes());wrapper_sha=sha(wrapper.read_bytes())
require(tool_sha=='d21de8ac1eebb04ae72010af5d9078ef64c85b0903cd328619d03d8fbc4f00be'
    and wrapper_sha=='f3039f2a7e9971fe4a29187a696bb68e6e94c3f755a05881cad0e572ca33073c','ACTUAL_COUNTER_OR_WRAPPER_CHANGED')
unit_text=Path('/etc/systemd/system/rag-s8-full-corpus-20261020.service').read_text()
require('python /opt/rag-s8/state/run_full_corpus.py' in unit_text and 'Restart=no' in unit_text,'EXECUTED_COMMAND_NOT_PINNED_WRAPPER')
stopped=R/'state/checkpoints/full-corpus-20261020/runner-stopped.json'
require(not stopped.exists(),'STOPPED_RECEIPT_PRESENT')
stdout=R/'logs/full-corpus-20261020.log';stderr=R/'logs/full-corpus-20261020.stderr.log'
lines=stdout.read_text().splitlines();indexed=[]
for line in lines:
    try:row=json.loads(line)
    except json.JSONDecodeError:continue
    if row.get('state')=='INDEXED':indexed.append(row)
require(len(indexed)==10935 and sum(r['provider_calls'] for r in indexed)==11332
    and sum(r['reported_tokens'] for r in indexed)==5934546,'ACTUAL_TERMINAL_LOG_TOTAL_MISMATCH')
out={'schema':'s8-full-counter-completion-audit/v1','status':'PASS','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'new_job':new,'old_job':old,'combined_new_embedding_calls':12077,'combined_new_embedding_reported_tokens':6491636,
    'systemd':unit,'active_ingestion_containers':0,'single_instance_terminal':'NO_RUNNING_OR_DUPLICATE_FULL_JOB',
    'counter_finish':{'status':'EXECUTED_ZERO_EXIT_PINNED_CONTROL_FLOW','direct_finish_log_event':'NOT_EMITTED_BY_TOOL',
        'evidence':'Actual unit executes pinned wrapper; installed run_ingestion awaits native runner then synchronously calls finish(). Any finish exception is caught by native main and exits1. Actual MainPID0/ExecMainStatus0, no stopped receipt, all10935 INDEXED log rows, independently reread all10935 closed ledgers and equality. This is runtime/control-flow evidence, not a standalone finish log event.',
        'counter_sha256':tool_sha,'wrapper_sha256':wrapper_sha,'native_result_and_final_scan_agree':True},
    'logs':{'stdout_sha256':sha(stdout.read_bytes()),'stdout_bytes':stdout.stat().st_size,'indexed_rows':len(indexed),
        'stderr_sha256':sha(stderr.read_bytes()) if stderr.exists() else None,'stderr_bytes':stderr.stat().st_size if stderr.exists() else 0},
    'unknown_scope':'New jobs contain0 UNKNOWN. Existing unrelated historical UNKNOWN are neither read nor modified by this audit; zero here never clears historical UNKNOWN.',
    'new_provider_calls':0,'database_writes':0,'remote_mutations':0}
print(json.dumps(out,ensure_ascii=False))
