"""Disable only the two successfully completed one-shot jobs, preserving state."""
import json,subprocess,datetime
from pathlib import Path
R=Path('/opt/rag-s8');out=[]
for unit,folder,expected in [('rag-s8-ingestion-20261020.service','ingestion-20261020',748),('rag-s8-full-corpus-20261020.service','full-corpus-20261020',10935)]:
 data=json.loads((R/'state/checkpoints'/folder/'ingestion-results.json').read_text())
 assert data['state']=='INDEX_READY' and len(data['documents'])==expected
 p=subprocess.run(['systemctl','show',unit,'--property=ActiveState,MainPID,ExecMainStatus'],capture_output=True,text=True,timeout=15)
 assert p.returncode==0 and 'MainPID=0' in p.stdout and 'ExecMainStatus=0' in p.stdout and 'ActiveState=inactive' in p.stdout
 q=subprocess.run(['systemctl','disable',unit],capture_output=True,text=True,timeout=20);assert q.returncode==0,q.stderr
 verify=subprocess.run(['systemctl','show',unit,'--property=UnitFileState,ActiveState,MainPID,ExecMainStatus'],capture_output=True,text=True,timeout=15)
 assert verify.returncode==0 and 'UnitFileState=disabled' in verify.stdout
 out.append({'unit':unit,'disable_exit':q.returncode,'state':verify.stdout,'checkpoints_and_ledgers_preserved':True})
receipt={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'COMPLETED_ONESHOTS_DISABLED_NO_DATA_DELETED','units':out,
 'provider_calls':0,'business_database_writes':0,'api_worker_pg_redis_stopped':False}
(R/'reports/completed-jobs-retired.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
