"""Pinned SSH route; no model send or remote file/database write."""
import subprocess,json,sys
from pathlib import Path
R=Path(__file__).resolve().parent
cmd=['ssh.exe','-T','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','IdentitiesOnly=yes','-o','ConnectTimeout=15','-i','C:/Users/22088/Downloads/study-plan-dev.pem','root@120.55.115.162','python3 -']
label=sys.argv[1] if len(sys.argv)>1 else 'final-audit'
assert label.startswith('final-audit') and '/' not in label and '\\' not in label
script=sys.argv[2] if len(sys.argv)>2 else 'final-audit.remote.py'
assert script.startswith('final-audit.') and '/' not in script and '\\' not in script
assert not (R/(label+'.stdout')).exists() and not (R/(label+'.stderr')).exists(),'PRESERVE_PREVIOUS_AUDIT'
p=subprocess.run(cmd,input=(R/script).read_bytes(),capture_output=True,timeout=360)
(R/(label+'.stdout')).write_bytes(p.stdout);(R/(label+'.stderr')).write_bytes(p.stderr)
print(json.dumps({'exit_code':p.returncode,'stdout_bytes':len(p.stdout),'stderr_bytes':len(p.stderr)}));raise SystemExit(p.returncode)
