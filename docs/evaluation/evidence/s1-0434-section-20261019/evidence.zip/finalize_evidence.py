"""Offline source-bound checks; no database, Provider, Gold or ideal Context."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import sys
import zipfile

ROOT = Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
sys.path.insert(0, str(ROOT))
from backend.weknora_port.ingestion.core import DocumentRequest, ParserRegistry, ingest_document
from backend.weknora_port.ingestion.mineru import ENGINE, normalize_archive, public_chunk_locators
from backend.weknora_port.retrieval.rerank import model_passage
from backend.weknora_port.retrieval.types import SearchResult

OUT = Path(__file__).parent
SOURCE = Path(r'E:\WK\run\p11-real-20261016\B\assets\332\7f1d720d-9561-446f-a8cc-6a562c339d23\4019d2aa-c21d-42c2-8e8f-4d5aee4039ce\03f5a072-4021-4aca-9233-2dca910614f2\original\catvsdogdlpycon15se-150512122612-lva1-app6891_95.pdf')
sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
assert sha == '40a74d3fc5e73c81465206a4043c19b850daf66fc5617756f5894d25ad054b4b'
request = DocumentRequest(SOURCE.name, SOURCE.read_bytes(), 'offline', 'isolated-no-db',
    '0434-source-diag', 'local-20261019', parser_engine=ENGINE,
    kb_chunking_config={'chunk_size': 512, 'chunk_overlap': 80})
folder = OUT / 'pdf-pages-33-35-final'
receipt = json.loads((folder / 'receipt.json').read_text(encoding='utf-8'))
converted = normalize_archive(request, (folder / 'result.zip').read_bytes(), receipt, allow_partial=True)
registry = ParserRegistry(); registry.register(ENGINE, ('.pdf',), lambda _: converted.parsed)
result = ingest_document(request, registry)
assert 'Coding time!' in converted.parsed.content
targets = [row for row in result.chunks if "Kaggle's Cat vs Dog dataset" in row.content]
assert targets and all(row.metadata['page_numbers'] == [34] for row in targets)
assert all(row.context_header == "Kaggle's Cat vs Dog dataset (25k dog/cat pictures)" for row in targets)
assert not any('Coding time!' in row.context_header for row in targets)
assert all(row.content == converted.parsed.content[row.start:row.end] for row in result.chunks)
assets = [{'logical_path': asset.path, 'sha256': hashlib.sha256(asset.data).hexdigest()}
          for asset in converted.parsed.assets]
docmeta = {'sha256': sha, 'source_version': request.source_version,
           'parser_metadata': dict(converted.parsed.metadata), 'assets': assets}
rows = []
for row in result.chunks:
    public = public_chunk_locators(row.metadata, docmeta, row.document_id, row.source_version,
        row.start, row.end, row.content)
    rows.append({'id': row.source_id, 'content': row.content, 'context_header': row.context_header,
        'page_numbers': row.metadata['page_numbers'], 'start': row.start, 'end': row.end,
        'source_version': row.source_version, 'source_locations': public,
        'model_passage': model_passage(SearchResult(row.source_id, row.content, 0,
            knowledge_id=row.document_id, knowledge_base_id=row.knowledge_base_id,
            knowledge_title=SOURCE.stem, context_header=row.context_header))})
parent_req = replace(request, kb_chunking_config={'enable_parent_child': True,
    'parent_chunk_size': 512, 'child_chunk_size': 120, 'chunk_size': 120, 'chunk_overlap': 15})
pc = ingest_document(parent_req, registry)
parents = {r.source_id: r for r in pc.chunks if r.role == 'parent'}
for child in (r for r in pc.chunks if r.role == 'child'):
    # Existing splitter deliberately emits direct children for small source
    # units; only non-null parent references must resolve to stored parents.
    if child.parent_source_id is None:
        assert child.content == converted.parsed.content[child.start:child.end]
        continue
    assert child.parent_source_id in parents
    parent = parents[child.parent_source_id]
    assert parent.start <= child.start < child.end <= parent.end
    assert child.metadata['page_numbers'] == parent.metadata['page_numbers']
with zipfile.ZipFile(folder / 'result.zip') as z:
    overlay = json.loads(z.read('image_ocr.json'))
title_records = [{'page_idx': r['page_idx'], 'block_path': r['block_path'],
    'asset_sha256': r['asset_sha256'], 'image_path': r['image_path'], 'width': r['width'], 'height': r['height'], 'line': line}
    for r in overlay['records'] for line in r['lines'] if line['text'] == 'Coding time!']
assert title_records and all(t['page_idx'] == 32 for t in title_records)
record = {'status': 'LOCAL_OCR_AND_PAGE_HEADING_FLOW_PASS_CROSS_PAGE_SECTION_UNVERIFIED',
    'mode': 'BOUNDED_REAL_PDF_PARSE_NOT_HTTP_OR_VECTOR_RAG', 'source_path': str(SOURCE),
    'source_sha256': sha, 'historical_document_id': '4019d2aa-c21d-42c2-8e8f-4d5aee4039ce',
    'historical_source_version': '03f5a072-4021-4aca-9233-2dca910614f2',
    'actual_parsed_physical_pages': [33, 34, 35], 'identity': converted.parsed.metadata['mineru_source'],
    'ocr_title_records': title_records, 'rows': rows, 'original_sdk_bytes_preserved': True,
    'all_quotes_read_back': True, 'parent_child_links_verified': True,
    'derived_sections': converted.parsed.metadata['mineru_sections'],
    'cross_page_chapter_link': 'UNVERIFIED; neither PDF outline nor explicit parent/section metadata exists',
    'new_database_writes': 0, 'new_provider_sends': 0, 'actual_rerank_score': 'NOT_RUN',
    'generation_answer_correctness': 'NOT_RUN', 'existing_index_updated': False}
for asset in converted.parsed.assets:
    path = OUT / 'source-assets' / asset.path; path.parent.mkdir(parents=True, exist_ok=True); path.write_bytes(asset.data)
(OUT / 'final-proof.json').write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'status': record['status'], 'title_records': len(title_records),
    'title_confidence': title_records[0]['line']['confidence'], 'chunk_count': len(rows),
    'pages': record['actual_parsed_physical_pages'], 'quotes_readback': True,
    'parent_child_verified': True, 'provider_sends': 0}, ensure_ascii=True))
