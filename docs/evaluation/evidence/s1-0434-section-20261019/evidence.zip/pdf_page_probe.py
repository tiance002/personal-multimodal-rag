import hashlib, importlib.util, json, socket, sys, time
from pathlib import Path

def denied(*args, **kwargs): raise RuntimeError('LOCAL_NETWORK_DENIED')
socket.socket.connect = socket.socket.connect_ex = socket.create_connection = denied
from mineru import parse
from mineru.kit.common import save_parse_result

def main():
    source, directory, helper_path = map(Path, sys.argv[1:])
    started = time.monotonic()
    result = parse(source, tier='basic', ocr_mode='ocr', image_analysis=False, page_range='33-35')
    save_parse_result(result, directory / 'sdk-result.zip', 'zip')
    spec = importlib.util.spec_from_file_location('local_mineru_image_helper', helper_path)
    helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    (directory / 'result.zip').write_bytes(helper.supplement_archive(
        (directory / 'sdk-result.zip').read_bytes(), digest, helper.local_recognizer()))
    (directory / 'receipt.json').write_text(json.dumps({'source_sha256': digest, 'source_page_count': 68,
        'page_range': '33-35', 'seconds': time.monotonic()-started, 'provider_sends': 0,
        'mode': 'LOCAL_BOUNDED_SOURCE_DIAGNOSTIC_NOT_FULL_UPLOAD', 'network_policy': 'deny_all_connect'}), encoding='utf-8')
    print('BOUNDED_REAL_PDF_PARSE_DONE')

if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    main()
