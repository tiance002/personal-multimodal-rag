"""P29-only, one-time SiliconFlow limit increment and closeout.
Reuses the existing P22 CAS/ledger snapshot primitives; never sends requests.
"""
import argparse, asyncio, hashlib, json, os, sys, uuid
from datetime import datetime, timezone
from pathlib import Path
sys.path.insert(0, r'E:\RAG-Worktrees\weknora-python-port-20261013')
from backend.weknora_port.storage.token_budget import encode
from scripts import weknora_port_p22_fence as p22
from scripts.weknora_port_mvp_real import connection

ROOT=Path(r'E:\WK\run\p29-20261017\fence')
GRANT='P29-20261017-SF-300000'
INCREMENT=300_000
SCOPE='P29 only: seven full RAG requests maximum: frozen 0434/0959/0958 each rerank on/off, empty-KB once; original questions, new sessions, existing indexes, model fallback; all SF auxiliary calls included; no uncertain resend; close unused headroom'

def require(ok, code):
    if not ok: raise RuntimeError(code)
def plain(v): return json.loads(json.dumps(v,default=str))
def digest(v): return hashlib.sha256(encode(plain(v)).encode('utf-8')).hexdigest()
def root():
    r=ROOT.resolve(); require(r.drive.upper()=='E:','P29_EVIDENCE_PATH_INVALID'); r.mkdir(parents=True,exist_ok=True); return r
def read(r,name):
    p=r/(name+'.json')
    if not p.exists(): return None
    env=json.loads(p.read_text(encoding='utf-8'))
    require(env.get('sha256')==digest(env.get('data')),'P29_RECEIPT_HASH_MISMATCH')
    return env['data']
def write(r,name,value):
    value=plain(value); old=read(r,name)
    if old is not None:
        require(old==value,'P29_IMMUTABLE_RECEIPT_CONFLICT'); return old
    target=r/(name+'.json'); temp=r/('.'+name+'-'+uuid.uuid4().hex+'.tmp')
    try:
        with temp.open('xb') as f:
            f.write((encode({'data':value,'sha256':digest(value)})+'\n').encode('utf-8')); f.flush(); os.fsync(f.fileno())
        try: os.link(temp,target)
        except FileExistsError: require(read(r,name)==value,'P29_IMMUTABLE_RECEIPT_CONFLICT')
    finally: temp.unlink(missing_ok=True)
    return value

def approval_text(): return Path(r'E:\WK\run\p29-20261017\p29-owner-authorization.txt').read_text(encoding='utf-8-sig')
def intent(r):
    owner=approval_text()
    expected={'schema':'weknora-p29-fence-intent/v1','grant_id':GRANT,'increment_tokens':INCREMENT,
      'account_id':'siliconflow-owner-main','provider':'siliconflow','month':'2026-10-01',
      'system_identifier':'7696088403504697382','database':'weknora_python_port_20261013',
      'scope':SCOPE,'approval_sha256':hashlib.sha256(owner.encode()).hexdigest(),'approval_text':owner}
    old=read(r,'intent')
    if old is not None: require(old==expected,'P29_GRANT_MISMATCH'); return old
    return write(r,'intent',expected)

def receipt(action,i,before,after):
    return {'schema':'weknora-p29-fence-receipt/v1','grant_id':GRANT,'action':action,
      'intent_sha256':digest(i),'before_sha256':digest(before),'before':before,'after':after,'commit_confirmed':False}
def check(r,action,i):
    v=read(r,action+'-after')
    require(v is not None and v.get('schema')=='weknora-p29-fence-receipt/v1' and v.get('grant_id')==GRANT
      and v.get('action')==action and v.get('intent_sha256')==digest(i)
      and v.get('before_sha256')==digest(v.get('before')),'P29_RECEIPT_MISMATCH')
    return v

async def open_fence():
    r=root(); i=intent(r)
    require(read(r,'close-before') is None and read(r,'close-after') is None,'P29_ALREADY_CLOSING')
    c=await connection()
    try:
        await p22._locked(c)
        async with c.transaction():
            await p22._identity_and_lock(c); current=await p22._snapshot(c)
            done=read(r,'open-after')
            if done:
                check(r,'open',i); require(done['commit_confirmed'] and current['month']['limit_tokens']==done['after']['month']['limit_tokens'],'P29_OPEN_STATE_CONFLICT')
                p22._preserved(done['before'],current); result=done
            else:
                prior=read(r,'open-before'); prepared=read(r,'open-precommit')
                if prepared and current['month']['limit_tokens']==prepared['after']['month']['limit_tokens']:
                    require(prior==prepared['before'],'P29_OPEN_RECOVERY_CONFLICT'); p22._preserved(prior,current); result=prepared
                else:
                    require(current['headroom']==0,'P29_BASELINE_HEADROOM_CHANGED')
                    if prior is not None: require(prior==current,'P29_BASELINE_CHANGED')
                    prior=write(r,'open-before',current); target=current['occupied_with_carry']+INCREMENT
                    after=await p22._change(c,prior,target); require(after['headroom']==INCREMENT,'P29_INCREMENT_MISMATCH')
                    result=write(r,'open-precommit',receipt('open',i,prior,after))
        if result.get('commit_confirmed'): pass
        result=write(r,'open-after',dict(result,commit_confirmed=True))
        return result
    finally: await c.close()

async def close_fence():
    r=root(); i=intent(r); opened=check(r,'open',i)
    require(opened.get('commit_confirmed') is True,'P29_OPEN_COMMIT_REQUIRED')
    c=await connection()
    try:
        await p22._locked(c)
        async with c.transaction():
            await p22._identity_and_lock(c); current=await p22._snapshot(c); p22._preserved(opened['before'],current)
            done=read(r,'close-after')
            if done:
                require(done.get('commit_confirmed') is True and done['after']==current,'P29_CLOSE_STATE_CONFLICT'); result=done
            else:
                prior=read(r,'close-before'); prepared=read(r,'close-precommit')
                if prepared and current==prepared['after']:
                    require(prior==prepared['before'],'P29_CLOSE_RECOVERY_CONFLICT'); result=prepared
                else:
                    require(current['month']['limit_tokens']==opened['after']['month']['limit_tokens'],'P29_OPEN_LIMIT_CHANGED')
                    if prior is not None: require(prior==current,'P29_CLOSE_BASELINE_CHANGED')
                    prior=write(r,'close-before',current); after=await p22._change(c,prior,current['occupied_with_carry'])
                    require(after['headroom']==0,'P29_CLOSE_HEADROOM_NOT_ZERO')
                    result=write(r,'close-precommit',receipt('close',i,prior,after))
        return write(r,'close-after',dict(result,commit_confirmed=True))
    finally: await c.close()

def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=('open','close'));a=ap.parse_args()
    try:
        with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner:
            result=runner.run(open_fence() if a.action=='open' else close_fence())
        print(encode({'status':'PASS','action':a.action,'grant_id':GRANT,'limit_tokens':result['after']['month']['limit_tokens'],'occupied_with_carry':result['after']['occupied_with_carry'],'headroom':result['after']['headroom'],'receipt':str(ROOT/(a.action+'-after.json'))}))
        return 0
    except Exception as e:
        code=str(e) if str(e).startswith('P29_') else 'P29_OPERATION_FAILED_'+type(e).__name__
        print(encode({'status':'FAIL','code':code}),file=sys.stderr);return 1
if __name__=='__main__': raise SystemExit(main())
