import argparse,asyncio
from pathlib import Path
from contextlib import asynccontextmanager
from scripts.weknora_port_p9_observed_api import observed_factory as base_factory
from scripts.weknora_port_p17_observed_api import RawResponse
from scripts.weknora_port_p8_1_observed_api import resolved

def factory(authority,evidence):
 base=base_factory(authority,evidence)
 @asynccontextmanager
 async def assemble(settings):
  async with base(settings) as app:
   build=app.model_factory
   async def model_factory(config,key,gate):
    model=await resolved(build(config,key,gate));original=model.transport.open
    @asynccontextmanager
    async def capture(config,path,body,context,**kwargs):
     async with original(config,path,body,context,**kwargs) as handle:
      proxy=RawResponse(handle.response,Path(evidence),context.request_id,kwargs['capability']) if '/answer/' in context.request_id else None
      if proxy:handle.response=proxy
      try:yield handle
      finally:
       if proxy:proxy.finish()
    model.transport.open=capture
    return model
   app.model_factory=model_factory
   yield app
 return assemble
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--port',type=int);p.add_argument('--authority-config');p.add_argument('--evidence-dir');a=p.parse_args()
 import uvicorn
 from backend.weknora_port.entrypoint import create_app
 server=uvicorn.Server(uvicorn.Config(create_app(runtime_factory=factory(a.authority_config,a.evidence_dir)),host='127.0.0.1',port=a.port))
 with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as r:r.run(server.serve())
