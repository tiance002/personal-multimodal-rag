import asyncio,json,hashlib
from pathlib import Path
from scripts.weknora_port_mvp_real import connection
out=Path('E:/WK/run/p29-20261017')
async def main():
 c=await connection()
 try:
  manifest=json.loads((out/'manifest.json').read_text(encoding='utf-8'));sessions=[x['session_id'] for x in manifest['cases']]
  calls=await (await c.execute("SELECT call_id,session_id,request_id,tenant_id,account_id,provider,model,capability,state,actual_total,held_tokens,usage_facts,finished_at FROM port_token_calls WHERE session_id=ANY(%s) ORDER BY call_id",(sessions,))).fetchall()
  assert len(calls)==31 and all(r['state']=='settled' and r['provider']=='siliconflow' for r in calls)
  assert sum(r['actual_total'] for r in calls)==50544
  ds=await (await c.execute("SELECT to_jsonb(t) AS row FROM port_token_calls t WHERE account_id='deepseek-owner-main' ORDER BY call_id")).fetchall()
  pre=json.loads((out/'preflight.json').read_text())
  assert hashlib.sha256(json.dumps(ds,sort_keys=True,default=str).encode()).hexdigest()==pre['deepseek_calls_sha256']
  old=await (await c.execute("SELECT count(*) AS n,sum(held_tokens) AS held FROM port_token_calls WHERE account_id='siliconflow-owner-main' AND state='unknown'")).fetchone()
  assert old['n']==61 and old['held']==823355
  (out/'actual-calls.json').write_text(json.dumps({'calls':calls,'settled_tokens':50544,'new_unknown':0,'historical_unknown':old,'deepseek_unchanged':True},indent=2,default=str)+'\n',encoding='utf-8')
  print('PASS actual31settled50544; SF61UNKNOWNheld823355 intact; DeepSeekcallhash unchanged')
 finally:await c.close()
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as r:r.run(main())
