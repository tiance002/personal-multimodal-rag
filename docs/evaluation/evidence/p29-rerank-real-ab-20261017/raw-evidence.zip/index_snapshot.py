import asyncio,json,sys
from pathlib import Path
from scripts.weknora_port_mvp_real import connection
async def main():
 c=await connection()
 try:
  out={}
  for table in ('knowledges','chunks','embeddings'):
   out[table]=await (await c.execute(f"SELECT count(*) AS rows, md5(string_agg(id::text||':'||md5(to_jsonb(t)::text),',' ORDER BY id)) AS rows_digest FROM {table} t WHERE knowledge_base_id=ANY(%s)",(['7f1d720d-9561-446f-a8cc-6a562c339d23','63236a5c-c0d6-499d-84e5-34475564f1c0'],))).fetchone()
  p=Path('E:/WK/run/p29-20261017/index-'+sys.argv[1]+'.json');p.write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
 finally:await c.close()
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as r:r.run(main())
