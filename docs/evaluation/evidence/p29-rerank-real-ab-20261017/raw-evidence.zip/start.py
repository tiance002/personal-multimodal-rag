import asyncio,json,os,socket,subprocess,sys
from pathlib import Path
import httpx
from scripts.weknora_port_mvp_real import dsn
ROOT=Path('E:/RAG-Worktrees/weknora-python-port-20261013');OUT=Path('E:/WK/run/p29-20261017')
async def main():
 assert not (OUT/'processes.json').exists()
 procs={}
 for tenant,port,source in [(332,56425,Path('E:/WK/run/p25-20261017/runtime')),(344,56427,Path('E:/WK/run/p27-live-20261017'))]:
  with socket.socket() as s: assert s.connect_ex(('127.0.0.1',port))!=0
  old=json.loads((source/'state.json').read_text(encoding='utf-8'));env={k:v for k,v in os.environ.items() if not k.startswith('WEKNORA_PORT_')}
  tmp=OUT/'tmp';tmp.mkdir(exist_ok=True)
  env.update(PYTHONPATH=';'.join([str(ROOT),'E:/WK/deps/reader',str(ROOT/'var/weknora-port/runtime-deps')]),PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',TEMP=str(tmp),TMP=str(tmp),WEKNORA_PORT_DATABASE_URL=dsn(),WEKNORA_PORT_DATABASE_SYSTEM_ID='7696088403504697382',WEKNORA_PORT_DATABASE_NAME='weknora_python_port_20261013',WEKNORA_PORT_REDIS_URL='redis://127.0.0.1:56424/15',WEKNORA_PORT_REDIS_RUN_ID=old['redis_run_id'],WEKNORA_PORT_REDIS_PREFIX=f'weknora-python-p29-20261017:{tenant}:ab',WEKNORA_PORT_STORAGE_ROOT=old['storage_root'],WEKNORA_PORT_SECRET_KEY_FILE=old['secret_key_file'],WEKNORA_PORT_TOKENIZER_ASSET='D:/RAG-Tokenizer-Assets/cl100k_base.tiktoken',WEKNORA_PORT_ROUTER_MODE='CHEAP_ONLY',WEKNORA_PORT_FALLBACK_STRATEGY='model',WEKNORA_PORT_ORIGINS='http://127.0.0.1:56426')
  cmd=[sys.executable,'-B',str(OUT/'observed.py'),'--port',str(port),'--authority-config',str(OUT/f'authority-{tenant}.json'),'--evidence-dir',str(OUT/f'evidence-{tenant}')]
  p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=(OUT/f'api-{tenant}.stdout.txt').open('ab'),stderr=(OUT/f'api-{tenant}.stderr.txt').open('ab'))
  procs[str(tenant)]={'pid':p.pid,'port':port,'command':cmd};(OUT/'processes.json').write_text(json.dumps(procs,indent=2))
  async with httpx.AsyncClient(trust_env=False,timeout=10) as c:
   for i in range(30):
    try:
     r=await c.get(f'http://127.0.0.1:{port}/readyz')
     if r.status_code==200:break
    except httpx.HTTPError:pass
    await asyncio.sleep(1)
   else:raise RuntimeError('notready')
   roles=await c.get(f'http://127.0.0.1:{port}/api/v1/settings/model-configuration');roles.raise_for_status()
   (OUT/f'roles-{tenant}.json').write_text(json.dumps(roles.json(),indent=2),encoding='utf-8')
 print(json.dumps({'ready':procs,'cloud_calls':0}))
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as r:r.run(main())
