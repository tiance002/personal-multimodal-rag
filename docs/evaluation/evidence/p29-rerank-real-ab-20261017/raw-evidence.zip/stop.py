import asyncio,json,subprocess
from pathlib import Path
from scripts.weknora_port_mvp_real import connection
out=Path('E:/WK/run/p29-20261017')
async def main():
 c=await connection()
 try:
  row=await (await c.execute("SELECT count(*) AS n FROM port_token_calls WHERE account_id='siliconflow-owner-main' AND state='reserved'")).fetchone();assert row['n']==0
 finally:await c.close()
 procs=json.loads((out/'processes.json').read_text());stopped=[]
 for tenant,p in procs.items():
  cmd=subprocess.check_output(['powershell','-NoProfile','-Command',f'(Get-CimInstance Win32_Process -Filter "ProcessId={p["pid"]}").CommandLine'],text=True)
  assert 'p29-20261017' in cmd and 'observed.py' in cmd and f'authority-{tenant}.json' in cmd
  subprocess.run(['taskkill','/PID',str(p['pid']),'/T','/F'],check=True,capture_output=True)
  stopped.append(p)
 (out/'stopped.json').write_text(json.dumps({'stopped_owned_processes':stopped,'reserved_before_stop':0,'queries_complete':7},indent=2))
 print('stopped only 2 P29 API process trees; 0 reserved; no worker started')
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as r:r.run(main())
