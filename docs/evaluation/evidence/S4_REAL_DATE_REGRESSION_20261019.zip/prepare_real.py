import asyncio,hashlib,json,os,sys,uuid
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
from scripts.local_runtime import load_config,environment,verify_resources
source_config=Path(r'E:\WK\run\s3-product-20261019\local.json')
cfg=load_config(source_config)
assert not (HERE/'local.json').exists()
for entry in cfg['environment'].get('PYTHONPATH','').split(os.pathsep):
    if entry:sys.path.insert(0,entry)
identity=asyncio.run(verify_resources(cfg),loop_factory=asyncio.SelectorEventLoop)
assert identity['tenant_id']==1 and identity['cloud_allowed'] is False
import psycopg
from psycopg.rows import dict_row
with psycopg.connect(environment(cfg)['WEKNORA_PORT_DATABASE_URL'],autocommit=True,row_factory=dict_row) as c:
    c.execute('BEGIN TRANSACTION READ ONLY')
    calls=c.execute('SELECT call_id,md5(row_to_json(p)::text) fingerprint FROM port_provider_calls p ORDER BY created_at,call_id').fetchall()
    principal=c.execute("SELECT tenant_id,subject_id FROM port_local_principal WHERE slot='local'").fetchone()
    assert principal['tenant_id']==1
    old_rows={table:c.execute(query,('d683c1b1-7268-45c2-8a05-23c94f4d5db0',)).fetchall() for table,query in (
        ('documents','SELECT id,md5(row_to_json(k)::text) fingerprint FROM knowledges k WHERE knowledge_base_id=%s'),
        ('chunks','SELECT id,md5(row_to_json(c)::text) fingerprint FROM chunks c WHERE knowledge_base_id=%s'),
        ('tasks','SELECT id,md5(row_to_json(t)::text) fingerprint FROM port_image_tasks t WHERE knowledge_base_id=%s'))}
    c.execute('ROLLBACK')
cfg['state_dir']=str(HERE/'runtime')
cfg['environment']['WEKNORA_PORT_REDIS_PREFIX']='weknora-python-s4-'+uuid.uuid4().hex
cfg['environment']['WEKNORA_PORT_EVIDENCE_DIR']=str(HERE/'evidence')
cfg['environment']['WEKNORA_PORT_CLOUD_ALLOWED']='false'
def save(name,data):
    with (HERE/name).open('x',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2,default=str)
save('local.json',cfg)
save('preflight.json',{'identity':identity,'calls_before':calls,'old_s3_rows':old_rows,
    'principal_sha256':hashlib.sha256(principal['subject_id'].encode()).hexdigest(),
    'old_s3_config_sha256':hashlib.sha256(source_config.read_bytes()).hexdigest()})
save('owner-authorization.json',{'owner_approved':True,'status':'OPEN',
    'owner_reply':'批准上述 S4 最小真实复验','recorded_at':datetime.now(timezone.utc).isoformat(),
    'tenant_id':1,'providers':['siliconflow','deepseek'],
    'models':['BAAI/bge-m3','BAAI/bge-reranker-v2-m3','Qwen/Qwen3.5-4B','deepseek-flash'],
    'max_provider_calls':12,'max_uploads':1,'max_questions':1,'max_caption_requests':0,
    'cloud_mode':'ordinary; existing Gate and ledger; no cumulative hard token/call fence',
    'stop_on_new_unknown':True,'no_retries':True,'source_sha256':'9cf9b35209cac1162a0edafe4f56616446bdfd3e1dadda5ce8bae0931853e1e5',
    'question':'What was the inspection date?','code_sha':'2e214051d7c00cac487fb1bd0382f18e8078c779'})
print(json.dumps({'identity':identity,'baseline_calls':len(calls),
    'principal_sha256':hashlib.sha256(principal['subject_id'].encode()).hexdigest(),
    'new_redis_prefix':cfg['environment']['WEKNORA_PORT_REDIS_PREFIX'],'provider_calls':0}))
