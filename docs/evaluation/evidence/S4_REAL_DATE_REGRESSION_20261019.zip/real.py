"""Single authorized S4 upload/question through the existing normal API."""
import json,sys,time,uuid,hashlib
from pathlib import Path
import httpx
ROOT=Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
import scripts.s3_product_check as helper
helper.RUN=HERE
read=helper.read
write=helper.write

def current():
    value=helper.snapshot()
    grant=read(HERE/'owner-authorization.json')
    assert grant['status']=='OPEN' and grant['owner_approved']
    calls=value['calls']
    bad=[c for c in calls if c['tenant_id']!=1 or c['provider'] not in grant['providers']
         or c['model'] not in grant['models'] or c['capability']=='vision'
         or c['outcome'] not in ('RESPONSE_RECEIVED','UNKNOWN')
         or (c['outcome']=='UNKNOWN' and c['finished_at'] is not None)]
    if bad or len(calls)>12:
        grant.update(status='STOP',stop_reason='NEW_UNKNOWN_OR_CALL_IDENTITY_OR_LIMIT')
        write(HERE/'owner-authorization.json',grant)
        raise RuntimeError('S4_STOP_NO_MORE_SENDS')
    return value

def configure(c):
    assert c.get('/readyz').json()['cloud_allowed'] is False
    roles=c.get('/api/v1/settings/model-configuration');roles.raise_for_status()
    cfg=roles.json();by={v['role']:v for v in cfg['data']['roles']}
    for role,model in [('embedding','BAAI/bge-m3'),('rerank','BAAI/bge-reranker-v2-m3'),('cheap','Qwen/Qwen3.5-4B'),('expensive','deepseek-flash')]:
        assert by[role]['model']==model and by[role]['credential_status']=='CONFIGURED'
    write(HERE/'public-model-roles.json',cfg)
    with (HERE/'create-kb.claim').open('x') as f:f.write('new S4 KB only')
    r=c.post('/api/v1/knowledge-bases',json={'name':'S4 日期修复复验 · 20261019'});r.raise_for_status()
    write(HERE/'kb-created.json',r.json());kb=r.json()['data']['id']
    r=c.patch(f'/api/v1/knowledge-bases/{kb}/external-processing',json={'cloud_allowed':True});r.raise_for_status()
    write(HERE/'kb-consent.json',r.json())
    r=c.patch(f'/api/v1/knowledge-bases/{kb}/image-processing',json={
        'enable_multimodal':True,'ocr_adapter':'mineru','caption_mode':'follow_ocr','caption_model_id':''})
    r.raise_for_status();write(HERE/'image-config.json',r.json())
    assert current()['calls']==[]
    print(json.dumps({'knowledge_base_id':kb,'provider_calls':0,'caption':'disabled; local OCR only'}),flush=True)

def upload(c):
    kb=read(HERE/'kb-created.json')['data']['id']
    assert c.get('/readyz').json()['cloud_allowed'] is True
    before=current();helper.validate_before_upload(before)
    source=Path(r'E:\WK\run\s3-product-20261019\samples\north_pier_inspection.pdf')
    assert hashlib.sha256(source.read_bytes()).hexdigest()==read(HERE/'owner-authorization.json')['source_sha256']
    with (HERE/'upload.claim').open('x') as f:f.write(str(source))
    start=time.monotonic()
    with source.open('rb') as f:r=c.post(f'/api/v1/knowledge-bases/{kb}/documents',files={'file':(source.name,f)})
    write(HERE/'upload.json',{'http_status':r.status_code,'body':r.json(),'seconds':time.monotonic()-start})
    r.raise_for_status();doc=r.json()['data'];states=[]
    while True:
        response=c.get(f'/api/v1/knowledge-bases/{kb}/documents');response.raise_for_status()
        row=next(v for v in response.json()['data'] if v['id']==doc['id'])
        if not states or states[-1]['status']!=row['status']:
            states.append({'status':row['status'],'seconds':time.monotonic()-start,'error':row.get('error_code')})
            write(HERE/'upload-states.json',states)
            print(json.dumps(states[-1]),flush=True)
        state=current();helper.validate_upload_snapshot(state,doc['id'],worker_active=helper._worker_is_active())
        if row['status'] not in ('pending','processing'):break
        if time.monotonic()-start>900:raise RuntimeError('LOCAL_UPLOAD_TIMEOUT_NO_RETRY')
        time.sleep(2)
    assert row['status']=='completed',row['status']
    print(json.dumps({'document_id':doc['id'],'status':row['status'],'provider_calls':len(state['calls'])}),flush=True)

def question(c):
    state=current();assert all(v['outcome']=='RESPONSE_RECEIVED' for v in state['calls'])
    assert len(state['calls'])<=4,'INSUFFICIENT_REMAINING_CALL_ENVELOPE'
    assert len(state['documents'])==1 and state['documents'][0]['parse_status']=='completed'
    assert not any(v['state'] in ('pending','processing') for v in state['tasks'])
    kb=read(HERE/'kb-created.json')['data']['id']
    with (HERE/'question.claim').open('x') as f:f.write('one normal API question; no retry')
    start=time.monotonic()
    r=c.post('/api/v1/sessions',json={'title':'S4 日期修复复验','knowledge_base_scope':[kb],'document_scope':[]});r.raise_for_status()
    sid=r.json()['data']['id'];qid=str(uuid.uuid4())
    body={'content':'What was the inspection date?','request_id':qid,'mode':'quick',
        'knowledge_base_scope':[kb],'document_scope':[],'reasoning_effort':'off'}
    receipt={'session_id':sid,'client_request_id':qid,'body':body}
    write(HERE/'question.json',receipt)
    with c.stream('POST',f'/api/v1/sessions/{sid}/messages',json=body,headers={'Accept':'text/event-stream'}) as response:
        receipt['http_status']=response.status_code;write(HERE/'question.json',receipt);response.raise_for_status()
        with (HERE/'question.sse').open('xb') as f:
            for part in response.iter_bytes():f.write(part);f.flush()
    receipt.update(client_seconds=time.monotonic()-start,sse_complete=True)
    write(HERE/'question.json',receipt)
    history=c.get(f'/api/v1/sessions/{sid}/messages');history.raise_for_status();write(HERE/'history.json',history.json())
    snapshot=current()
    print(json.dumps({'http_status':response.status_code,'client_seconds':receipt['client_seconds'],'calls':len(snapshot['calls'])}),flush=True)

if __name__=='__main__':
    action=sys.argv[1]
    with httpx.Client(base_url='http://127.0.0.1:56425',timeout=httpx.Timeout(600,connect=10),
            headers={'Origin':'http://127.0.0.1:56426','Accept-Language':'zh-CN'}) as client:
        if action=='configure':configure(client)
        elif action=='upload':upload(client)
        elif action=='question':question(client)
        elif action=='snapshot':
            s=current();print(json.dumps({'calls':len(s['calls']),'documents':len(s['documents'])}))
        else:raise ValueError('UNKNOWN_ACTION')
