"""Read-only continuation observer. It never sends a Provider request."""
import json
import sys
from pathlib import Path

ROOT = Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
sys.path.insert(0, str(ROOT))
from scripts.s3_product_check import snapshot, read, write

HERE = Path(__file__).resolve().parent
grant = read(HERE / 'owner-authorization.json')
assert grant['status'] == 'OPEN'
current = snapshot()
assert current['historical_calls_unchanged']
by_id = {c['call_id']: c for c in current['calls']}
baseline = grant['baseline_call_fingerprints']
assert all(by_id.get(k, {}).get('fingerprint') == v for k, v in baseline.items()), 'BASELINE_CHANGED'
new = [c for c in current['calls'] if c['call_id'] not in baseline]
assert all(c['tenant_id'] == grant['tenant_id'] and c['provider'] in grant['provider_allowlist']
           and c['model'] in grant['models'] for c in new), 'UNEXPECTED_NEW_CALL_IDENTITY'
terminal_unknown = [c for c in new if c['outcome'] == 'UNKNOWN' and c['finished_at'] is not None]
abnormal = [c for c in new if c['outcome'] not in {'RESPONSE_RECEIVED', 'UNKNOWN'}]
write(HERE / 'current.json', current)
if terminal_unknown or abnormal:
    grant['status'] = 'STOP'
    grant['stop_reason'] = 'NEW_TERMINAL_UNKNOWN_OR_ABNORMAL_CALL'
    grant['stop_request_ids'] = [c['request_id'] for c in terminal_unknown + abnormal]
    write(HERE / 'owner-authorization.json', grant)
    raise SystemExit('STOP: new terminal UNKNOWN/abnormal call; no new sends')
print(json.dumps({
    'baseline_calls_unchanged': len(baseline),
    'new_calls': len(new),
    'new_settled': sum(c['outcome'] == 'RESPONSE_RECEIVED' for c in new),
    'new_in_flight': sum(c['outcome'] == 'UNKNOWN' for c in new),
    'documents': [{'id': d['id'], 'file_name': d['file_name'], 'status': d['parse_status']}
                  for d in current['documents']],
    'tasks': [{'id': t['id'], 'state': t['state']} for t in current['tasks']],
    'turns': [{'run_id': t['run_id'], 'status': t['status'], 'error': t['error_code']}
              for t in current['turns']],
}, ensure_ascii=True))
