"""Record exactly one frozen browser question before its normal UI submission."""
import json
import runpy
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
qid = sys.argv[1]
runpy.run_path(str(HERE / 'check.py'), run_name='s3_continuation_observer')
grant = json.loads((HERE / 'owner-authorization.json').read_text(encoding='utf-8'))
snapshot = json.loads((HERE / 'current.json').read_text(encoding='utf-8'))
assert grant['status'] == 'OPEN' and qid in grant['question_ids']
assert all(c['outcome'] == 'RESPONSE_RECEIVED' for c in snapshot['calls']
           if c['call_id'] not in grant['baseline_call_fingerprints']), 'NEW_CALL_NOT_SETTLED'
assert all(d['parse_status'] == 'completed' for d in snapshot['documents'])
question = next(q for q in json.loads((RUN / 'samples/questions_expected.json').read_text(encoding='utf-8'))['questions'] if q['id'] == qid)['question']
assert not any(t['q0'] == question for t in snapshot['turns']), 'QUESTION_ALREADY_SUBMITTED'
with (HERE / (qid + '.question.claim')).open('x', encoding='utf-8') as f:
    json.dump({'question_id': qid, 'q0': question, 'channel': 'normal Edge UI',
               'recorded_at': datetime.now(timezone.utc).isoformat()}, f, ensure_ascii=False, indent=2)
print('Claimed', qid, question)
