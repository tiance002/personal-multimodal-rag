"""Claim each Owner-approved post-prompt case once; never resend old IDs."""
import json
import runpy
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
RUN = HERE.parent
case_id = sys.argv[1]
runpy.run_path(str(HERE / 'check.py'), run_name='s3_prompt_observer')
grant = json.loads((HERE / 'owner-authorization.json').read_text(encoding='utf-8'))
current = json.loads((HERE / 'current.json').read_text(encoding='utf-8'))
assert case_id in grant['question_cases'] and grant['status'] == 'OPEN'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == grant['code_sha']
assert all(c['outcome'] == 'RESPONSE_RECEIVED' for c in current['calls']
           if c['call_id'] not in grant['baseline_call_fingerprints'])
qid = case_id.removesuffix('-regression')
q = next(q for q in json.loads((RUN / 'samples/questions_expected.json').read_text(encoding='utf-8'))['questions'] if q['id'] == qid)
prior = [t for t in current['turns'] if t['q0'] == q['question']]
if case_id.endswith('-regression'):
    assert qid in {'s3-q1', 's3-q3'} and len(prior) == 1 and prior[0]['status'] == 'error'
else:
    assert not prior
assert len(list(HERE.glob('*.question.claim'))) < grant['max_new_questions']
with (HERE / (case_id + '.question.claim')).open('x', encoding='utf-8') as f:
    json.dump({'case_id': case_id, 'question_id': qid, 'q0': q['question'],
               'code_sha': grant['code_sha'], 'previous_runs': [t['run_id'] for t in prior],
               'recorded_at': datetime.now(timezone.utc).isoformat(),
               'channel': 'normal Edge new session/new request_id'}, f, ensure_ascii=False, indent=2)
print('Claimed', case_id, q['question'])
