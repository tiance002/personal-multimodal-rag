# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: adapter.spec.ts >> live empty shows final output status without retry
- Location: tests\weknora-port\adapter.spec.ts:30:3

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.wp-message.assistant').getByText('模型未返回可用答案；运行终态已保存，未重新生成。', { exact: true })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('.wp-message.assistant').getByText('模型未返回可用答案；运行终态已保存，未重新生成。', { exact: true }) with timeout 5000ms
  - waiting for locator('.wp-message.assistant').getByText('模型未返回可用答案；运行终态已保存，未重新生成。', { exact: true })

```

```yaml
- complementary:
  - text: W
  - strong: WeKnora
  - text: Python adapter
  - navigation "主导航":
    - button "问答"
    - button "资料库"
    - button "模型设置"
    - button "长期记忆"
  - button "＋ 新对话"
  - text: 历史会话
  - paragraph: 还没有会话
  - text: 本地知识工作台
- main:
  - text: 问答台 / 课程资料
  - status: 模型未返回可用答案，运行终态已保存
  - strong: 检索范围
  - text: 会话使用已保存的知识库范围；新范围请新建会话 1 个知识库 · 0 个资料 知识库
  - checkbox "课程资料 1 份资料 · 仅本地（该库内容不外发）" [checked] [disabled]
  - strong: 课程资料
  - text: 1 份资料 · 仅本地（该库内容不外发） 资料文件
  - checkbox "教材 第三章.pdf ready" [disabled]
  - strong: 教材 第三章.pdf
  - text: ready
  - article:
    - text: 你
    - paragraph: 状态测试
  - article:
    - text: WeKnora
    - group: 实际执行事件 · 2
    - text: 尚未收到 complete，结果状态待确认；没有重新生成。
    - button "GET 续读原回答"
  - text: 快速问答
  - button "智能推理 暂不可用" [disabled]
  - text: 一次提问只发一次 POST；中断后只 GET 续读
  - textbox "询问当前资料…"
  - text: Enter 发送 · Shift+Enter 换行
  - button "发送 ↗" [disabled]
```

# Test source

```ts
  1   | import { expect, test } from "@playwright/test";
  2   | 
  3   | const envelope = (data: unknown) => ({ data, meta: { request_id: "api-request" } });
  4   | const roleRows = ["embedding", "rerank", "cheap", "expensive", "vlm"].map(role => ({
  5   |   role, provider: "local", model: `${role}-model`, base_url: "http://127.0.0.1:9999/v1",
  6   |   key_configured: role === "cheap",
  7   | }));
  8   | 
  9   | async function installCatalogRoutes(page: import("@playwright/test").Page, options: { implementation?: string } = {}) {
  10  |   await page.route("**/api/v1/runtime", route => route.fulfill({ json: envelope({ implementation: options.implementation ?? "weknora-python-port", api_version: "v1" }) }));
  11  |   await page.route("**/api/v1/knowledge-bases", route => route.fulfill({ json: envelope([
  12  |     { id: "kb-1", name: "课程资料", cloud_allowed: false, document_count: 1 },
  13  |   ]) }));
  14  |   await page.route("**/api/v1/knowledge-bases/kb-1/documents", route => route.fulfill({ json: envelope([
  15  |     { id: "doc-1", knowledge_base_id: "kb-1", filename: "教材 第三章.pdf", status: "ready" },
  16  |   ]) }));
  17  |   await page.route("**/api/v1/sessions", route => route.fulfill({ json: envelope([]) }));
  18  |   await page.route("**/api/v1/settings/model-configuration", route => route.fulfill({ json: envelope({ revision: "rev-1", roles: roleRows }) }));
  19  | }
  20  | 
  21  | function frame(event: Record<string, unknown>) {
  22  |   return `event: message\ndata: ${JSON.stringify(event)}\n\n`;
  23  | }
  24  | 
  25  | for (const scenario of [
  26  |   { name: "truncated", text: "保留尚未写完的回答", finish_reason: "length", generation_issues: ["TRUNCATED"], label: "输出被截断；已有内容已保存，未重新生成。" },
  27  |   { name: "empty", text: "", finish_reason: "stop", generation_issues: ["EMPTY"], label: "模型未返回可用答案；运行终态已保存，未重新生成。" },
  28  |   { name: "selected-final", text: "升级后完整回答", finish_reason: "stop", generation_issues: [], label: "回答已由服务端完成并保存" },
  29  | ]) {
  30  |   test(`live ${scenario.name} shows final output status without retry`, async ({ page }) => {
  31  |     await installCatalogRoutes(page);
  32  |     let posts = 0;
  33  |     let resumes = 0;
  34  |     await page.route("**/api/v1/sessions", route => route.fulfill({ json: envelope(route.request().method() === "POST"
  35  |       ? { id: "status-session", title: "状态测试", knowledge_base_scope: ["kb-1"], document_scope: [], updated_at: "now" } : []) }));
  36  |     await page.route("**/api/v1/sessions/status-session/messages", async route => {
  37  |       if (route.request().method() !== "POST") return route.fulfill({ json: envelope([]) });
  38  |       posts++;
  39  |       const body = frame({ id: "status-run", response_type: "agent_query", content: "", done: false,
  40  |         data: { request_id: "status-run", session_id: "status-session", assistant_message_id: "status-answer" } }) +
  41  |         frame({ id: "status-run", response_type: "answer", content: scenario.text, done: true, data: { event_id: "final-answer" } }) +
  42  |         frame({ id: "status-run", response_type: "complete", content: "", done: false,
  43  |           data: { finish_reason: scenario.finish_reason, generation_issues: scenario.generation_issues,
  44  |             truncated: scenario.name === "truncated", final_content: scenario.text,
  45  |             attempts: [{ objective: ["TRUNCATED"] }, { objective: scenario.generation_issues }] } });
  46  |       return route.fulfill({ status: 200, contentType: "text/event-stream", body });
  47  |     });
  48  |     await page.route("**/api/v1/sessions/continue-stream/**", route => { resumes++; return route.fulfill({ status: 500 }); });
  49  |     await page.goto("/");
  50  |     await page.getByText("课程资料", { exact: true }).first().click();
  51  |     await page.getByPlaceholder("询问当前资料…").fill("状态测试");
  52  |     await page.getByRole("button", { name: "发送" }).click();
  53  |     const bubble = page.locator(".wp-message.assistant");
> 54  |     await expect(bubble.getByText(scenario.label, { exact: true })).toBeVisible();
      |                                                                     ^ Error: expect(locator).toBeVisible() failed
  55  |     await expect(bubble.locator(".wp-message-content")).toHaveText(scenario.text);
  56  |     if (scenario.name !== "selected-final") await expect(bubble.getByText("回答已由服务端完成并保存", { exact: true })).toHaveCount(0);
  57  |     expect(posts).toBe(1);
  58  |     expect(resumes).toBe(0);
  59  |   });
  60  | 
  61  |   test(`history ${scenario.name} restores persisted final output status`, async ({ page }) => {
  62  |     await installCatalogRoutes(page);
  63  |     let mutations = 0;
  64  |     await page.route("**/api/v1/sessions", route => route.fulfill({ json: envelope([
  65  |       { id: "status-history", title: "保存的状态", knowledge_base_scope: ["kb-1"], document_scope: [], updated_at: "now" },
  66  |     ]) }));
  67  |     await page.route("**/api/v1/sessions/status-history/messages", route => {
  68  |       if (route.request().method() !== "GET") mutations++;
  69  |       return route.fulfill({ json: envelope([
  70  |         { id: "saved-status", role: "assistant", content: scenario.text, request_id: "saved-status-run", created_at: "now",
  71  |           is_completed: true, turn_status: "completed", finish_reason: scenario.finish_reason, generation_issues: scenario.generation_issues },
  72  |       ]) });
  73  |     });
  74  |     await page.goto("/");
  75  |     await page.getByRole("button", { name: /保存的状态/ }).click();
  76  |     const bubble = page.locator(".wp-message.assistant");
  77  |     await expect(bubble.getByText(scenario.label, { exact: true })).toBeVisible();
  78  |     await expect(bubble.locator(".wp-message-content")).toHaveText(scenario.text);
  79  |     if (scenario.name !== "selected-final") await expect(bubble.getByText("回答已由服务端完成并保存", { exact: true })).toHaveCount(0);
  80  |     expect(mutations).toBe(0);
  81  |   });
  82  | }
  83  | 
  84  | test("port adapter loads visible scope and five masked model roles without old app fallback", async ({ page }) => {
  85  |   await installCatalogRoutes(page);
  86  |   await page.goto("/");
  87  |   await expect(page.getByRole("heading", { name: "从你的资料中寻找答案" })).toBeVisible();
  88  |   await expect(page.getByText("选择检索范围，快速问答会显示实际检索与回答进度。")).toBeVisible();
  89  |   await expect(page.getByText("选择检索范围，快速问答会显示服务端实际发送的执行事件与引用。")).toHaveCount(0);
  90  |   await expect(page.getByText("课程资料", { exact: true }).first()).toBeVisible();
  91  |   await page.getByText("课程资料", { exact: true }).first().click();
  92  |   await expect(page.getByText("教材 第三章.pdf")).toBeVisible();
  93  |   await expect(page.getByRole("button", { name: /智能推理/ })).toBeDisabled();
  94  |   await page.getByRole("button", { name: "模型设置" }).click();
  95  |   for (const role of ["Embedding", "Rerank", "Quick answer", "Smart answer", "Vision"]) {
  96  |     await expect(page.getByText(role, { exact: true })).toBeVisible();
  97  |   }
  98  |   await expect(page.getByText("API 密钥只写入，不会从服务端读回")).toBeVisible();
  99  | });
  100 | 
  101 | test("POST once and recover by offset-zero GET of the same assistant message without duplicate answer text", async ({ page }) => {
  102 |   await installCatalogRoutes(page);
  103 |   let posts = 0;
  104 |   let gets = 0;
  105 |   let postBody: Record<string, unknown> | undefined;
  106 |   await page.route("**/api/v1/sessions", async route => {
  107 |     if (route.request().method() === "POST") {
  108 |       await route.fulfill({ json: envelope({ id: "session-1", title: "测试问题", knowledge_base_scope: ["kb-1"], document_scope: [], updated_at: "now" }) });
  109 |       return;
  110 |     }
  111 |     await route.fulfill({ json: envelope([]) });
  112 |   });
  113 |   await page.route("**/api/v1/sessions/session-1/messages", async route => {
  114 |     if (route.request().method() === "POST") {
  115 |       posts++;
  116 |       postBody = route.request().postDataJSON() as Record<string, unknown>;
  117 |       const body = frame({ id: "request-1", response_type: "agent_query", content: "", done: false,
  118 |         data: { request_id: "request-1", session_id: "session-1", assistant_message_id: "assistant-1" } }) +
  119 |         frame({ id: "request-1", response_type: "answer", content: "Hello", done: false, data: { event_id: "answer-1" } });
  120 |       await route.fulfill({ status: 200, contentType: "text/event-stream", body });
  121 |       return;
  122 |     }
  123 |     await route.fulfill({ json: envelope([]) });
  124 |   });
  125 |   await page.route("**/api/v1/sessions/continue-stream/session-1?message_id=assistant-1", async route => {
  126 |     gets++;
  127 |     const body = frame({ id: "request-1", response_type: "agent_query", content: "", done: false,
  128 |       data: { request_id: "request-1", session_id: "session-1", assistant_message_id: "assistant-1" } }) +
  129 |       frame({ id: "request-1", response_type: "answer", content: "Hello", done: false, data: { event_id: "answer-1" } }) +
  130 |       frame({ id: "request-1", response_type: "answer", content: " world", done: true, data: { event_id: "answer-1" } }) +
  131 |       frame({ id: "request-1", response_type: "complete", content: "", done: false, data: { final_content: "Hello world" } });
  132 |     await route.fulfill({ status: 200, contentType: "text/event-stream", body });
  133 |   });
  134 | 
  135 |   await page.goto("/");
  136 |   await page.getByText("课程资料", { exact: true }).first().click();
  137 |   await page.getByPlaceholder("询问当前资料…").fill("What does chapter three explain?");
  138 |   await page.getByRole("button", { name: "发送" }).click();
  139 |   await expect(page.getByText("Hello world")).toBeVisible();
  140 |   await expect(page.getByText("回答已由服务端完成并保存")).toBeVisible();
  141 |   expect(posts).toBe(1);
  142 |   expect(gets).toBe(1);
  143 |   expect(postBody?.mode).toBe("quick");
  144 |   expect(postBody?.knowledge_base_scope).toEqual(["kb-1"]);
  145 | });
  146 | 
  147 | test("runtime identity mismatch blocks mutations and remains visibly isolated from the existing backend", async ({ page }) => {
  148 |   await installCatalogRoutes(page, { implementation: "legacy-rag" });
  149 |   let postCount = 0;
  150 |   await page.route("**/api/v1/knowledge-bases", async route => {
  151 |     if (route.request().method() === "POST") postCount++;
  152 |     await route.fulfill({ json: envelope([]) });
  153 |   });
  154 |   await page.goto("/");
```