import argparse, contextlib, hashlib, json, os, socket, subprocess, sys, time, uuid
from pathlib import Path
ROOT=Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
OUT=Path(__file__).parent
CONFIG=OUT/'phase-local.json'
sys.path.insert(0,str(ROOT))
import httpx, psycopg
from psycopg.rows import dict_row
from scripts.local_runtime import environment,verify_resources


def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,x):Path(p).write_text(json.dumps(x,ensure_ascii=False,indent=2,default=str)+'\n',encoding='utf-8')


def db(env,session=None):
 with psycopg.connect(env['WEKNORA_PORT_DATABASE_URL'],autocommit=True,row_factory=dict_row) as c:
  c.execute('BEGIN TRANSACTION READ ONLY')
  unknown=c.execute("SELECT call_id,md5(row_to_json(p)::text) AS fingerprint FROM port_provider_calls p WHERE outcome='UNKNOWN' ORDER BY call_id").fetchall()
  if session:
   data={'turns':c.execute('SELECT * FROM port_turns WHERE session_id=%s',(session,)).fetchall(),
    'messages':c.execute('SELECT * FROM messages WHERE session_id=%s ORDER BY created_at,id',(session,)).fetchall(),
    'calls':c.execute('SELECT * FROM port_provider_calls WHERE session_id=%s ORDER BY created_at,call_id',(session,)).fetchall(),
    'attempts':c.execute('SELECT a.* FROM generation_attempts a JOIN generation_runs r USING(run_id) WHERE r.session_id=%s ORDER BY ordinal',(session,)).fetchall()}
  else:data={}
  c.execute('ROLLBACK')
 def compact(x):
  if isinstance(x,dict):return {k:compact(v) for k,v in x.items() if k!='prior_numeric_raw'}
  if isinstance(x,list):return [compact(v) for v in x]
  return x
 return {'unknown':unknown,**compact(data)}


@contextlib.contextmanager
def daily_api(env,batch):
 port=56425
 with socket.socket() as s:
  if s.connect_ex(('127.0.0.1',port))==0:raise RuntimeError('EXISTING_DAILY_API_DO_NOT_REPLACE')
 with (batch/'api.log').open('wb') as log:
  proc=subprocess.Popen([sys.executable,'-B','-m','backend.weknora_port.entrypoint','--host','127.0.0.1','--port',str(port)],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
  write(batch/'process.json',{'pid':proc.pid,'port':port,'worker_started':False,'normal_entrypoint':True})
  try:
   with httpx.Client(base_url=f'http://127.0.0.1:{port}',headers={'Origin':'http://127.0.0.1:56426'},trust_env=False,timeout=httpx.Timeout(1800,connect=5)) as client:
    end=time.monotonic()+35
    while True:
     if proc.poll() is not None:raise RuntimeError('API_EXITED')
     try:r=client.get('/readyz');r.raise_for_status();break
     except httpx.ConnectError:
      if time.monotonic()>end:raise
      time.sleep(.25)
    yield client,{},proc
  finally:
   # Caller waits for the admitted turn's terminal DB state before leaving.
   if proc.poll() is None:proc.terminate();proc.wait(20)


def execute_http(client,headers,case,batch,env):
 roles=client.get('/api/v1/settings/model-configuration',headers=headers);roles.raise_for_status();write(batch/'public-models.json',roles.json())
 assert all(r['credential_status']=='CONFIGURED' for r in roles.json()['data']['roles'])
 session=client.post('/api/v1/sessions',headers=headers,json={'knowledge_base_scope':[case['kb']],'document_scope':[],'title':'Phase01 '+case['case_id']});session.raise_for_status()
 sid=session.json()['data']['id'];write(batch/'session.json',session.json())
 payload={'content':case['question'],'request_id':str(uuid.uuid4()),'knowledge_base_scope':[case['kb']],'document_scope':[],'mode':'quick','reasoning_effort':'off'}
 with (batch/'question-submitted.json').open('x',encoding='utf-8') as f:json.dump({'session_id':sid,'payload':payload},f,ensure_ascii=False,indent=2)
 started=time.monotonic();events=[];timing={'request_started_monotonic':started,'first_nonempty_answer_monotonic':None}
 try:
  with (batch/'response.sse').open('w',encoding='utf-8') as trace:
   with client.stream('POST',f'/api/v1/sessions/{sid}/messages',headers=headers,json=payload,timeout=httpx.Timeout(1800,connect=5)) as response:
    timing['response_headers_monotonic']=time.monotonic();response.raise_for_status()
    for line in response.iter_lines():
     trace.write(line+'\n')
     if line.startswith('data: '):
      event=json.loads(line[6:]);event['observed_monotonic']=time.monotonic();events.append(event)
      if event.get('response_type')=='answer' and event.get('content') and timing['first_nonempty_answer_monotonic'] is None:timing['first_nonempty_answer_monotonic']=event['observed_monotonic']
      if event.get('response_type')=='complete':break
  timing['read_finished_monotonic']=time.monotonic();timing['elapsed_seconds']=timing['read_finished_monotonic']-started
  write(batch/'events.json',events);write(batch/'http-timing.json',timing)
  history=client.get(f'/api/v1/sessions/{sid}/messages',headers=headers);history.raise_for_status();write(batch/'history.json',history.json())
  # Read-only refresh of exactly the same history; never another question.
  again=client.get(f'/api/v1/sessions/{sid}/messages',headers=headers);again.raise_for_status();write(batch/'history-refreshed.json',again.json())
 finally:
  # Observation errors must not cancel the supplier. Do not leave a launcher
  # context (which owns termination) until the exact turn is terminal.
  while True:
   snap=db(env,sid)
   if snap['turns'] and snap['turns'][0]['status'] in ('completed','error'):break
   time.sleep(2)
  write(batch/'db-final.json',snap)
 return sid


def main(case_id):
 parent=read(OUT/'phase-accounting.json');assert parent['status']=='OPEN','PHASE_STOP_OR_CLOSED'
 assert all(b['status']=='CLOSED' for b in parent['batches']),'UNRESOLVED_DELEGATION_STOP'
 assert not any(b['case_id']==case_id for b in parent['batches']),'CASE_ALREADY_ATTEMPTED_NO_RETRY'
 case=next(c for c in read(OUT/'live-cases.json') if c['case_id']==case_id)
 spent_calls=sum(b['calls'] for b in parent['batches']);spent_tokens=sum(b['tokens'] for b in parent['batches'])
 assert len(parent['batches'])<parent['max_questions']
 cap_calls=min(12,parent['max_calls']-spent_calls);cap_tokens=min(100000,parent['max_tokens']-spent_tokens)
 assert cap_calls>=10 and cap_tokens>=30000,'INSUFFICIENT_COMPLETE_NORMAL_FLOW_ENVELOPE'
 batch=OUT/('live-'+case_id);batch.mkdir(exist_ok=False)
 cfg=read(CONFIG)
 import asyncio
 identity=asyncio.run(verify_resources(cfg),loop_factory=asyncio.SelectorEventLoop)
 env=environment(cfg,identity['redis_run_id']);before=db(env);write(batch/'before.json',before)
 auth=read(OUT/'identity-models.json')
 allowed_ids={1:{'mdl243ef6c62adf02818f0e969b323048bae37ce165c32310eed73e36a93239f','mdl2f3f91c525da1aa4f92e128fbd7f1f993b4c7423dede8220d8f47ed64f290','mdl8397d606d3b4437f1adb06798fb4fb0efaad577c6038db1e1e3fbe2bd80fd','mdl96a368bfb0c176c6e38e325c53a030ae3e40b000254c17d19a854f4495846','mdlf8bfb8f2c47f8764f4f4b5851d00d9cf3fd02d827b92919b52eb6b5e69039'},332:{m['id'] for m in auth['models'] if m['tenant_id']==332}}
 # Correct ID comes from actual inspected current registry, not a model-name guess.
 allowed_ids[1].add('mdlf8bfb8f2c47f8764f4f4b5851d00d9cf3fd02d827b92919b52eb6b5e69039')
 # Source role name maps to Registry capability; no VLM in this phase.
 models=[]
 for m in auth['models']:
  if m['tenant_id']!=case['tenant_id'] or m['id'] not in allowed_ids[case['tenant_id']]:continue
  cap={'embedding':'embedding','rerank':'rerank','Embedding':'embedding','Rerank':'rerank'}.get(m['type'],'chat')
  models.append({'provider':m['provider'],'model':m['name'],'model_id':m['id'],'capability':cap})
 subject='web_user:local:bba83fda-3749-499b-9b1a-1f42aa2da8a6' if case['tenant_id']==1 else 'p8-real-3de2eca0bea340babcde75ce60c9a366'
 grant={'status':'OPEN','scope':'PHASE01','tenant_id':case['tenant_id'],'subject_id':subject,'allowed_kbs':[case['kb']],'allowed_models':models,'allowed_request_prefixes':list('0123456789abcdef'),'max_calls':cap_calls,'max_tokens':cap_tokens,'capture_evidence':True,'entries':[]}
 assert len(models)==(5 if case['tenant_id']==1 else 4)
 delegated={'case_id':case_id,'status':'DELEGATED','max_calls':cap_calls,'max_tokens':cap_tokens,'path':str(batch),'calls':0,'tokens':0}
 assert spent_calls+cap_calls<=60 and spent_tokens+cap_tokens<=400000
 parent['batches'].append(delegated);write(OUT/'phase-accounting.json',parent)
 write(batch/'case.json',case);write(batch/'execution.json',grant)
 env.update(WEKNORA_PORT_CLOUD_ALLOWED='true',WEKNORA_PORT_EXECUTION_FILE=str(batch/'execution.json'),PYTHONIOENCODING='utf-8',PYTHONDONTWRITEBYTECODE='1')
 write(batch/'source.json',{'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT).decode().strip(),'identity':identity,'mode':'bounded_source_v1','reasoning_effort':'off','no_gold_sent':True,'worker_started':False})
 try:
  if case['tenant_id']==1:
   with daily_api(env,batch) as (client,headers,proc):execute_http(client,headers,case,batch,env)
  else:
   from scripts.m4_tenant332_api import tenant332_api
   with tenant332_api(config_path=CONFIG,execution_file=batch/'execution.json',output_root=OUT/'tenant332-servers') as api:
    write(batch/'api-identity.json',{'tenant_id':332,'port':api.port,'pid':api.process_id,'redis_prefix':api.redis_prefix,'subject_fingerprint':api.identity_preflight['subject_fingerprint'],'worker_started':False})
    # Use normal M4 loopback client/auth, no principal injected by client.
    api.client._client.base_url=api.base_url
    execute_http(api.client._client,{'Authorization':'Bearer '+api.client._token,'Origin':api.base_url},case,batch,env)
 finally:
  ledger=read(batch/'execution.json');entries=ledger['entries'];bad=[e for e in entries if e['status']!='SETTLED']
  if not bad:
   ledger.update(status='CLOSED',unused_calls_revoked=cap_calls-len(entries),unused_tokens_revoked=cap_tokens-sum(e['held_tokens'] for e in entries));write(batch/'execution.json',ledger)
   delegated.update(status='CLOSED',calls=len(entries),tokens=sum(e['held_tokens'] for e in entries))
  else:
   if ledger['status']=='OPEN':ledger['status']='STOP';write(batch/'execution.json',ledger)
   delegated.update(status='STOP',calls_reserved=cap_calls,tokens_reserved=cap_tokens)
   parent['status']='STOP'
  after=db(env);old={r['call_id']:r['fingerprint'] for r in before['unknown']};current={r['call_id']:r['fingerprint'] for r in after['unknown']}
  assert all(current.get(k)==v for k,v in old.items()),'OLD_UNKNOWN_CHANGED'
  new_unknown=set(current)-set(old)
  if new_unknown:parent['status']='STOP'
  write(OUT/'phase-accounting.json',parent)
  write(batch/'closeout.json',{'delegation':delegated,'old_unknown_unchanged':True,'new_provider_unknown':len(new_unknown),'stage_status':parent['status']})
 print(json.dumps({'case_id':case_id,'delegation':delegated,'stage_status':parent['status']}))


if __name__=='__main__':main(sys.argv[1])
