import asyncio, json, sys
from pathlib import Path
sys.path.insert(0,'E:/RAG-Worktrees/weknora-python-port-20261013')
from scripts.rag_m40_preflight import database_config, read
async def run():
 import psycopg
 from psycopg.rows import dict_row
 cfg=database_config(read('E:/WK/run/p81-retirement-20261018/local.json'))
 async with await psycopg.AsyncConnection.connect(cfg['DATABASE_URL'],autocommit=True,row_factory=dict_row) as c:
  await c.execute('BEGIN TRANSACTION READ ONLY')
  rows=await (await c.execute("SELECT id,chunk_type,index_status,is_enabled,metadata->>'source_version' AS source_version FROM chunks WHERE tenant_id=%s AND knowledge_base_id=%s AND knowledge_id=%s AND deleted_at IS NULL ORDER BY id",(332,'f4b6ddb2-c05c-4ece-ba73-c1dad6eea8d7','222d167a-387d-4e30-8412-2cc30393fed5'))).fetchall()
  await c.execute('ROLLBACK')
  print(json.dumps(rows,ensure_ascii=False))
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner: runner.run(run())
