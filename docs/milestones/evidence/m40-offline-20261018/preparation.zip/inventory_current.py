"""Current frozen-scope metadata and all-QID source coverage. READ ONLY, no RAG."""
import asyncio, hashlib, json, sys
from pathlib import Path
sys.path.insert(0,'E:/RAG-Worktrees/weknora-python-port-20261013')
from scripts.rag_m40_preflight import database_config, read
ROOT=Path('E:/RAG-Worktrees/weknora-python-port-20261013')
PLAN=read(ROOT/'docs/milestones/RAG_M4_0_BASELINE.plan.json')
HISTORY=read('E:/WK/run/p19-20261016/state.json')
GOLD=read('E:/WK/run/p9-20261016/gold-all.json')
async def run():
 import psycopg
 from psycopg.rows import dict_row
 cfg=database_config(read('E:/WK/run/p81-retirement-20261018/local.json'))
 async with await psycopg.AsyncConnection.connect(cfg['DATABASE_URL'],autocommit=True,row_factory=dict_row) as c:
  await c.execute('BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY')
  identity=await (await c.execute('SELECT system_identifier::text AS system_id,current_database() AS database FROM pg_control_system()')).fetchone()
  if identity!={'system_id':cfg['DATABASE_SYSTEM_ID'],'database':cfg['DATABASE_NAME']}: raise ValueError('IDENTITY_MISMATCH')
  indexes=await (await c.execute("SELECT ci.relname AS index_name,pi.indisvalid,pi.indisready,am.amname AS method FROM pg_index pi JOIN pg_class ct ON ct.oid=pi.indrelid JOIN pg_class ci ON ci.oid=pi.indexrelid JOIN pg_am am ON am.oid=ci.relam WHERE ct.relname='embeddings' ORDER BY ci.relname")).fetchall()
  out={'kind':'READ_ONLY_METADATA_NOT_QA','database_identity':identity,'physical_embedding_indexes':indexes,'datasets':[]}
  for dataset in PLAN['dataset_inventory']:
   name=dataset['dataset']; case=next(r for r in PLAN['cases'] if r['dataset']==name)
   scope=(case['tenant_id'],case['knowledge_base_id'])
   kb=await (await c.execute('SELECT id,cloud_allowed,embedding_model_id,indexing_strategy FROM knowledge_bases WHERE tenant_id=%s AND id=%s AND deleted_at IS NULL',scope)).fetchone()
   docs=await (await c.execute("SELECT id,file_hash,metadata->>'source_version' AS source_version,parse_status,enable_status FROM knowledges WHERE tenant_id=%s AND knowledge_base_id=%s AND deleted_at IS NULL ORDER BY id",scope)).fetchall()
   chunks=await (await c.execute("SELECT c.id,c.knowledge_id,c.chunk_type,c.is_enabled,c.index_status,c.metadata->>'source_version' AS source_version, count(e.id) AS index_rows, min(e.dimension) AS min_dimension,max(e.dimension) AS max_dimension,bool_and(e.embedding IS NOT NULL AND e.dimension>0 AND vector_dims(e.embedding)=e.dimension) AS vectors_valid FROM chunks c LEFT JOIN embeddings e ON e.knowledge_id=c.knowledge_id AND e.knowledge_base_id=c.knowledge_base_id AND e.chunk_id=c.id AND e.source_id=c.id AND e.source_type=0 AND e.is_enabled=TRUE WHERE c.tenant_id=%s AND c.knowledge_base_id=%s AND c.deleted_at IS NULL GROUP BY c.id ORDER BY c.id",scope)).fetchall()
   ready_docs={d['id'] for d in docs if d['source_version'] and d['parse_status']=='completed' and d['enable_status']=='enabled'}
   valid_chunks=[r for r in chunks if r['is_enabled'] and r['index_status']=='ready' and r['index_rows']>0 and r['vectors_valid'] and r['knowledge_id'] in ready_docs]
   keyword=await (await c.execute('SELECT count(*) AS index_rows,count(*) FILTER(WHERE content IS NOT NULL AND length(content)>0) AS nonempty_keyword_rows FROM embeddings WHERE knowledge_base_id=%s AND is_enabled=TRUE',(scope[1],))).fetchone()
   catalog={sid:r.get('source',{}).get('sha256') for sid,r in HISTORY['datasets'][name]['documents'].items()}
   # P19 predates the B3 MinerU import; exact P32 file-hash bindings add it.
   for frozen in PLAN['cases']:
    if frozen['dataset']==name:
     catalog.update({d['source_id']:d['file_sha256'] for d in frozen['expected_documents']})
   coverage=[]
   native=next((r for r in GOLD['datasets'] if r['name']==name),None)
   for question in native['cases'] if native else []:
    found=[];missing=[]
    for source_id,rel in question['qrels'].items():
     if rel<=0: continue
     expected=catalog.get(source_id)
     matched=[d['id'] for d in docs if expected and d['file_hash']==expected and d['id'] in ready_docs and any(r['knowledge_id']==d['id'] for r in valid_chunks)]
     if matched: found.append({'source_id':source_id,'document_ids':matched})
     else: missing.append(source_id)
    coverage.append({'qid':question['qid'],'positive_sources':found,'missing_positive_sources':missing,'source_coverage':'COMPLETE' if found and not missing else 'INCOMPLETE','qa_executable':'NOT_PROVEN_BY_SOURCE_ID_COVERAGE'})
   out['datasets'].append({'dataset':name,'tenant_id':scope[0],'knowledge_base_id':scope[1],'kb':kb,
    'document_count':len(docs),'chunk_count':len(chunks),'enabled_indexed_vector_chunks':len(valid_chunks),
    'index_rows':sum(int(r['index_rows']) for r in chunks),'keyword':keyword,'dimensions':sorted({r['max_dimension'] for r in valid_chunks}),
    'metadata_sha256':hashlib.sha256(json.dumps({'docs':docs,'chunks':chunks},sort_keys=True,default=str).encode()).hexdigest(),
    'full_frozen_qid_source_coverage':coverage,'fully_source_covered_qids':sum(r['source_coverage']=='COMPLETE' for r in coverage)})
  calls=await (await c.execute("SELECT tenant_id,count(*) AS calls,count(*) FILTER(WHERE outcome='UNKNOWN') AS unknown_outcomes,md5(string_agg(call_id||':'||outcome||':'||coalesce(usage::text,''),'|' ORDER BY call_id)) AS ledger_fingerprint FROM port_provider_calls WHERE tenant_id=ANY(%s) GROUP BY tenant_id ORDER BY tenant_id",([1,332],))).fetchall()
  out['existing_provider_ledger']=calls
  await c.execute('ROLLBACK')
 target=Path('E:/WK/run/rag-m40-20261018/current-inventory.json')
 target.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps({'status':'READ_ONLY_COMPLETE','datasets':[(r['dataset'],r['document_count'],r['chunk_count'],r['enabled_indexed_vector_chunks'],r['fully_source_covered_qids']) for r in out['datasets']]},ensure_ascii=False))
with asyncio.Runner(loop_factory=asyncio.SelectorEventLoop) as runner: runner.run(run())
