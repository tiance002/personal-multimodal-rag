"""Freeze existing public case/Gold/source identities only; no services or model calls."""
import hashlib, json
from pathlib import Path

ROOT=Path('E:/RAG-Worktrees/weknora-python-port-20261013')
P32=Path('E:/WK/run/p32-20261017')
GOLD=Path('E:/WK/run/p9-20261016/gold-all.json')
HISTORY=Path('E:/WK/run/p19-20261016/state.json')
def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
old, gold, history, bound = read(P32/'plan.json'), read(GOLD), read(HISTORY), read(P32/'source-bindings.json')
identity=read(P32/'identity-before.json')
metrics={
 'scifact':['subset_source_Recall@10','subset_source_MRR@10','subset_source_nDCG@10'],
 'miracl-zh':['subset_passage_Recall@10','subset_passage_MRR@10','subset_passage_nDCG@10'],
 'longbench-zh':['task_specific_ROUGE_ZH_or_QA_F1_ZH'],
 'hotpotqa':['answer_EM','answer_token_F1','subset_source_Recall@10'],
 'mmlongbench-doc':['project_normalized_EM','project_character_F1','source_fact_review'],
 'omnidocbench':['RAG_engineering_source_fact_review_NOT_official_QA']}
case_gold={(d['name'],c['qid']):c for d in gold['datasets'] for c in d['cases']}
ordinary={'scifact-339','miracl-7049630','longbench-51abd206','hotpot-5a8ad6','mml-0959','omni-page012'}
refs=[P32/'plan.json',P32/'plan-frozen.json',P32/'source-bindings.json',GOLD,HISTORY,
      ROOT/'scripts/rag_m3_score.py',ROOT/'scripts/p32_score_results.py',ROOT/'scripts/weknora_port_p19_score.py',
      ROOT/'eval_center/metrics.py',ROOT/'eval_center/weknora_scoring.py']
plan={'schema':'rag-m4-plan/v1','baseline_sha':'5099efe5aae1de1bc5849c7db2f081c32fe22d5c',
 'upstream_sha':'3e8b0bfc80b845b2d4b2ed683994748741450a97','overall_authorization':None,
 'input_files':[{'path':str(p),'sha256':sha(p)} for p in refs],
 'production':{'query_understanding':'A','rerank_threshold':0.3,'top1_minimum':0.15,'router':'DYNAMIC','force_role':None},
 'authorization_proposal_only':{'status':'NOT_APPROVED','end_to_end_requests':11,'provider_calls_total':132,
  'token_limit_total_including_unresolved_reservations':600000,'per_batch_calls':12,'per_batch_tokens':100000,
  'batch_size':1,'max_minutes_per_batch':40,'unknown_policy':'STOP_NO_RETRY_NO_NEW_GRANT_FILE'},
 'cases':[],'dataset_inventory':[],
 'excluded_case':{'case_id':'omni-page007','reason':'M3.5 matrix upload/QA/refresh acceptance preserved; no repeat or repair in M4.0'},
 'execution_contract':{'path':'existing normal FastAPI -> Query Understanding -> Search -> Rerank -> Merge/Context -> DYNAMIC -> generation -> SSE/history',
  'payload_fields_only':['content','request_id','knowledge_base_scope','document_scope'],
  'new_session_per_case':True,'no_gold_or_ideal_evidence_in_payload':True,'offline_only_until_new_owner_authorization':True,
  'daily_identity_must_match_manifest':'Do not change principal or remap historical data; otherwise report blocked scope.',
  'no_legacy_AB_runner':'M3/P32 runner startup/prepare pins old HEAD, overrides consent/principal; not authorized for M4.'}}
for c in old['cases']:
 if c['case_id']=='omni-page007': continue
 dataset=c['source_dataset']; native=case_gold.get((dataset,c['qid']))
 if native is not None and c['question']!=native['question']: raise ValueError('QUESTION_CHANGED:'+c['case_id'])
 docs=[]
 for source in c['source_files']:
  options=[Path('E:/WK/run/p9-20261016/s')/source['sha256'][:20]/source['file_name']]
  if source.get('source_path'): options.append(Path(source['source_path']))
  for item in history['datasets'][dataset]['documents'].values():
   if item.get('source',{}).get('sha256')==source['sha256'] and item.get('source',{}).get('path'):
    options.append(Path(item['source']['path']))
  actual=next((p for p in options if p.is_file() and sha(p)==source['sha256']),None)
  if actual is None: raise ValueError('SOURCE_FILE_NOT_REPRODUCIBLE:'+c['case_id'])
  matches=[d for d in bound['documents'] if d['tenant_id']==c['tenant_id'] and d['knowledge_base_id']==c['knowledge_base_id'] and d['file_hash']==source['sha256']]
  if len(matches)!=1: raise ValueError('SOURCE_DOCUMENT_BINDING_AMBIGUOUS:'+c['case_id'])
  d=matches[0]
  docs.append({'id':d['id'],'source_version':d['source_version'],'file_sha256':d['file_hash'],
               'source_id':source['source_id'],'file_path':str(actual),'parser_engine':d.get('parser_engine')})
 row={'case_id':c['case_id'],'dataset':dataset,'qid':c['qid'],'question':c['question'],
  'selection_role':'ordinary_regression' if c['case_id'] in ordinary else 'known_difficult',
  'tenant_id':c['tenant_id'],'subject_id':identity['subject_id'],'knowledge_base_id':c['knowledge_base_id'],
  'kb_scope':[c['knowledge_base_id']],'document_scope':[],'expected_documents':docs,
  'expected_chunk_ids':[],'answer_points':native['answers'] if native else [],
  'qrels':native['qrels'] if native else {},
  'gold':{'path':str(GOLD),'sha256':sha(GOLD),'type':native['qrels_kind'] if native else 'official_parsing_gold_only_no_QA_Gold',
          'metrics':metrics[dataset],'answer_accuracy_applicable':dataset not in ('scifact','miracl-zh','omnidocbench')},
  'manual_source_fact_review_required':True,'prior_results':'HISTORICAL_ONLY_NOT_CURRENT_SCORE',
  'stages_required':['Search','Rerank','Merge/TopK','Context','actual_provider_evidence','answer','SSE_history_consistency'],
  'new_execution':'NOT_RUN','actual_tokens':None,'quality_metrics':None}
 plan['cases'].append(row)
for d in gold['datasets']:
 name=d['name']; subset=history['datasets'][name]
 source_hashes={sid:r['source']['sha256'] for sid,r in subset['documents'].items()}
 coverage=[]
 for c in d['cases']:
  positives=[sid for sid,rel in c['qrels'].items() if rel>0]
  missing=[sid for sid in positives if sid not in source_hashes]
  coverage.append({'qid':c['qid'],'positive_sources':positives,'historical_catalog_missing':missing,
    'current_db_coverage':'NOT_YET_VERIFIED_FOR_NONSELECTED_QIDS'})
 plan['dataset_inventory'].append({'dataset':name,'frozen_qids':len(d['cases']),
  'native_answer_gold_count':sum(bool(c['answers']) for c in d['cases']),
  'historical_indexed_documents':len(subset['documents']),
  'selected_for_new_current_baseline':sum(c['dataset']==name for c in plan['cases']),
  'all_frozen_qid_source_coverage':coverage,'dataset_version':d['dataset_version']})
plan['dataset_inventory'].append({'dataset':'omnidocbench','frozen_QA_Gold':0,'parsing_Gold_pages':len(gold['omnidocbench_parsing_gold']['pages']),
 'historical_reliable_page_text_NED_denominator':3,'selected_for_new_current_baseline':1,
 'note':'page012 reuses an existing engineering question for current-version diagnostic only; matrix page007 excluded; no official QA accuracy.'})
out=ROOT/'docs/milestones/RAG_M4_0_BASELINE.plan.json'
if out.exists(): raise ValueError('PLAN_EXISTS_NO_OVERWRITE')
out.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'FROZEN_OFFLINE_NO_AUTHORIZATION','cases':len(plan['cases']),'plan_sha256':sha(out)},ensure_ascii=False))
