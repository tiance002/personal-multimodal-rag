import hashlib,json
from pathlib import Path
ROOT=Path('E:/RAG-Worktrees/weknora-python-port-20261013')
p=ROOT/'docs/milestones/RAG_M4_0_BASELINE.plan.json'
plan=json.loads(p.read_text(encoding='utf-8'))
plan['offline_revision']=2
plan['revision_note']='Only scoring/provenance detail added before any send; all 11 questions, Gold, source versions and selection unchanged.'
plan['source_fingerprints']={}
for rel in ['backend/weknora_port/development.py','backend/weknora_port/runtime.py','backend/weknora_port/execution.py',
 'backend/weknora_port/retrieval/pipeline.py','backend/weknora_port/retrieval/query.py','backend/weknora_port/retrieval/search.py',
 'backend/weknora_port/retrieval/rerank.py','backend/weknora_port/retrieval/merge.py','backend/weknora_port/retrieval/context.py',
 'backend/weknora_port/generation/coordinator.py','backend/weknora_port/generation/router.py',
 'scripts/rag_m40_preflight.py','scripts/p9_score_real.py','scripts/p8_score_real.py']:
 plan['source_fingerprints'][rel]=hashlib.sha256((ROOT/rel).read_bytes()).hexdigest()
for path in [Path('E:/WK/run/p9-20261016/baseline/official-longbench/metrics.py'),
             Path('E:/WK/run/p9-20261016/baseline/official-longbench/receipt.json')]:
 ref={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
 if not any(r['path']==ref['path'] for r in plan['input_files']): plan['input_files'].append(ref)
plan['scoring_rules']={
 'not_run':'All absent run/model/stage data remain NOT_RUN/null, never scored0 or carried from history.',
 'retrieval':'Project chunk ranks onto frozen source IDs at K=10. Report Search/Rerank/Context separately. Subset only, not official full-corpus recall.',
 'exact_evidence':'A same-document summary is only source ID hit. Human source-supported fact coverage separately records original/derived chunk and version.',
 'generation':'Only full completed application answers use native Gold scoring; failed/cancelled/no-receipt attempts retained outside completed denominator.',
 'gold_limits':'SciFact/MIRACL have qrels only, no answer accuracy. LongBench tasks separate. Hotpot EM/F1 no support/joint. MML string diagnostics separate fact support. Omni no official QA.',
 'failure_order':['admission/API_scope','Query Understanding','Search','Rerank','Merge/TopK','Context','provider evidence delivery','generation','SSE/persistence','score data mapping'],
 'failure_categories':['SOURCE_NOT_RECALLED','FACT_DROPPED_AT_RERANK','FACT_DROPPED_AFTER_MERGE','FACT_NOT_SENT_TO_MODEL',
  'WRONG_REASONING_WITH_EVIDENCE','ANSWER_FORMAT_MISMATCH','SOURCE_CONFLICT','UNSUPPORTED_ADDITION','CAPABILITY_LIMIT','UNDETERMINED'],
 'provenance':'Model-derived OCR/Caption/Summary stays identified; valid source identity is not semantic entailment.',
 'usage':'Actual Provider usage only. Missing usage UNREPORTED; unknown response STOP, hold, no resend. All batches share Owner overall cap, never renew by file cycling.'}
plan['normal_api_readiness']='BLOCKED: manifest tenant332 differs from daily tenant1. No principal switch, data remap or experimental service will be used to evade it.'
p.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'schema':plan['schema'],'revision':2,'cases':len(plan['cases']),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}))
