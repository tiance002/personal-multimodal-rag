"""Read-only pre-send verification; intentionally contains no HTTP/model sender."""
import dataclasses
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

import psycopg
from psycopg.rows import dict_row
from redis import Redis

ROOT = Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
OUT = Path(__file__).parent
CONFIG = Path(r'E:\WK\run\p81-retirement-20261018\local.json')
KB = '9d3461a5-080c-4b5e-a367-c82b79d3013c'
DOC = '996fda57-6cc2-4045-a3ff-7416f037459a'
VERSION = '91f260da-03e3-422e-ae08-b6f818ee3b7b'
OLD_CALL = '34448ac6-ef09-476e-b9df-b4ce1bf5d8fc/answer/1/cheap'
sys.path.insert(0, str(ROOT))
from backend.weknora_port.models.catalog import resolve_model_config
from backend.weknora_port.models.request import build_chat_body
from backend.weknora_port.models.types import ChatOptions, Message
from backend.weknora_port.models.output_contract import resolve_output_contract


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + '\n', encoding='utf-8')


def snapshot():
    cfg = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
    env = cfg['environment']
    with psycopg.connect(env['WEKNORA_PORT_DATABASE_URL'], autocommit=True,
                        row_factory=dict_row, connect_timeout=5) as conn:
        conn.execute('BEGIN TRANSACTION READ ONLY')
        assert conn.execute('SHOW transaction_read_only').fetchone()['transaction_read_only'] == 'on'
        identity = conn.execute('SELECT system_identifier::text AS system_id,current_database() AS database FROM pg_control_system()').fetchone()
        assert identity == {'system_id': '7696088403504697382', 'database': 'weknora_python_port_20261013'}
        principal = conn.execute("SELECT tenant_id,subject_id FROM port_local_principal WHERE slot='local'").fetchone()
        assert principal['tenant_id'] == 1
        owner = (1, principal['subject_id'])
        old = conn.execute('SELECT *,md5(row_to_json(t)::text) AS fingerprint FROM port_provider_calls t WHERE tenant_id=%s AND subject_id=%s AND request_id=%s', (*owner, OLD_CALL)).fetchone()
        assert old and old['outcome'] == 'UNKNOWN' and old['usage'] is None and old['finished_at'] is None
        count = conn.execute('SELECT count(*) AS calls FROM port_provider_calls WHERE tenant_id=%s AND subject_id=%s', owner).fetchone()['calls']
        kb = conn.execute('SELECT id,tenant_id,name,cloud_allowed,embedding_model_id,rerank_model_id,summary_model_id FROM knowledge_bases WHERE id=%s AND deleted_at IS NULL', (KB,)).fetchone()
        assert kb['tenant_id'] == 1 and kb['cloud_allowed'] is True
        doc = conn.execute('SELECT id,tenant_id,knowledge_base_id,file_path,file_hash,parse_status FROM knowledges WHERE id=%s AND deleted_at IS NULL', (DOC,)).fetchone()
        assert doc['tenant_id'] == 1 and doc['knowledge_base_id'] == KB and doc['parse_status'] == 'completed'
        assert VERSION in doc['file_path'] and sha(Path(doc['file_path']).read_bytes()) == doc['file_hash']
        vectors = conn.execute('SELECT chunk_id,dimension,(embedding IS NOT NULL) AS has_vector,is_enabled FROM embeddings WHERE knowledge_base_id=%s ORDER BY chunk_id,id', (KB,)).fetchall()
        assert vectors and all(v['dimension'] > 0 and v['has_vector'] for v in vectors)
        roles = conn.execute("SELECT revision,roles->'cheap'->>'model' AS cheap,roles->'expensive'->>'model' AS expensive FROM port_model_configuration WHERE tenant_id=%s AND subject_id=%s", owner).fetchone()
        assert roles['revision'] == 20 and roles['cheap'] == 'Qwen/Qwen3.5-4B'
        models = conn.execute("SELECT id,name,role,source,status,parameters->>'provider' AS provider,parameters->>'base_url' AS base_url FROM models WHERE tenant_id=%s AND subject_id=%s AND status='active' AND deleted_at IS NULL ORDER BY id", owner).fetchall()
        models = [m for m in models if 'fixture.invalid' not in (m['base_url'] or '')]
        protected = {}
        for table, where, args in (
            ('models', 'tenant_id=332', ()),
            ('port_model_configuration', 'tenant_id=332', ()),
            ('chunks', 'knowledge_base_id=%s', (KB,)),
            ('embeddings', 'knowledge_base_id=%s', (KB,)),
        ):
            protected[table] = conn.execute('SELECT md5(row_to_json(t)::text) AS row_hash FROM ' + table + ' t WHERE ' + where + ' ORDER BY row_hash', args).fetchall()
        conn.execute('ROLLBACK')
    redis = Redis.from_url(env['WEKNORA_PORT_REDIS_URL'], decode_responses=True)
    try:
        info = redis.info('server')
    finally:
        redis.close()
    prior = json.loads(Path(r'E:\WK\run\qwen-evidence-diagnosis-20261018\readonly-db-redis.json').read_text(encoding='utf-8'))
    assert info['run_id'] == prior['redis_identity']['run_id']
    return {'database': identity, 'tenant_id': 1,
            'subject_sha256': sha(principal['subject_id'].encode()), 'knowledge_base': kb,
            'document': doc, 'source_version': VERSION, 'vectors': vectors, 'model_configuration': roles,
            'models': models, 'old_unknown': {k: old[k] for k in ('call_id','request_id','model','outcome','usage','finished_at','fingerprint')},
            'provider_calls': count, 'protected_db_hashes': protected,
            'redis_run_id': info['run_id'], 'redis_db': 15, 'redis_prefix': env['WEKNORA_PORT_REDIS_PREFIX'],
            'daily_config_sha256': sha(CONFIG.read_bytes()), 'daily_cloud_allowed': env['WEKNORA_PORT_CLOUD_ALLOWED'],
            'daily_execution_file': env.get('WEKNORA_PORT_EXECUTION_FILE')}


if __name__ == '__main__':
    started = time.monotonic()
    before = snapshot()
    config = resolve_model_config('siliconflow', 'Qwen/Qwen3.5-4B',
                                  base_url='https://api.siliconflow.cn/v1', model_type='KnowledgeQA')
    # This dummy text is never sent. No source/Gold or prepared ideal evidence.
    body = build_chat_body(config, (Message('user', 'offline pre-send validation'),),
                           ChatOptions(temperature=.3, max_completion_tokens=1024), stream=True)
    coded_contract = dataclasses.asdict(resolve_output_contract(config, body))
    assert coded_contract['output_upper'] == 1024 and coded_contract['reasoning_included'] is True
    assert body['max_tokens'] == 1024 and 'enable_thinking' not in body and 'thinking_budget' not in body
    # Official current provider documentation contradicts full-completion/v1.
    # It does not establish a hard reasoning upper for the unchanged wire.
    decision = 'DENY_BEFORE_SEND_OUTPUT_BOUND_UNVERIFIABLE'
    after = snapshot()
    assert before == after
    status = subprocess.check_output(['git', 'status', '--porcelain', '-z'], cwd=ROOT).decode().split('\0')
    protected_files = [{ 'path': x[3:], 'sha256': sha((ROOT / x[3:]).read_bytes()) }
                       for x in status if x and (ROOT / x[3:]).is_file()]
    save('preflight.json', {'status': decision, 'before': before, 'after': after,
                           'request_body_offline_only': body, 'existing_coded_contract': coded_contract,
                           'provider_contract': {'max_tokens_semantics': 'visible answer cap, excluding chain-of-thought',
                             'thinking_budget': 'not sent', 'reasoning_upper': None,
                             'qwen_4b_specific_hard_cap_support': 'UNVERIFIED',
                             'sources': ['https://docs.siliconflow.cn/docs/api/chat-completions-post',
                                         'https://docs.siliconflow.cn/docs/userguide/capabilities/reasoning']},
                           'protected_files': protected_files, 'new_provider_calls': 0,
                           'new_tokens': 0, 'question_submissions': 0,
                           'api_started': False, 'execution_fence_opened': False,
                           'elapsed_seconds': round(time.monotonic() - started, 3)})
    print(json.dumps({'decision': decision, 'tenant_id': 1, 'revision': 20,
                      'vectors': len(before['vectors']), 'old_unknown_unchanged': True,
                      'new_provider_calls': 0, 'question_submissions': 0}, ensure_ascii=False))
