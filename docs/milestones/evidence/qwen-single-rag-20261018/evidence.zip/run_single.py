"""One real HTTP question, current formal API, existing LocalExecution gate."""
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import runpy
import socket
import subprocess
import sys
import time
import uuid

import httpx
import psycopg
from psycopg.rows import dict_row

ROOT = Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
PARENT = Path(__file__).parent
OUT = PARENT / 'live'
CONFIG = Path(r'E:\WK\run\p81-retirement-20261018\local.json')
QUESTION = '请写出课件中线性方程组的系数矩阵，以及增广矩阵最后一列的三个数。'
KB = '9d3461a5-080c-4b5e-a367-c82b79d3013c'
DOC = '996fda57-6cc2-4045-a3ff-7416f037459a'
sys.path.insert(0, str(ROOT))
from scripts.local_runtime import environment
from backend.weknora_port.models.catalog import resolve_model_config
from backend.weknora_port.models.request import build_chat_body
from backend.weknora_port.models.types import ChatOptions, Message
from backend.weknora_port.models.output_contract import resolve_output_contract


def save(name, value):
    (OUT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2, default=str) + '\n', encoding='utf-8')


def db_snapshot(env, session_id):
    with psycopg.connect(env['WEKNORA_PORT_DATABASE_URL'], autocommit=True,
                        row_factory=dict_row, connect_timeout=5) as c:
        c.execute('BEGIN TRANSACTION READ ONLY')
        result = {'turns': c.execute('SELECT * FROM port_turns WHERE tenant_id=1 AND session_id=%s', (session_id,)).fetchall(),
                  'messages': c.execute('SELECT * FROM messages WHERE tenant_id=1 AND session_id=%s ORDER BY created_at,id', (session_id,)).fetchall(),
                  'calls': c.execute('SELECT * FROM port_provider_calls WHERE tenant_id=1 AND session_id=%s ORDER BY created_at,call_id', (session_id,)).fetchall(),
                  'attempts': c.execute('SELECT a.* FROM generation_attempts a JOIN generation_runs r USING(run_id) WHERE r.tenant_id=1 AND r.session_id=%s ORDER BY a.ordinal', (session_id,)).fetchall()}
        c.execute('ROLLBACK')
    # Repeated SSE cumulative usage snapshots are unnecessary here. Raw wire
    # receipts are retained by the existing observer, without request headers.
    def compact(x):
        if isinstance(x, dict): return {k: compact(v) for k, v in x.items() if k != 'prior_numeric_raw'}
        if isinstance(x, list): return [compact(v) for v in x]
        return x
    return compact(result)


def main():
    assert not (OUT / 'question-submitted.json').exists(), 'ONE_QUESTION_ALREADY_SUBMITTED_NO_RETRY'
    assert not (OUT / 'execution.json').exists(), 'NEVER_RESET_EXECUTION'
    OUT.mkdir(exist_ok=True)
    before = runpy.run_path(str(PARENT / 'preflight.py'), run_name='preflight_library')['snapshot']()
    cfg = json.loads(CONFIG.read_text(encoding='utf-8-sig'))
    assert cfg['api_port'] == 56425 and before['tenant_id'] == 1
    with socket.socket() as check:
        assert check.connect_ex(('127.0.0.1', cfg['api_port'])) != 0, 'EXISTING_API_DO_NOT_REPLACE'
    config = resolve_model_config('siliconflow', 'Qwen/Qwen3.5-4B', base_url='https://api.siliconflow.cn/v1', model_type='KnowledgeQA')
    body = build_chat_body(config, (Message('user', 'offline verification'),),
                           ChatOptions(temperature=.3, max_completion_tokens=1024, thinking=False), stream=True)
    contract = resolve_output_contract(config, body)
    assert body['enable_thinking'] is False and contract.thinking_mode == 'disabled' and contract.output_upper == 1024
    allowed = []
    for m in before['models']:
        if m['role'] == 'vlm': continue
        capability = {'embedding': 'embedding', 'rerank': 'rerank'}.get(m['role'], 'chat')
        allowed.append({'provider': m['provider'], 'model': m['name'], 'model_id': m['id'], 'capability': capability})
    assert len(allowed) == 5
    principal_subject = 'web_user:local:bba83fda-3749-499b-9b1a-1f42aa2da8a6'
    assert hashlib.sha256(principal_subject.encode()).hexdigest() == before['subject_sha256']
    authorization = {'status': 'AUTHORIZED', 'owner_evidence': 'Owner approved the exact finite scope in this conversation after call_cf96fa93616043d78b763810c920413f',
                     'max_questions': 1, 'max_calls': 6, 'max_tokens': 100000,
                     'scope': 'tenant1 existing M3.5 KB; SiliconFlow and existing DYNAMIC DeepSeek Expensive',
                     'old_unknown': 'retained; this is a different request, not a retry',
                     'per_request_reasoning_effort': 'off', 'production_defaults_changed': False}
    save('owner-authorization.json', authorization)
    grant = {'status': 'OPEN', 'scope': 'QWEN_SINGLE_RAG', 'tenant_id': 1, 'subject_id': principal_subject,
             'allowed_kbs': [KB], 'allowed_models': allowed,
             'allowed_request_prefixes': list('0123456789abcdef'),
             'request_prefix_basis': 'Normal server-issued UUID; exact principal, KB and model IDs restrict sends; no Worker started',
             'max_calls': 6, 'max_tokens': 100000, 'capture_evidence': True, 'entries': [],
             'approval_reference': 'owner-authorization.json'}
    with (OUT / 'execution.json').open('x', encoding='utf-8') as f: json.dump(grant, f, indent=2)
    save('preflight.json', {'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT).decode().strip(),
                           'identity': before, 'output_contract': dataclasses.asdict(contract), 'authorization': authorization})
    env = environment(cfg, before['redis_run_id'])
    env.update(WEKNORA_PORT_CLOUD_ALLOWED='true', WEKNORA_PORT_EXECUTION_FILE=str(OUT / 'execution.json'),
               PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1')
    process = None
    session_id = None
    try:
        with (OUT / 'api.log').open('wb') as log:
            process = subprocess.Popen([sys.executable, '-B', '-m', 'backend.weknora_port.entrypoint', '--host', '127.0.0.1', '--port', str(cfg['api_port'])],
                cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
            save('process.json', {'pid': process.pid, 'entrypoint': 'backend.weknora_port.entrypoint', 'port': cfg['api_port'], 'worker_started': False})
            with httpx.Client(base_url='http://127.0.0.1:56425', trust_env=False,
                              headers={'Origin': 'http://127.0.0.1:56426'}, timeout=httpx.Timeout(1800, connect=5)) as api:
                deadline = time.monotonic() + 35
                while True:
                    assert process.poll() is None, 'API_EXITED_SEE_LOG'
                    try:
                        ready = api.get('/readyz'); ready.raise_for_status(); break
                    except httpx.ConnectError:
                        assert time.monotonic() < deadline, 'API_START_FAILED'
                        time.sleep(.2)
                assert ready.json()['cloud_allowed'] is True
                roles = api.get('/api/v1/settings/model-configuration'); roles.raise_for_status(); save('model-configuration.json', roles.json())
                assert all(r['credential_status'] == 'CONFIGURED' for r in roles.json()['data']['roles'])
                assert next(r for r in roles.json()['data']['roles'] if r['role'] == 'cheap')['model'] == 'Qwen/Qwen3.5-4B'
                docs = api.get('/api/v1/knowledge-bases/' + KB + '/documents'); docs.raise_for_status(); save('documents.json', docs.json())
                session = api.post('/api/v1/sessions', json={'knowledge_base_scope': [KB], 'document_scope': [], 'title': 'Qwen 单次非思考模式 RAG 正例验证'})
                session.raise_for_status(); save('session.json', session.json()); session_id = session.json()['data']['id']
                payload = {'content': QUESTION, 'request_id': str(uuid.uuid4()), 'knowledge_base_scope': [KB], 'document_scope': [], 'mode': 'quick', 'reasoning_effort': 'off'}
                with (OUT / 'question-submitted.json').open('x', encoding='utf-8') as f: json.dump({'session_id': session_id, 'payload': payload, 'time': time.time()}, f, ensure_ascii=False, indent=2)
                events = []
                started = time.monotonic()
                with (OUT / 'response.sse').open('w', encoding='utf-8') as trace:
                    with api.stream('POST', f'/api/v1/sessions/{session_id}/messages', json=payload) as response:
                        response.raise_for_status()
                        for line in response.iter_lines():
                            trace.write(line + '\n'); trace.flush()
                            if line.startswith('data: '):
                                event = json.loads(line[6:]); event['observed_elapsed_seconds'] = round(time.monotonic() - started, 6); events.append(event)
                                if event.get('response_type') == 'complete': break
                elapsed = round(time.monotonic() - started, 6)
                save('events.json', events)
                history = api.get(f'/api/v1/sessions/{session_id}/messages'); history.raise_for_status(); save('history.json', history.json())
                save('http-result.json', {'status': 'ONE_QUESTION_SUBMITTED', 'elapsed_seconds': elapsed, 'events': len(events), 'terminal': events[-1] if events else None})
                save('db-after.json', db_snapshot(env, session_id))
    finally:
        if session_id is not None and process is not None and process.poll() is None:
            # A client-side observation failure does not own cancellation. Wait
            # for this exact server turn to become terminal; never resubmit it.
            wait_started = time.monotonic()
            while True:
                observed = db_snapshot(env, session_id)
                if observed['turns'] and observed['turns'][0]['status'] in ('completed', 'error'):
                    break
                if process.poll() is not None:
                    break
                if time.monotonic() - wait_started > 2100:
                    save('live-wait-needed.json', {'pid': process.pid, 'session_id': session_id,
                                                   'reason': 'server still live; no termination/retry'})
                    # Leave the verified live process for the parent to inspect.
                    process = None
                    raise RuntimeError('VERIFIED_LIVE_SERVER_REQUIRES_FURTHER_WAIT')
                time.sleep(2)
        if process is not None and process.poll() is None:
            # Only after the request loop reached a terminal event/error. Never
            # interrupt an in-flight model because a progress poll timed out.
            process.terminate()
            process.wait(timeout=20)
        if session_id is not None:
            save('db-final.json', db_snapshot(env, session_id))
        ledger = json.loads((OUT / 'execution.json').read_text(encoding='utf-8'))
        if all(row['status'] == 'SETTLED' for row in ledger['entries']):
            ledger.update(status='CLOSED', closed_at=time.time(), unused_calls_revoked=6-len(ledger['entries']),
                          unused_tokens_revoked=100000-sum(row['held_tokens'] for row in ledger['entries']))
            save('execution.json', ledger)
        else:
            # Retain INFLIGHT/UNKNOWN and full reservation. No new grant/retry.
            if ledger['status'] == 'OPEN': ledger['status'] = 'STOP'; save('execution.json', ledger)
        after = runpy.run_path(str(PARENT / 'preflight.py'), run_name='preflight_library')['snapshot']()
        for key in ('old_unknown', 'protected_db_hashes', 'daily_config_sha256', 'model_configuration'):
            assert before[key] == after[key], key + '_CHANGED'
        save('protection-after.json', {'old_unknown_unchanged': True, 'tenant332_models_unchanged': True,
              'source_index_unchanged': True, 'daily_config_unchanged': True,
              'provider_calls_before': before['provider_calls'], 'provider_calls_after': after['provider_calls'],
              'execution_status': ledger['status'], 'entries': len(ledger['entries']),
              'reported_tokens': sum((row.get('usage') or {}).get('total_tokens', 0) for row in ledger['entries']),
              'unknown': sum(row['status'] != 'SETTLED' for row in ledger['entries'])})
    print(json.dumps(json.loads((OUT / 'protection-after.json').read_text(encoding='utf-8'))))


if __name__ == '__main__':
    main()
