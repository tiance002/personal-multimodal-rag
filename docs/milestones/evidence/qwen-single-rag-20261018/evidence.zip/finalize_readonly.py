import hashlib, html, json
from datetime import datetime
from pathlib import Path
root=Path(r'E:\RAG-Worktrees\weknora-python-port-20261013')
p=Path(r'E:\WK\run\qwen-single-rag-20261018\live')
load=lambda f:json.loads(f.read_text(encoding='utf-8'))
d=load(p/'db-final.json'); grant=load(p/'execution.json'); h=load(p/'history.json')
stagefile=next((p/'evidence').glob('*.stages.json')); s=load(stagefile)
st={x['stage']:x for x in s['stages'] if x['status']=='completed'}
requests=[(f,load(f)) for f in (p/'evidence').glob('*.request.json')]
qf,q=next((f,r) for f,r in requests if r['model']=='Qwen/Qwen3.5-4B')
rqf,rq=next((f,r) for f,r in requests if r['capability']=='rerank')
raw=load(rqf.with_name(rqf.name.replace('.request.json','.response.body')))
search=st['retrieval']['state']['search_results']; reranked=st['rerank']['state']['rerank_results']; merged=st['merge']['state']['merge_results']
target='96ad695f-bb32-4df9-9cfb-1e8281f2fc31'; version='91f260da-03e3-422e-ae08-b6f818ee3b7b'
text=next(r for r in search if r['id']==target)
assert text['metadata']['source_version']==version
prepared_user=next(m['content'] for m in q['body']['messages'] if m['role']=='user')
assert text['content'] in html.unescape(prepared_user)
assert q['body']['enable_thinking'] is False and q['body']['max_tokens']==1024
assert target in s['finalized_context']['result_ids'] and target in [r['id'] for r in reranked]
assert len(d['calls'])==6 and all(c['outcome']=='RESPONSE_RECEIVED' for c in d['calls'])
assert not any(c['model']=='Qwen/Qwen3.5-4B' for c in d['calls'])
assert not qf.with_name(qf.name.replace('.request.json','.response.body')).exists()
assert grant['status']=='CLOSED' and all(e['status']=='SETTLED' for e in grant['entries'])
assert d['turns'][0]['error_code']=='LOCAL_EXECUTION_LIMIT_DENIED'
assistant=next(m for m in h['data'] if m['role']=='assistant')
assert assistant['turn_status']=='error' and assistant['turn_error_code']==d['turns'][0]['error_code'] and assistant['content']==''
initial=load(p.parent/'preflight.json')
files_check=[{'path':f['path'],'unchanged':hashlib.sha256((root/f['path']).read_bytes()).hexdigest()==f['sha256']} for f in initial['protected_files']]
assert all(f['unchanged'] for f in files_check)
def slim(r):return {'id':r['id'],'score':r['score'],'knowledge_base_id':r['knowledge_base_id'],'document_id':r['knowledge_id'],'source_version':r['metadata'].get('source_version'),'start_at':r['start_at'],'end_at':r['end_at']}
usage=[]
for c in d['calls']:
 u=c['usage']; dur=(datetime.fromisoformat(c['finished_at'])-datetime.fromisoformat(c['created_at'])).total_seconds()
 usage.append({'request_id':c['request_id'],'provider':c['provider'],'model':c['model'],'outcome':c['outcome'],'prompt_tokens':u['prompt_tokens'],'completion_tokens':u['completion_tokens'],'total_tokens':u['total_tokens'],'admission_to_settlement_seconds':round(dur,6),'wire_sha256':c['wire_sha256']})
rawmap=[{'index':r['index'],'chunk_id':search[r['index']]['id'],'relevance_score':r['relevance_score'],'passes_0_3':r['relevance_score']>=.3} for r in raw['results']]
summary={'status':'BLOCKED_PROVIDER_CALL_LIMIT_BEFORE_QWEN','candidate_status':'CANDIDATE_NOT_VALIDATED','source_head':load(p/'preflight.json')['source_head'],'question':d['turns'][0]['q0'],'run_id':s['run_id'],'session_id':s['session_id'],'tenant_id':1,'kb_scope':d['turns'][0]['knowledge_base_scope'],'document_scope':d['turns'][0]['document_scope'],'source_version':version,'local_thinking_mode':'off for this request only; global defaults unchanged','query_understanding':{'model':'XingChenAGI/Xing4.0-29B','intent':st['understand']['state']['intent'],'rewrite':st['understand']['state']['rewrite_query']},'search':list(map(slim,search)),'rerank':{'threshold':.3,'top1_floor':.15,'raw':rawmap,'selected':list(map(slim,reranked))},'merge':list(map(slim,merged)),'context':{'result_ids':s['finalized_context']['result_ids'],'rendered_chars':len(s['finalized_context']['rendered_contexts']),'target_text_sha256':hashlib.sha256(text['content'].encode()).hexdigest(),'target_full_text_present':True,'full_target_in_prepared_generation_body':True,'provider_received_context':False,'target_text':text['content']},'qwen':{'requested_model':q['model'],'sent':False,'prepared_body_parameters':{k:v for k,v in q['body'].items() if k!='messages'},'answer':None,'quality':'NOT RUN','ttft_seconds':None,'provider_finish_reason':None,'generation_attempt_status':d['attempts'][0]['status'],'generation_attempt_usage_status':d['attempts'][0]['usage']['status'],'generation_attempt_cost_status':d['attempts'][0]['cost_status'],'usage_unknown_explanation':'Unsent FAILED attempt stores generic unknown usage/cost sentinel; there is no Qwen provider call or execution reservation.'},'calls':usage,'usage':{'actual_provider_calls':6,'prompt_tokens':sum(c['prompt_tokens'] for c in usage),'completion_tokens':sum(c['completion_tokens'] for c in usage),'reported_total_tokens':sum(c['total_tokens'] for c in usage),'new_provider_unknown':0,'qwen_provider_calls':0,'expensive_provider_calls':0},'http':load(p/'http-result.json'),'sse_history_turn_consistent':True,'user_message_pending_field':'history/db user message remains pending; assistant and turn correctly terminal error','execution':{'status':grant['status'],'max_calls':6,'max_tokens':100000,'unused_tokens_revoked':grant['unused_tokens_revoked'],'unknown_held_tokens':0},'protection':load(p/'protection-after.json'),'inherited_paths':files_check,'first_failure':'Provider call-count admission before final Qwen send; not retrieval or Qwen quality failure','planning_error':'One understanding + four normal expansion/query embeddings + one rerank exhausted all six authorized calls; final generation required at least a seventh. No disabled expansion or extra send to evade cap.'}
(p/'analysis.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':summary['status'],'tokens':summary['usage'],'target_rerank_score':next(r['relevance_score'] for r in rawmap if r['chunk_id']==target),'context_chars':summary['context']['rendered_chars'],'protected_paths':len(files_check)},ensure_ascii=False))
