"""P31 API/worker entrypoint. No authority or fence imports."""
import runpy, sys
from pathlib import Path
repo=Path(r"E:/RAG-Worktrees/weknora-python-port-20261013")
sys.path.insert(0,str(repo))
from scripts.p31_native_acceptance import service_main
service_main()
